document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"/template/jrydf/css/index.min.css\">");
$(function() {
    $("div.lazy").lazyload({effect:"show"});
    $("img.lazy").lazyload({effect:"show"});
    var swiper = new Swiper('.banner', {
        pagination: ".swiper-pagination",
		slidesPerView: "auto",
		centeredSlides: !0,
		paginationClickable: !0,
		loop: !0,
		preloadImages: false,
		lazyLoading: true,
		lazyLoadingInPrevNext:true,
		lazyLoadingInPrevNextAmount:1,
    });
	var videoSelectWrap = new Swiper('.videoSelectWrap',{freeMode : true,slidesPerView : 'auto',lazyLoading: true,lazyLoadingInPrevNext:true,lazyLoadingInPrevNextAmount:3,});
	var scroll = new auiScroll({
	    listen:true,
	    distance:200
	},function(ret){
		if(ret.scrollTop>40){
			$('.scroll-to-top').show();
		}else{
			$('.scroll-to-top').hide();
		}
	});
	$(".scroll-to-top").click(function(){
		$("html,body").animate({scrollTop:0}, 500);
	});
});
