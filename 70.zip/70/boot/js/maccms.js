document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"/template/boot/css/css.css\">");
