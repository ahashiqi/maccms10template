document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"/template/fsdf/images/base.css\">");
document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"/template/fsdf/images/main.css\">");
