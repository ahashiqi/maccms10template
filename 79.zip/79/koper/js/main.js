document.writeln("<link rel=\"stylesheet\" type=\"text/css\" href=\"/template/koper/images/foot.css\">");
