var feifei = {
//start
'browser':{//浏览器
	'url': document.URL,
	'title': document.title,
	'language': (navigator.browserLanguage || navigator.language).toLowerCase(),//zh-tw|zh-hk|zh-cn
	'canvas' : function(){
		return !!document.createElement('canvas').getContext;
	}(),
	'useragent' : function(){
		var ua = navigator.userAgent;//navigator.appVersion
		return {
			'mobile': !!ua.match(/AppleWebKit.*Mobile.*/), //是否为移动终端 
			'ios': !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
			'android': ua.indexOf('Android') > -1 || ua.indexOf('Linux') > -1, //android终端或者uc浏览器 
			'iPhone': ua.indexOf('iPhone') > -1 || ua.indexOf('Mac') > -1, //是否为iPhone或者QQHD浏览器 
			'iPad': ua.indexOf('iPad') > -1, //是否iPad
			'trident': ua.indexOf('Trident') > -1, //IE内核
			'presto': ua.indexOf('Presto') > -1, //opera内核
			'webKit': ua.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
			'gecko': ua.indexOf('Gecko') > -1 && ua.indexOf('KHTML') == -1, //火狐内核 
			'weixin': ua.indexOf('MicroMessenger') > -1 //是否微信 ua.match(/MicroMessenger/i) == "micromessenger",			
		};
	}()
},
'click':{//点击事件
	'more': function(){//ajax翻页
		$("#ff-page-next").bind('click', function(){
			$.get($(this).attr('data-ajaxurl')+(cms.page*1+1), function(data){
				if(data){
					$("#ff-page-box").append(data);// 插入新元素
					cms.page++;// 更新页码
				}else{
					$("#ff-page-next").hide();
					$(this).unbind("click");
				}
			},'html');
		});
	},
	'updown': function(){
		$('body').on('click', 'a.ff-updown', function(e){
			var $this = $(this);
			if($(this).attr("data-id")){
				$.ajax({
					url: cms.root+'index.php?s=updown-'+$(this).attr("data-module")+'-id-'+$(this).attr("data-id")+'-type-'+$(this).attr("data-type"),
					cache: false,
					dataType: 'json',
					success: function(json){
						$this.addClass('disabled');
						if(json.status == 1){
							if($this.attr("data-type")=='up'){
								$this.find('.ff-updown-tips').html(json.data.up);
							}else{
								$this.find('.ff-updown-tips').html(json.data.down);
							}
						}else{
							$this.attr('title', json.info);
							$this.tooltip('show');
						}
					}
				});
			}
		});
	}
},
'submit':{//表单提交事件
	'search': function(){
		$("#ff-search button").on("click",function(){
			$action = $(this).attr('data-action');
			if($action){
				$("#ff-search").attr('action', $action);
			}
		});
		$("#ff-search").on("submit", function(){
			$action = $(this).attr('action');
			if(!$action){
				$action = cms.root+'index.php?s=vod-search';
			}
			$wd = $('#ff-search #ff-wd').val();
			if($wd){
				location.href = $action.replace('FFWD',encodeURIComponent($wd));
			}else{
				$("#ff-wd").focus();
				$("#ff-wd").attr('data-toggle','tooltip').attr('data-placement','bottom').attr('title','请输入关键字').tooltip('show');
			}
			return false;
		});
	}
},
'key':{//键盘
	'enter': function(){//回车
		$("#ff-search input").keyup(function(event){
			if(event.keyCode == 13){
				location.href = cms.root+'index.php?s=vod-search-wd-'+encodeURIComponent($('#ff-search #ff-wd').val())+'-p-1.html';
			}
		});
	},
	'page': function(){//翻页
	}
},
'scroll':{//滚动条
	'fixed' : function($id, $top, $width){// 悬浮区域
		var offset = $('#'+$id).offset();
		if(offset){
			if(!$top){
				$top = 5;
			}
			if(!$width){
				$width = $('#'+$id).width();
			}			
			$(window).bind('scroll', function(){
				if($(this).scrollTop() > offset.top){
					$('#'+$id).css({"position":"fixed","top":$top+"px","width":$width+"px"});
				}else{
					$(('#'+$id)).css({"position":"relative"});
				}
			});		
		}
	},
	'totop':function($id, $top){//返回顶部
		// $id:dc-totop $top:偏移值
		$('body').append('<a href="#" class="'+$id+'" id="'+$id+'"><i class="glyphicon glyphicon-chevron-up"></i></a>');
		$(window).bind('scroll', function(){
			if($(this).scrollTop() > $top){
				$('#'+$id).fadeIn("slow");
			}else{
				$('#'+$id).fadeOut("slow");
			}
		});	
	}
},
'load':{//延迟加载
	'images': function(){
		$.ajaxSetup({
			cache: true 
		});
		$.getScript("https://cdn.staticfile.org/jquery.lazyload/1.11.3/jquery.lazyload.min.js", function(response, status) {
			$("img.ff-img").lazyload({
				placeholder : cms.root+"Public/images/no.jpg",
				effect : "fadeIn",
				failurelimit: 15

			}); 
		});
	},
  'flickity':function(){//手机滑动
		if($(".ff-gallery").length && feifei.browser.useragent.mobile){
			$.ajaxSetup({ 
				cache: true 
			});
			$("<link>").attr({ rel: "stylesheet",type: "text/css",href: "https://cdnjs.cloudflare.com/ajax/libs/flickity/1.1.1/flickity.min.css"}).appendTo("head");
			$.getScript("https://cdnjs.cloudflare.com/ajax/libs/flickity/1.1.1/flickity.pkgd.min.js", function(response, status) {
				$('.ff-gallery').flickity({
					cellAlign: 'left',
					freeScroll: true,
					contain: true,
					prevNextButtons: false,
					pageDots: false
				});
			});
		}
	},
	'raty': function(){
		$.ajaxSetup({ 
			cache: true 
		});
		if($("#ff-raty").length ){
			$("<link>").attr({ rel: "stylesheet",type: "text/css",href: cms.root+"Public/jquery/1.11.3/jquery.raty.min.css"}).appendTo("head");
			$.getScript(cms.root+"Public/jquery/1.11.3/jquery.raty.min.js", function(response, status) {
				$('#ff-raty').raty({ 
					starType: 'i',
					number: 5,
					numberMax : 5,
					half: true,
					score : function(){
						return $(this).attr('data-score');
					},
					click: function(score, evt) {
						$.ajax({
							type: 'get',
							url: cms.root+'index.php?s=gold-'+$('#ff-raty').attr('data-module')+'-id-'+$('#ff-raty').attr('data-id')+'-score-'+(score*2),
							timeout: 5000,
							dataType:'json',
							error: function(){
								$('#ff-raty').attr('title', '网络异常！').tooltip('show');
							},
							success: function(json){
								if(json.status == 1){
									$('#ff-raty-tips').html(json.data.gold);
								}else{
									$('#ff-raty').attr('title', json.info).tooltip('show');
								}
							}
						});
					}
				});
			});
		}
	},

},
'cms':{//CMS系统
	'goback': function(){
		if(feifei.browser.useragent.mobile){
			if(history.length > 0 && document.referrer){
				$("#ff-goback").show();
				$('#ff-goback').attr('href','javascript:history.go(-1);');
			}else{
				$("#ff-goback").hide();
			}
		}
	},
	'comment': function(){
		if($(".ff-comment").length ){
			$(".ff-comment").html('<div id="uyan_frame"></div>');
			$.getScript("");
		}
	},
	'share': function(){
		if($(".ff-share").length ){
			$(".ff-share").html('<div class="bdsharebuttonbox"><a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a><a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a><a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a><a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a><a href="#" class="bds_bdysc" data-cmd="bdysc" title="分享到百度云收藏"></a><a href="#" class="bds_copy" data-cmd="copy" title="分享到复制网址"></a></div>');
			window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
		}
	},
	'nav': function($id){
		$('#nav-'+$id).addClass("active");
	},
	'qrcode': function(){
		$("[data-toggle='popover']").popover({
				html:true
		});
		$("[data-toggle='popover']").on('show.bs.popover', function () {
			$("[data-toggle='popover']").attr('data-content','<img src="https://api.pwmqr.com/qrcode/create/?url='+encodeURIComponent(feifei.browser.url)+'"/>');
		})
	},
	'download': function(){
		if($(".ff-down-list").length ){
			$.getScript("https://cdn.feifeicms.co/download/xunlei.js");
		}
	}
}
//end
};
/*#ff-search #wd #ff-goback .ff-gallery .ff-raty .ff-img .ff-share*/
$(document).ready(function(){
	feifei.submit.search();
    feifei.load.images();
	feifei.load.raty();
	feifei.load.autocomplete();
	feifei.load.flickity();	
	feifei.scroll.totop('ff-totop',5);
	feifei.click.updown();
	feifei.cms.goback();
	feifei.cms.share();
	feifei.cms.qrcode();
	feifei.cms.download();
	feifei.cms.comment();
});