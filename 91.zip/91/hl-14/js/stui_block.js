/*!
 * v3.0 Copyright 2016-2018 http://v.shoutu.cn
 * Email 726662013@qq.com
 */



var playerhigh = "1"; 


