
$(document).ready(function ($) {
  var recente = $.cookie("mac_history_dianying");
  var len = 0;
  var canadd = true;
  if (recente) {
    recente = eval("(" + recente + ")");
    len = recente.length;
    $(recente).each(function () {
      if (vod_name == this.vod_name) {
        canadd = false;
        var json = "[";
        $(recente).each(function (i) {
          var temp_name, temp_url, temp_part, temp_pic,temp_id, temp_remarks;
          if (this.vod_name == vod_name) {
            temp_name = vod_name;
            temp_url = vod_url;
            temp_part = vod_part;
            temp_pic = vod_pic;
            temp_id = vod_id;
            temp_remarks = vod_remarks;
          } else {
            temp_name = this.vod_name;
            temp_url = this.vod_url;
            temp_part = this.vod_part;
            temp_id = this.vod_id;
            temp_pic = this.vod_pic;
            temp_remarks = this.vod_remarks;
          }
          json += "{\"vod_name\":\"" + temp_name + "\",\"vod_id\":\"" + temp_id + "\",\"vod_pic\":\"" + temp_pic + "\",\"vod_remarks\":\"" + temp_remarks + "\",\"vod_url\":\"" + temp_url + "\",\"vod_part\":\"" + temp_part + "\"}";
          if (i != len - 1)
            json += ",";
        })
        json += "]";
        $.cookie("mac_history_dianying", json, {
          path: "/",
          expires: (2)
        });
        return false;
      }
    });
  }
  if (canadd) {
    var json = "[";
    var start = 0;
    var isfirst = "]";
    isfirst = !len ? "]" : ",";
    json += "{\"vod_name\":\"" + vod_name + "\",\"vod_id\":\"" + vod_id + "\",\"vod_pic\":\"" + vod_pic + "\",\"vod_remarks\":\"" + vod_remarks + "\",\"vod_url\":\"" + vod_url + "\",\"vod_part\":\"" + vod_part + "\"}" + isfirst;
    if (len > 9)
      len -= 1;
    for (i = 0; i < len - 1; i++) {
      json += "{\"vod_name\":\"" + recente[i].vod_name + "\",\"vod_id\":\"" + recente[i].vod_id + "\",\"vod_pic\":\"" + recente[i].vod_pic + "\",\"vod_remarks\":\"" + recente[i].vod_remarks + "\",\"vod_url\":\"" + recente[i].vod_url + "\",\"vod_part\":\"" + recente[i].vod_part + "\"},";
    }
    if (len > 0) {
      json += "{\"vod_name\":\"" + recente[len - 1].vod_name + "\",\"vod_id\":\"" + recente[len - 1].vod_id + "\",\"vod_pic\":\"" + recente[len - 1].vod_pic + "\",\"vod_remarks\":\"" + recente[len - 1].vod_remarks + "\",\"vod_url\":\"" + recente[len - 1].vod_url + "\",\"vod_part\":\"" + recente[len - 1].vod_part + "\"}]";
    }
    $.cookie("mac_history_dianying", json, {
      path: "/",
      expires: (2)
    });
  }
})
