<?php
namespace app\admin\controller;


class Mgwap extends Base
	{
		public function mgwset()
		{
			if (Request()->isPost()) {
				$config = input();
				$config_new["mgwcms"] = $config["mgwcms"];
				$config_old = config("mgwst");
				$config_new = array_merge($config_old, $config_new);
				$res = mac_arr2file(APP_PATH . "extra/mgwst.php", $config_new);
				if ($res === false) {
					return $this->error("保存失败，请重试!");
				}
				return $this->success("保存成功!");
			}
			$this->assign("config", config("mgwst"));
			return $this->fetch("admin@system/mgwcms");
		}
	}
