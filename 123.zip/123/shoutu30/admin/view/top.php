<div class="tzt-header">
    <div style="float: right;text-align: right; margin-top: 18px;">
        <p>当前版本：v<?php echo $info['version'];?></p>
        <?php 
            if($info['version']<$edition['edition']){
                echo '<a href="https://www.taozhuti.cn'.$edition['url'].'" target="_blank" class="layui-badge layui-bg-red">发现新版本 v'.$edition['edition'].'</a>';
            }else{
                echo '<a href="" target="_blank" class="layui-badge layui-bg-red">已是最新版本</a>';
            }
        ?>
    </div>
    <h3>
        <img src="images/logo2.png" />
        <a style="margin-left: 20px;" href="javascript:;" data-url="?url=index&manage=backup" data-msg="当前操作将备份您的所有设置，请确保主题目录有可写权限" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><i class="layui-icon layui-icon-file"></i> 备份设置</a>
        <a style="margin-left: 20px;" href="javascript:;" data-url="?url=index&manage=resume" data-msg="当前操作将恢复为您备份过的设置，请确保已经操作过备份设置<br>操作不可撤销，确认操作吗？" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><i class="layui-icon layui-icon-set"></i> 恢复设置</a>
        <a style="margin-left: 20px;" href="javascript:;" data-url="?url=index&manage=resetting" data-msg="当前操作将清空您主题的所有设置，并还原至初始状态<br>操作不可撤销，确认操作吗？" class="layui-btn layui-btn-sm layui-btn-normal layer-confirm"><i class="layui-icon layui-icon-refresh-1
"></i> 重置设置</a>
        <a style="margin-left: 20px;" target="_back" href="/" class="layui-btn layui-btn-sm layui-btn-normal"><i class="layui-icon layui-icon-home"></i> 网站首页</a>
    </h3>
</div>