<?php 
	require('./config.php');
	$data = $config['basic'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php'); ?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<form class="layui-form" method="post" action="?url=basic&array=basic&type=post" enctype="multipart/form-data">
					<?php config_input('basic',$config['basic']) ?>
					<div class="layui-form-item">
						<div class="layui-input-block">
							<button type="submit" class="layui-btn layui-btn-normal post-submit"> <i class="layui-icon layui-icon-release"></i> 确认保存</button>
							<button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="?url=basic&array=basic&type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！">
								<i class="layui-icon layui-icon-delete"></i> 清空设置
							</button>
							<a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
						</div>
					</div>
				</form>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

