<?php 
	require('./config.php');
	$href = '?url=play&array=play&';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>后台管理中心</title>
<?php require('header.php');?>
</head>
	<body>
		<div class="page-container">
			<?php require('top.php');?>
			<ul class="layui-nav">
				<?php config_menu($config) ?>
			</ul>
			<div class="layui-tab-content">
				<blockquote class="layui-elem-quote layui-text">
  					模块组逻辑：填写标题》选择模块》填写模块参数，模块参数是指分类id或对应模块的值等，例如广告模块填广告id，其他选项可根据需求选择，获取当前分类、主演等参数值填写current，全部分类填写all，具体可查看<a href="" target="_blank">官方教程</a>操作。
				</blockquote>
				<div class="swiper">
					<div class="swiper-wrapper">
						<?php config_block_post('play',$href);?>
					</div>
					<div style="margin-top: 20px; text-align: center;">
						<a href="javascript:;" class="layui-btn layui-btn-sm layui-btn-normal left-prev">上一个</a>
						<span class="layui-btn layui-btn-sm layui-btn-primary lef-page" style="width: auto;"></span>
						<a href="javascript:;" class="layui-btn layui-btn-sm layui-btn-normal right-next">下一个</a>
					</div>
					<div class="swiper-pagination"></div>
					<div class="swiper-button-prev"></div>
					<div class="swiper-button-next"></div>
				</div>
				<form class="layui-form" method="post" action="<?php echo $href;?>type=post" enctype="multipart/form-data">
					<fieldset class="layui-elem-field layui-field-title" style="margin-top: 20px;">
						<legend>已添加的模块组 - 支持拖拽排序哦！</legend>
					</fieldset>
					<?php
						if(is_array($config['play']['data'])){
							config_block('play',$config['play']['data'],$href);
						}
					?>
					<div class="layui-form-item" style="padding-top: 20px; text-align: center;">
						<button type="submit" class="layui-btn layui-btn-normal"> <i class="layui-icon layui-icon-release"></i> 确认保存</button><button type="button" class="layui-btn layui-btn-danger layer-confirm" data-url="<?php echo $href;?>type=empty" data-msg="您确定要进行清空设置吗？该操作不可撤销！"><i class="layui-icon layui-icon-delete"></i> 清空模块</button><a href="/" target="_back" class="layui-btn layui-btn-primary"> <i class="layui-icon layui-icon-home"></i> 打开前台</a>
					</div>
				</form>
			</div>
		</div>
		<?php require('footer.php'); ?>
	</body>
</html>

