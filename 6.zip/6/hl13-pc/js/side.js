(function() {
	var b = {
		getObj: function(id) {
			return document.getElementById(id)
		},
		getElementsByClassName: function(className, tagName, box) {
			var d = box != null ? typeof box == "string" ? document.getElementById(box) : box : document;
			if (!tagName) {
				tagName = "*"
			};
			var children = d.getElementsByTagName(tagName) || document.all;
			var elements = new Array();
			for (var i = 0; i < children.length; i++) {
				var child = children[i];
				var classNames = child.className.split(' ');
				for (var j = 0; j < classNames.length; j++) {
					if (classNames[j] == className) {
						elements.push(child);
						break
					}
				}
			};
			if (elements.length == 1) {
				return elements[0]
			}
			return elements
		}
	};
	var mv_down = b.getElementsByClassName("mv_down");
	var mv_down_li_arr = mv_down.getElementsByTagName("li");
	var slideObj = b.getElementsByClassName("mv_c_in");
	var slide_li_arr = slideObj.getElementsByTagName("li");
	var slide_img_arr = slideObj.getElementsByTagName("img");
	var slideCount = 4;
	var w = 895;
	var n = 30;
	var c = 0;
	var timers = new Array(n);
	var doSlide = function(type) {
			for (var i = 0; i < mv_down_li_arr.length; i++) {
				mv_down_li_arr[i].className = c == i ? "xz" : ""
			}
			var y = slideObj.scrollLeft;
			var d = c * w - y;
			if (!d) return;
			for (var i = 0; i < n; i++)(function() {
				if (timers[i]) clearTimeout(timers[i]);
				var j = i;
				timers[i] = setTimeout(function() {
					slideObj.scrollLeft = y + Math.round(d * Math.sin(Math.PI * (j + 1) / (2 * n)))
				}, (i + 1) * n)
			})();
			var max_img_index = c * 5 + 5 > slide_img_arr.length ? slide_img_arr.length : c * 5 + 5;
			for (var i = c * 5; i < max_img_index; i++) {
				if (slide_img_arr[i].src.indexOf("lazy.gif") != -1) {
					slide_img_arr[i].src = slide_img_arr[i].getAttribute("xsrc")
				}
			}
		};
	b.getElementsByClassName("mv_L").firstChild.onclick = function() {
		setSlideInterval();
		if (c <= 0) c = slideCount;
		c--;
		doSlide()
	};
	b.getElementsByClassName("mv_R").firstChild.onclick = function() {
		setSlideInterval();
		c++;
		if (c >= slideCount) c = 0;
		doSlide()
	};
	var mv_down_a_arr = mv_down.getElementsByTagName("a");
	for (var i = 0; i < mv_down_a_arr.length; i++) {
		(function() {
			var j = i;
			mv_down_a_arr[i].onmouseover = function() {
				c = j;
				doSlide();
				if (doSlideInterval != null) {
					clearInterval(doSlideInterval);
					doSlideInterval = null
				}
				this.onmouseout = function() {
					var theEvent = window.event || arguments[0];
					if (isMouseLeaveOrEnter(theEvent, this)) {
						setSlideInterval()
					}
				}
			}
		})()
	}
	var doSlideInterval = null;

	function setSlideInterval() {
		if (doSlideInterval != null) {
			clearInterval(doSlideInterval);
			doSlideInterval = null
		}
		doSlideInterval = setInterval(function() {
			c++;
			if (c == slideCount) c = 0;
			doSlide(c)
		}, 6000)
	}
	setSlideInterval();
	for (var i = 0; i < slide_li_arr.length; i++) {
		slide_li_arr[i].onmouseover = function() {
			this.childNodes[1].previousSibling.style.display = "";
			if (doSlideInterval != null) {
				clearInterval(doSlideInterval);
				doSlideInterval = null
			}
			this.onmouseout = function() {
				var theEvent = window.event || arguments[0];
				if (isMouseLeaveOrEnter(theEvent, this)) {
					this.childNodes[0].style.display = "none";
					setSlideInterval()
				}
			}
		}
	}
})();