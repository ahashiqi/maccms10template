var n = parseInt(location.href.split("-")[1]) + 1;
var z = jQuery(".livetitle span").length;
if (n > z) {
	$("Tab_hot_1").className = "on";
	$("List_hot_1").style.display = "block";
	$("info_hot_1").style.display = "block";
} else {
	$("Tab_hot_" + n).className = "on";
	$("List_hot_" + n).style.display = "block";
	$("info_hot_" + n).style.display = "block";
};
var lis = $("ss" + n).getElementsByTagName("li");
var e = $("ss" + n).scrollHeight;
var u = new RegExp(/\w+?-\w+?-\w+?\.html/);
var a = location.href.match(u)[0];
var b = a.replace(/.html/, "").split('-')[2];
var f = lis.length % 4;
if (f == 2) {
	var b = b - 1;
} else if (f == 3) {
	var b = b - 2;
} else if (f == 0) {
	var b = b - 3;
} else {
	var b = b;
}
var d = Math.ceil(b / 4) * 38 + 38;
var c = e - d;
$("ss" + n).scrollTop = c;
for (var i = 0; i < lis.length; i++) {
	if (lis[i].getElementsByTagName("a")[0].href.match(u)[0] == a) {
		lis[i].getElementsByTagName("a")[0].className = "cur";
		if (lis[i].getElementsByTagName("a")[0].innerHTML.length > 16) {
			lis[i].getElementsByTagName("a")[0].innerHTML = lis[i].getElementsByTagName("a")[0].innerHTML.substring(0, 16) + ".."
		}
	}
}

function kuanp() {
	if (asdff == 1) {
		$("playbox").style.width = "1200px";
		$("cciframe").style.width = "1200px";
		$("playin").style.width = "1200px";
		$("kuanp").innerHTML = "\u7a84\u5c4f";
		setCookie("autokuanp", 1, 24);
		asdff = 2;
	} else if (asdff == 2) {
		$("playbox").style.width = "960px";
		$("cciframe").style.width = "960px";
		$("playin").style.width = "960px";
		$("kuanp").innerHTML = "\u5bbd\u5c4f";
		setCookie("autokuanp", 2, 24);
		asdff = 1;
	}
}
jQuery("#qvod").html("\u9700\u8981\u4e0b\u8f7d\u5feb\u64ad\u64ad\u653e\u5668");
jQuery("#xfplay").html("<a href='http://down.xfplay.com/xfplay.exe' target='_blank'>点击下载影音先锋播放器</a>");
jQuery("#ffhd").html("<a href='http://www.ffplay.net' target='_blank'>点击下载非凡影音播放器</a>");
jQuery("#xigua").html("<a href='http://s1.xiguaplayer.com/xigua_Install.exe' target='_blank'>\u70b9\u51fb\u4e0b\u8f7d\u897f\u74dc\u5f71\u97f3\u64ad\u653e\u5668</a>");