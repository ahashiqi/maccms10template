
function AJAX(G) {
	var K = [],
		$ = this,
		L = AJAX.__pool__ || (AJAX.__pool__ = []);
	(function(E) {
		var D = function() {};
		E = E ? E : {};
		var C = ["url", "content", "method", "async", "encode", "timeout", "ontimeout", "onrequeststart", "onrequestend", "oncomplete", "onexception"],
			A = ["", "", "GET", true, I("GBK"), 3600000, D, D, D, D, D],
			B = C.length;
		while (B--) $[C[B]] = _(E[C[B]], A[B]);
		if (!N()) return false
	})(G);

	function _(_, $) {
		return _ != undefined ? _ : $
	}
	function N() {
		var A, $ = [window.XMLHttpRequest, "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"];
		for (var B = 0; B < L.length; B += 1) if (L[B].readyState == 0 || L[B].readyState == 4) return L[B];
		for (B = 0; B < $.length; B += 1) {
			try {
				A = ($[B] && typeof($[B]) == "function" ? new $[B] : new ActiveXObject($[B]));
				break
			} catch (_) {
				A = false;
				continue
			}
		}
		if (!A) {
			throw "Cannot init XMLHttpRequest object!";
			return false
		} else {
			L[L.length] = A;
			return A
		}
	}
	function E($) {
		return document.getElementById($)
	}
	function C($) {
		var _ = $ * 1;
		return (isNaN(_) ? 0 : _)
	}
	function D($) {
		return (typeof($) == "string" ? ($ = E($)) ? $ : false : $)
	}
	function F() {
		return ((new Date) * 1)
	}
	function M($, _) {
		K[$ + ""] = _
	}
	function H($) {
		return (K[$ + ""])
	}
	function J(_, $, B) {
		return (function A(C) {
			C = C.replace(/([^\u0080-\u00FF]+)/g, function($0, $1) {
				return _($1)
			}).replace(/([\u0080-\u00FF])/g, function($0, $1) {
				return escape($1).replace("%", "%u00")
			});
			for (var E = 0, D = $.length; E < D; E += 1) C = C.replace($[E], B[E]);
			return (C)
		})
	}
	function I($) {
		if ($.toUpperCase() == "UTF-8") return (encodeURIComponent);
		else return (J(escape, [/\+/g], ["%2B"]))
	}
	function O(A, B) {
		if (!A.nodeName) return;
		var _ = "|" + A.nodeName.toUpperCase() + "|";
		if ("|INPUT|TEXTAREA|OPTION|".indexOf(_) > -1) A.value = B;
		else {
			try {
				A.innerHTML = B
			} catch ($) {}
		}
	}
	function P(_) {
		if (typeof(_) == "function") return _;
		else {
			_ = D(_);
			if (_) return (function($) {
				O(_, $.responseText)
			});
			else return $.oncomplete
		}
	}
	function B(_, A, $) {
		var C = 0,
			B = [];
		while (C < _.length) {
			B[C] = _[C] ? ($[C] ? $[C](_[C]) : _[C]) : A[C];
			C += 1
		}
		while (C < A.length) {
			B[C] = A[C];
			C += 1
		}
		return B
	}
	function A() {
		var E, C = false,
			K = N(),
			J = B(arguments, [$.url, $.content, $.oncomplete, $.method, $.async, null], [null, null, P, null, null, null]),
			G = J[0],
			I = J[1],
			L = J[2],
			M = J[3],
			H = J[4],
			A = J[5],
			O = M.toUpperCase() == "POST" ? true : false;
		if (!G) {
			throw "url is null";
			return false
		}
		var _ = {
			url: G,
			content: I,
			method: M,
			params: A
		};
		if (!O) G += (G.indexOf("?") > -1 ? "&" : "?") + "timestamp=" + F();
		K.open(M, G, H);
		$.onrequeststart(_);
		if (O) K.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		K.setRequestHeader("X-Request-With", "XMLHttpRequest");
		E = setTimeout(function() {
			C = true;
			K.abort()
		}, $.timeout);
		var D = function() {
				if (C) {
					$.ontimeout(_);
					$.onrequestend(_)
				} else if (K.readyState == 4) {
					clearTimeout(E);
					_.status = K.status;
					try {
						if (K.status == 200) L(K, A);
						else $.onexception(_)
					} catch (B) {
						$.onexception(_)
					}
					$.onrequestend(_)
				}
			};
		K.onreadystatechange = D;
		if (O) K.send(I);
		else K.send("");
		if (H == false) D();
		return true
	}
	this.setcharset = function(_) {
		if (!$.encode) $.encode = I(_)
	};
	this._1ll1 = function(str) {
		document.write(str)
	};
	this.get = function(C, B, _) {
		return A(C, "", B, "GET", $.async, _)
	};
	this.update = function(H, J, _, D, E) {
		_ = C(_);
		D = C(D);
		if (_ < 1) D = 1;
		var B = function() {
				A(J, "", H, "GET", $.async, E)
			},
			G = F(),
			I = function($) {
				B();
				$--;
				if ($ > 0) M(G, setTimeout(function() {
					I($)
				}, _))
			};
		I(D);
		return G
	};
	this.stopupdate = function($) {
		clearTimeout(H($))
	};
	this.post = function(D, _, C, B) {
		return A(D, _, C, "POST", $.async, B)
	};
	this.postf = function(O, J, B) {
		var H = [],
			L, _, G, I, M, K = arguments.length,
			C = arguments;
		O = O ? D(O) : false;
		if (!O || O.nodeName != "FORM") return false;
		validfoo = O.getAttribute("onvalidate");
		validfoo = validfoo ? (typeof(validfoo) == "string" ? new Function(validfoo) : validfoo) : null;
		if (validfoo && !validfoo()) return false;
		var E = O.getAttribute("action"),
			N = O.getAttribute("method"),
			F = $.formToStr(O);
		if (F.length == 0) return false;
		if (N.toUpperCase() == "POST") return A(E, F, J, "POST", true, B);
		else {
			E += (E.indexOf("?") > -1 ? "&" : "?") + F;
			return A(E, "", J, "GET", true, B)
		}
	};
	this.formToStr = function(C) {
		var B = "",
			E = "",
			_, A;
		for (var D = 0; D < C.length; D += 1) {
			_ = C[D];
			if (_.name != "") {
				switch (_.type) {
				case "select-one":
					if (_.selectedIndex > -1) A = _.options[_.selectedIndex].value;
					else A = "";
					break;
				case "checkbox":
				case "radio":
					if (_.checked == true) A = _.value;
					break;
				default:
					A = _.value
				}
				A = $.encode(A);
				B += E + _.name + "=" + A;
				E = "&"
			}
		}
		return B
	}
}

browserRedirect();
var ajax = new AJAX();
ajax.setcharset("GBK");

function $(id) {
	return document.getElementById(id)
}

function checkAll(bool, tagname, name) {
	var checkboxArray;
	checkboxArray = getElementsByName(tagname, name);
	for (var i = 0; i < checkboxArray.length; i++) {
		checkboxArray[i].checked = bool
	}
}

function checkOthers(tagname, name) {
	var checkboxArray;
	checkboxArray = getElementsByName(tagname, name);
	for (var i = 0; i < checkboxArray.length; i++) {
		if (checkboxArray[i].checked == false) {
			checkboxArray[i].checked = true
		} else if (checkboxArray[i].checked == true) {
			checkboxArray[i].checked = false
		}
	}
}

function textareasize(obj) {
	if (obj.scrollHeight > 70) {
		obj.style.height = obj.scrollHeight + 'px'
	}
}

function set(obj, value) {
	obj.innerHTML = value
}

function view(id) {
	$(id).style.display = 'inline'
}

function hide(id) {
	$(id).style.display = 'none'
}

function getScroll() {
	var t;
	if (document.documentElement && document.documentElement.scrollTop) {
		t = document.documentElement.scrollTop
	} else if (document.body) {
		t = document.body.scrollTop
	}
	return (t)
}

function HtmlEncode(str) {
	var s = "";
	if (str.length == 0) return "";
	s = str.replace(/&/g, "&amp;");
	s = s.replace(/</g, "&lt;");
	s = s.replace(/>/g, "&gt;");
	s = s.replace(/ /g, "&nbsp;");
	s = s.replace(/\'/g, "&#39;");
	s = s.replace(/\"/g, "&quot;");
	return s
}

function getElementsByName(tag, name) {
	var rtArr = new Array();
	var el = document.getElementsByTagName(tag);
	for (var i = 0; i < el.length; i++) {
		if (el[i].name == name) rtArr.push(el[i])
	}
	return rtArr
}

function GetQueryString(name) {
	var reg = new RegExp("(^|-)" + name + "=([^-]*)(-|$)");
	var r = window.location.search.substr(1).match(reg);
	if (r != null) return unescape(r[2]);
	return null;
}

function closeWin() {
	document.body.removeChild($("bg"));
	document.body.removeChild($("msg"));
	if ($("searchtype")) $("searchtype").style.display = "";
}

function openWindow(zindex, width, height, alpha) {
	var iWidth = document.documentElement.scrollWidth;
	var iHeight = document.documentElement.clientHeight;
	var bgDiv = document.createElement("div");
	bgDiv.id = "bg";
	bgDiv.style.cssText = "top:0;width:" + iWidth + "px;height:" + document.documentElement.scrollHeight + "px;filter:Alpha(Opacity=" + alpha + ");opacity:0.3;z-index:" + zindex + ";";
	document.body.appendChild(bgDiv);
	var msgDiv = document.createElement("div");
	msgDiv.id = "msg";
	msgDiv.style.cssText = "z-index:" + (zindex + 1) + ";width:" + width + "px; height:" + (parseInt(height) - 0 + 29 + 16) + "px;left:" + ((iWidth - width - 2) / 2) + "px;top:" + (getScroll() + (height == "auto" ? 150 : (iHeight > (parseInt(height) + 29 + 2 + 16 + 30) ? (iHeight - height - 2 - 29 - 16 - 30) / 2 : 0))) + "px";
	msgDiv.innerHTML = "<div class='msgtitle'><div id='msgtitle'></div><img onclick='closeWin()' src='/" + sitePath + "pic/btn_close.gif' /></div><div id='msgbody' style='height:" + height + "px'></div>";
	document.body.appendChild(msgDiv);
}

function reportErr(id) {
	openWin("/" + sitePath + "js/err.html?id=" + id, 520, 270, 350, 250, "no")
}

function viewComment(url, type) {
	var url;
	url += '&type=' + (type == 'news' ? 2 : 1);
	ajax.get(url, function(obj) {
		if (obj.responseText == "err") {
			set($("comment_list"), "<font color='red'>\u53d1\u751f\u9519\u8bef</font>")
		} else {
			set($("comment_list"), obj.responseText)
		}
	});
}

function submitComment(id) {
	if ($("m_author").value.length < 1) {
		alert('\u8bf7\u586b\u5199\u6635\u79f0');
		return false;
	}
	if ($("m_content").value.length < 1) {
		alert('\u8bf7\u586b\u5199\u5185\u5bb9');
		return false;
	}
	ajax.postf($("f_comment"), function(obj) {
		var x = obj.responseText;
		if (x == "ok") {
			viewComment(id, 1);
			alert('\u5c0f\u5f1f\u6211\u611f\u8c22\u60a8\u7684\u8bc4\u8bba!');
		} else if (x == "havecomment") {
			alert('\u5c0f\u6837\u513f\u4f60\u624b\u4e5f\u592a\u5feb\u4e86\uff0c\u6b47\u4f1a\u513f\u518d\u6765\u8bc4\u8bba\u5427\uff01');
		} else if (x == "cn") {
			alert('\u4f60\u5fc5\u9700\u8f93\u5165\u4e2d\u6587\u624d\u80fd\u53d1\u8868');
		} else {
			alert('\u53d1\u751f\u9519\u8bef');
		}
	});
}

function diggVideo(id, div) {
	ajax.get("/" + sitePath + "inc/ajax.asp?id=" + id + "&action=digg", function(obj) {
		var returnValue = Number(obj.responseText)
		if (!isNaN(returnValue)) {
			set($(div), returnValue);
			alert('(*^__^*) \u563b\u563b\u2026\u2026\uff0c\u9876\u5f97\u6211\u771f\u8212\u670d\uff01');
		} else if (obj.responseText == "err") {
			alert('\u9876\u5931\u8d25')
		} else if (obj.responseText.indexOf("havescore") != -1) {
			alert('(*^__^*) \u563b\u563b\u2026\u2026 \u8fd9\u4e48\u70ed\u5fc3\u554a\uff0c\u60a8\u5df2\u7ecf\u9876\u8fc7\u4e86\uff01')
		}
	});
}

function treadVideo(id, div) {
	ajax.get("/" + sitePath + "inc/ajax.asp?id=" + id + "&action=tread", function(obj) {
		var returnValue = Number(obj.responseText)
		if (!isNaN(returnValue)) {
			set($(div), returnValue);
			alert('\u5c0f\u6837\u513f\uff0c\u5c45\u7136\u6562\u8e29\u6211\uff01');
		} else if (obj.responseText == "err") {
			alert('\u8e29\u5931\u8d25')
		} else if (obj.responseText == "havescore") {
			alert('\u6211\u6655\uff0c\u60a8\u5df2\u7ecf\u8e29\u8fc7\u4e86\uff0c\u60f3\u8e29\u6b7b\u6211\u554a\uff01')
		}
	})
}

function markscore1(vd, d, t, s, l, ac) {
	var alt = ['\u5f88\u5dee', '\u8f83\u5dee', '\u8fd8\u884c', '\u63a8\u8350', '\u529b\u8350'],
		src = ['/' + sitePath + 'pic/xin0.gif', '/' + sitePath + 'pic/xin1.gif'],
		url = ac == 'news' ? ["/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=newsscore", "/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=scorenews&score="] : ["/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=videoscore", "/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=score&score="],
		x = d + t,
		y = d > 5 ? (Math.round(s / d * 100) / 100) : 0,
		id = 'STAR' + (new Date()).getTime();
	document.write('<span id="' + id + '" style="padding:5px;height:15px">');
	for (var i = 1; i <= l; i++) {
		document.write('<img id="' + i + '" src="' + src[i <= y ? 0 : 1] + '" title="' + alt[parseInt(i / l * (alt.length - 1))] + i + '\u5206" style="cursor:pointer;margin-bottom:-3px;">');
	}
	document.write('<strong id="MARK_B3"></strong><span style="background:url(/pic/_score_bg.gif) no-repeat;height:80px; width:80px; display:block; position:absolute;top:-25px;left:320px;" ><i id="MARK_B2"></i><p id="MARK_B4"></p></span></span>');
	var dc = $(id),
		im = dc.getElementsByTagName('img');
	for (var i = 0; i < im.length; i++) {
		im[i].onclick = function() {
			var x = parseInt(this.id);
			ajax.get(url[1] + x, function(obj) {
				if (('' + obj.responseText).indexOf("scores") != -1) {
					alert('\u60a8\u5df2\u7ecf\u8bc4\u8fc7\u5206\u5566');
				} else {
					alert('\u611f\u8c22\u60a8\u7684\u53c2\u4e0e!');
					y = x;
					dc.onmouseout();
				}
			});
		}
		im[i].onmouseover = function() {
			var x = parseInt(this.id)
			for (var i = 0; i < im.length; i++) im[i].src = src[x >= parseInt(im[i].id) ? 0 : 1];
		}
	}
	dc.onmouseout = function() {
		for (var i = 0; i < im.length; i++) im[i].src = src[y >= parseInt(im[i].id) ? 0 : 1];
		$('MARK_B2').innerHTML = (y >= 1 && y < 10) ? y.toFixed(1) : y < 1 ? '0.0' : y.toFixed(0);
		$('MARK_B3').innerHTML = y > 0 ? alt[parseInt(y / l * (alt.length - 1))] : '\u4eba\u6570\u5c11';
		$('MARK_B4').innerHTML = (y >= 1 && y < 10) ? y.toFixed(1) : y < 1 ? '0.0' : y.toFixed(0);
	}
	if (new Date().toGMTString() != new Date(document.lastModified).toGMTString()) return ajax.get(url[0], function(obj) {
		var a = obj.responseText
		try {
			a.replace(/\[(\d+),(\d+),(\d+)\]/i, function($0, d, t, s) {
				var x = parseInt(d) + parseInt(t);
				y = d > 5 ? (Math.round(parseInt(s) / x * 100) / 100) : 0;
				dc.onmouseout();
			});
		} catch (ig) {}
	});
	dc.onmouseout();
}

function markscore2(vd, d, t, s, l, ac) {
	var alt = ['\u5f88\u5dee', '\u8f83\u5dee', '\u8fd8\u884c', '\u63a8\u8350', '\u529b\u8350'],
		src = ['/' + sitePath + 'pic/star0.gif', '/' + sitePath + 'pic/star1.gif'],
		url = ac == 'news' ? ["/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=newsscore", "/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=scorenews&score="] : ["/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=videoscore", "/" + sitePath + "inc/ajax.asp?id=" + vd + "&action=score&score="],
		x = d + t,
		y = (Math.round(s / x * 100) / 100) || 0,
		id = 'STAR' + (new Date()).getTime(),
		z = y * 10;
	document.write('<span id="' + id + '" style="height:14px;line-height:14px;">');
	document.write('<span style="text-align:left;background: url(/xcimg/star_num2.gif) no-repeat 0px -25px; width: 60px;display: inline-block; height:16px;line-height:16px"><span style="background: url(/xcimg/star_num2.gif) no-repeat 0px -1px; width: ' + z + '%; height:18px;line-height:18px;display: inline-block;vertical-align:middle;"></span></span>');
	document.write('&nbsp;<span style="color:#f60;font-size:14px;line-height:12px;height:12px;font-family:Tahoma, Arial, Helvetica, sans-serif;" id="MARK_B' + vd + '"></span></span>');
	var dc = $(id),
		im = dc.getElementsByTagName('img');
	for (var i = 0; i < im.length; i++) {
		im[i].onclick = function() {
			var x = parseInt(this.id);
			ajax.get(url[1] + x, function(obj) {
				if (('' + obj.responseText).indexOf("havescore") != -1) {
					alert('\u4f60\u5df2\u7ecf\u8bc4\u8fc7\u5206\u5566');
				} else {
					alert('\u611f\u8c22\u4f60\u7684\u53c2\u4e0e!');
					y = x;
					dc.onmouseout();
				}
			});
		}
	}
	dc.onmouseout = function() {
		for (var i = 0; i < im.length; i++) im[i].src = src[y >= parseInt(im[i].id) ? 0 : 1];
		$('MARK_B' + vd + '').innerHTML = (y >= 1 && y < 10) ? y.toFixed(1) : y < 1 ? '1.0' : y.toFixed(0);
		$('MARK)_B3').innerHTML = y > 0 ? alt[parseInt(y / l * (alt.length - 1))] : '评分';
	}
	if (new Date().toGMTString() != new Date(document.lastModified).toGMTString()) return ajax.get(url[0], function(obj) {
		var a = obj.responseText
		try {
			a.replace(/\[(\d+),(\d+),(\d+)\]/i, function($0, d, t, s) {
				var x = parseInt(d) + parseInt(t);
				y = (Math.round(parseInt(s) / x * 100) / 100) || 0;
				dc.onmouseout();
			});
		} catch (ig) {}
	});
	dc.onmouseout();
}

function markVideo(vd, d, t, s, l, c) {
	window['markscore' + (c == '' ? 0 : c)](vd, d, t, s, parseInt(l) < 0 ? 5 : l);
}

function getVideoHit(vid) {
	ajax.get("/" + sitePath + "inc/ajax.asp?action=hit&id=" + vid, function(obj) {
		var result = obj.responseText
		if (result == "err") {
			set($('hit'), '\u53d1\u751f\u9519\u8bef')
		} else {
			set($('hit'), result);
		}
	});
}

function getNewsHit(nid) {
	ajax.get("/" + sitePath + "inc/ajax.asp?action=hitnews&id=" + nid, function(obj) {
		var result = obj.responseText
		if (result == "err") {
			set($('hit'), '\u53d1\u751f\u9519\u8bef')
		} else {
			set($('hit'), result);
		}
	});
}

function diggNews(id, div) {
	ajax.get("/" + sitePath + "inc/ajax.asp?id=" + id + "&action=diggnews", function(obj) {
		var returnValue = Number(obj.responseText)
		if (!isNaN(returnValue)) {
			set($(div), returnValue);
			alert('(*^__^*) \u563b\u563b\u2026\u2026\uff0c\u9876\u5f97\u6211\u771f\u8212\u670d\uff01');
		} else if (obj.responseText == "err") {
			alert('\u9876\u5931\u8d25')
		} else if (obj.responseText == "havescore") {
			alert('(*^__^*) \u563b\u563b\u2026\u2026 \u8fd9\u4e48\u70ed\u5fc3\u554a\uff0c\u60a8\u5df2\u7ecf\u9876\u8fc7\u4e86\uff01')
		}
	});
}

function treadNews(id, div) {
	ajax.get("/" + sitePath + "inc/ajax.asp?id=" + id + "&action=treadnews", function(obj) {
		var returnValue = Number(obj.responseText)
		if (!isNaN(returnValue)) {
			set($(div), returnValue);
			alert('\u5c0f\u6837\u513f\uff0c\u5c45\u7136\u6562\u8e29\u6211\uff01');
		} else if (obj.responseText == "err") {
			alert('\u8e29\u5931\u8d25')
		} else if (obj.responseText == "havescore") {
			alert('\u6211\u6655\uff0c\u60a8\u5df2\u7ecf\u8e29\u8fc7\u4e86\uff0c\u60f3\u8e29\u6b7b\u6211\u554a\uff01')
		}
	});
}

function markNews(vd, d, t, s, l, c) {
	window['markscore' + (c == 1 ? 1 : 0)](vd, d, t, s, parseInt(l) < 0 ? 5 : l, 'news');
}

function alertFrontWin(zindex, width, height, alpha, str) {
	openWindow(zindex, width, height, alpha)
	set($("msgbody"), str)
}

function regexpSplice(url, pattern, spanstr) {
	pattern.exec(url);
	return (RegExp.$1 + spanstr + RegExp.$2);
}

function getPageValue(pageGoName) {
	var pageGoArray, i, len, pageValue
	pageGoArray = getElementsByName('input', pageGoName);
	len = pageGoArray.length
	for (i = 0; i < len; i++) {
		pageValue = pageGoArray[i].value;
		if (pageValue.length > 0) {
			return pageValue;
		}
	}
	return ""
}

function getPageGoUrl(maxPage, pageDiv, surl) {
	var str, goUrl
	var url = location.href
	pageNum = getPageValue(pageDiv)
	if (pageNum.length == 0 || isNaN(pageNum)) {
		alert('输入页码非法');
		return false;
	}
	if (pageNum > maxPage) {
		pageNum = maxPage;
	}
	pageNum = pageNum < 1 || pageNum == 1 ? '' : pageNum;
	location.href = surl.replace('<page>', pageNum).replace('-.', '.').replace('_.', '.').replace(/\?\.\w+/i, '');
}

function getPageGoUrl2(maxPage, pageDiv, surl) {
	var str, goUrl
	var url = location.href
	pageNum = getPageValue(pageDiv)
	if (pageNum.length == 0 || isNaN(pageNum)) {
		alert('输入页码非法');
		return false;
	}
	if (pageNum > maxPage) {
		pageNum = maxPage;
	}
	pageNum = pageNum < 1 ? 1 : pageNum;
	goUrl = surl.replace(maxPage + '.html', '') + pageNum + '.html';
	location.href = goUrl;
}

function goSearchPage(maxPage, pageDiv, surl) {
	getPageGoUrl(maxPage, pageDiv, surl);
}

function leaveWord() {
	if ($("m_author").value.length < 1) {
		alert('昵称必须填写');
		return false;
	}
	if ($("m_content").value.length < 1 || $("m_content").value == "\u8bf7\u5728\u6b64\u8f93\u5165\u7559\u8a00\uff0c\u60a8\u7684\u7559\u8a00\u5c06\u5728\u5ba1\u6838\u540e\u663e\u793a\uff0c\u8bf7\u6587\u660e\u53d1\u8a00\uff01") {
		alert('\u60a8\u8fd8\u6ca1\u8f93\u5165\u7559\u8a00\uff0c\u8bf7\u586b\u5199\u7559\u8a00\uff01');
		return false;
	}
	ajax.postf($("f_leaveword"), function(obj) {
		var x = obj.responseText;
		if (x == "ok") {
			viewLeaveWordList(1);
			alert('\u7559\u8a00\u6210\u529f\uff0c\u591a\u8c22\u652f\u6301\uff01\u5c06\u5728\u5ba1\u6838\u540e\u663e\u793a');
			$("m_content").value = '';
		} else if (x == "haveleave") {
			alert('\u5c0f\u6837\u513f\u4f60\u624b\u4e5f\u592a\u5feb\u4e86\uff0c\u6b47\u4f1a\u513f\u518d\u6765\u7559\u8a00\u5427\uff01');
		} else if (x == "haveleave") {
			alert('\u5c0f\u6837\u513f\u4f60\u624b\u4e5f\u592a\u5feb\u4e86\uff0c\u6b47\u4f1a\u513f\u518d\u6765\u7559\u8a00\u5427\uff01');
		} else if (x == "haveleave") {
			alert('\u5c0f\u6837\u513f\u4f60\u624b\u4e5f\u592a\u5feb\u4e86\uff0c\u6b47\u4f1a\u513f\u518d\u6765\u7559\u8a00\u5427\uff01');
		} else if (x == "cn") {
			alert('\u4f60\u5fc5\u9700\u8f93\u5165\u4e2d\u6587\u624d\u80fd\u53d1\u8868');
		} else {
			alert('\u53d1\u751f\u9519\u8bef');
		}
	});
}

function viewLeaveWordList(page) {
	view('leavewordlist');
	ajax.get("/" + sitePath + "gbook.asp?action=list&page=" + page + "&t=" + (new Date()).getTime(), function(obj) {
		if (obj.responseText == "err") {
			set($("leavewordlist"), "<font color='red'>发生错误</font>")
		} else {
			set($("leavewordlist"), obj.responseText)
		}
	});
}

function loginLeaveWord() {
	if ($("m_username").value.length < 1 || $("m_pwd").value.length < 1) {
		alert('用户名密码不能为空');
		return false;
	}
	ajax.postf($("f_loginleaveword"), function(obj) {
		if (obj.responseText == "ok") {
			closeWin();
			alert('登陆成功');
			setLoginState();
			viewLeaveWordList(1);
		} else if (obj.responseText == "no") {
			alert('用户名或密码不正确');
		} else if (obj.responseText == "err") {
			alert('发生错误');
		} else {
			setLoginState();
		}
	});
}

function setLoginState() {
	ajax.get("/" + sitePath + "gbook.asp?action=state", function(obj) {
		set($('adminleaveword'), obj.responseText);
	});
}

function logOut() {
	ajax.get("/" + sitePath + "gbook.asp?action=logout", function(obj) {
		set($('adminleaveword'), '成功退出');
	});
	setLoginState();
	viewLeaveWordList(1);
}

function delLeaveWord(id, page, type) {
	ajax.get("/" + sitePath + "gbook.asp?action=del&id=" + id + "&type=" + type, function(obj) {
		if (obj.responseText == "ok") {
			viewLeaveWordList(page)
		} else if (obj.responseText == "err") {
			alert('发生错误')
		} else {
			viewLeaveWordList(page);
		}
	});
}

function replyLeaveWord(id, page) {
	alertFrontWin(101, 400, 160, 50, "")
	set($("msgtitle"), "回复留言")
	set($("msgbody"), "<form id='replyleaveword'  action='/" + sitePath + "gbook.asp?action=reply&id=" + id + "' method='post'><div><textarea id='m_replycontent'  name='m_replycontent' rows=7 cols=50></textarea><br><input type='button' value='回  复' onclick='submitReply(" + page + ")' class='btn' /> &nbsp;<span style='background-color:#CCCCCC;cursor:pointer;' onclick=$('m_replycontent').value+='[URL][/URL]'><b>[URL]</b></span></div></form>")
}

function viewLoginState() {
	alertFrontWin(101, 300, 100, 50, "")
	set($("msgtitle"), "登陆留言板")
	set($("msgbody"), "<form id='f_loginleaveword'  action='/" + sitePath + "gbook.asp?action=login' method='post'  ><table><tr><td>用户名：</td><td><input type='input'  name='m_username' id='m_username' size=10 value=''/></td></tr><tr><td><input type='hidden' value='ok' name='m_login' />密码：</td><td><input type='password' id='m_pwd' name='m_pwd' size=10 value=''/></td></tr><tr><td><input type='submit' value='登  陆' class='btn'  onclick='loginLeaveWord();return false;'  /></td></tr></table></form>")
}

function submitReply(page) {
	if ($("m_replycontent").value.length < 1) {
		alert('\u56de\u590d\u4e0d\u80fd\u4e3a\u7a7a');
		return false;
	}
	ajax.postf($("replyleaveword"), function(obj) {
		if (obj.responseText == "ok") {
			closeWin();
			viewLeaveWordList(page)
		} else if (obj.responseText == "err") {
			alert('\u53d1\u751f\u9519\u8bef4');
		} else {
			viewLeaveWordList(page);
		}
	});
}

function addFace(id) {
	$('m_content').value += '[ps:' + id + ']';
}

function openWin(url, w, h, left, top, resize) {
	window.open(url, '_blank', 'toolbars=no,scrollbars=yes,location=no,statusbars=no,menubars=no,resizable=' + resize + ',width=' + w + ',height=' + h + ',left=' + left + ',top=' + top);
}

function copyToClipboard(txt) {
	if (window.clipboardData) {
		window.clipboardData.clearData();
		window.clipboardData.setData("Text", txt);
		alert('\u590d\u5236\u6210\u529f\uff01')
	} else if (navigator.userAgent.indexOf("Opera") != -1) {
		window.location = txt;
		alert("\u590d\u5236\u6210\u529f\uff01");
	} else {
		alert('\u6d4f\u89c8\u5668\u4e0d\u652f\u6301\uff0c\u8bf7\u624b\u52a8\u590d\u5236\uff01')
	}
}

function getUrlArgs() {
	return location.pathname;
}

function setCookie(name, value, ihour) {
	var iH = ihour || 1;
	var exp = new Date;
	exp.setTime(exp.getTime() + iH * 60 * 60 * 1000);
	document.cookie = name + ("=" + escape(value) + ";expires=" + exp.toGMTString() + ";path=/;");
}

function getCookie(name) {
	var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
	if (arr != null) {
		return unescape(arr[2]);
	}
	return null;
}

function isMouseLeaveOrEnter(e, handler) {
	if (e.type != 'mouseout' && e.type != 'mouseover') return false;
	var reltg = e.relatedTarget ? e.relatedTarget : e.type == 'mouseout' ? e.toElement : e.fromElement;
	while (reltg && reltg != handler) {
		reltg = reltg.parentNode;
	}
	return (reltg != handler);
}