function showxg() {
	if (zknum == 1) {
		$("xg").style.height = "auto";
		$("zk").className = "zkhover";
		zknum = 2
	} else {
		$("xg").style.height = "26px";
		$("zk").className = "zk";
		zknum = 1
	}
};
if ($("xg").offsetHeight > 38) {
	view("zk");
	$("xg").style.height = "26px";
	var zknum = 1
};
if ($("xg").getElementsByTagName("a").length > 1) {
	$("xgcolor").style.color = "#f60"
};
