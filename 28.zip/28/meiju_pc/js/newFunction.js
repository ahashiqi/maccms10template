//document.write('<script src="http://apps.bdimg.com/libs/jquery/1.7.2/jquery.min.js"></sc'+'ript>');
if(typeof(sitePath)=="undefined"){var sitePath=""}
//if(typeof(window.jQuery)=="undefined"){document.write('<script src="/'+sitePath+'js/jquery.min.js"></sc'+'ript>');}

function reportErr(id){openWin("/"+sitePath+"js/err.html?id="+id,400,220,350,250,0)}

function viewComment(url,type){
	var url;
	url+='&type='+(type=='news' ? 2 : 1);
	$.get(url,function(obj) {
			if (obj=="err"){
				$("#comment_list").html("<font color='red'>发生错误</font>");
			}else{
				$("#comment_list").html(obj)
			}
		}
	);		
}

function diggVideo(id,div){
	$.get(
		"/"+sitePath+"inc/ajax.asp?id="+id+"&action=digg",function (obj){
			var returnValue=Number(obj)
			if (!isNaN(returnValue)){$('#'+div).html(returnValue);alert('(*^__^*) 嘻嘻……，顶得我真舒服！');}else if(obj=="err"){alert('顶失败')}else if(obj=="havescore"){alert('(*^__^*) 嘻嘻…… 这么热心啊，您已经顶过了！')}	
		}
	);
}

function treadVideo(id,div){
	$.get("/"+sitePath+"inc/ajax.asp?id="+id+"&action=tread",function (obj){
			var returnValue=Number(obj)
			if(!isNaN(returnValue)){$('#'+div).html(returnValue);alert('小样儿，居然敢踩我！');}else if(obj=="err"){alert('踩失败')}	else if(obj=="havescore"){alert('我晕，您已经踩过了，想踩死我啊！')}	
		}
	)
}
function markscore0(vd,d,t,s,l,ac,s1,s2,s3,s4,s5){
	var alt=['烂剧','腐剧','一般','佳作','神剧'],url=ac=='news' ? ["/"+sitePath+"inc/ajax.asp?id="+vd+"&action=newsscore","/"+sitePath+"inc/ajax.asp?id="+vd+"&action=scorenews&score="] : ["/"+sitePath+"inc/ajax.asp?id="+vd+"&action=videoscore","/"+sitePath+"inc/ajax.asp?id="+vd+"&action=score&score="],
	x=d+t,y=(Math.round(s / x * 100) / 100) || 0,id='BT'+(new Date()).getTime();
	document.write('<div style="padding:5px 10px;border:1px solid #CCC">\
			<div style="color:#000"><strong>我来评分(请您参与评分，体现您的观点)</strong></div>\
			<div>共 <strong style="font-size:14px;color:red" id="total-digg"> '+x+' </strong> 个人评分， 平均分 <strong style="font-size:14px;color:red" id="average-score"> '+y+' </strong>， 总得分 <strong style="font-size:14px;color:red" id="total-score"> '+s+' </strong></div>\
			<div>');
	for(var i=0;i<=l;i++) document.write('<input type="radio" name="score" id="sint'+i+'" value="1" title="'+alt[parseInt(i/l*(alt.length-1))]+'" \/><label for="sint'+i+'">'+i+'<\/label>');
	document.write('&nbsp;<input type="button" value=" 评 分 " id="'+id+'" style="width:55px;height:21px"/>\
			</div>\
		</div>');
	$('#'+id).click(function(){
		var i=0;
		$("input[name='score']").each(function(index) {
            if($(this).is(":checked")){
				i=index;return false;
			}
        });
		if(i>l){alert('你还没选取分数');return;}
		$.get(url[1]+i,function (obj){
			if(('#'+obj).indexOf("havescore")!=-1){
				alert('你已经评过分啦');
			}else{
				s+=i;
				$('#total-digg').html(++x);
				$('#average-score').html(parseInt(s / x * 100) / 100 || 0);
				$('#total-score').html(s);
				alert('感谢你的参与!');
			}
		});
		this.disabled=true;
	})
	if(new Date().toGMTString()!=new Date(document.lastModified).toGMTString()) return $.get(url[0],function (obj){
		var a=obj
		try{
			a.replace(/\[(\d+),(\d+),(\d+)\]/i,function ($0,d,t,s){
				var x=parseInt(d)+parseInt(t),y=(Math.round(parseInt(s) / x * 100) / 100) || 0;
				$('#total-digg').html(x);
				$('#average-score').html(y);
				$('#total-score').html(s);
			});
		}catch(ig){}
	});
}

function markscore1(vd,d,t,s,l,ac,s1,s2,s3,s4,s5){
	var alt=['烂剧','腐剧','一般','佳作','神剧'],url=ac=='news' ? ["/"+sitePath+"inc/ajax.asp?id="+vd+"&action=newsscore","/"+sitePath+"inc/ajax.asp?id="+vd+"&action=scorenews&score="] : ["/"+sitePath+"inc/ajax.asp?id="+vd+"&action=videoscore","/"+sitePath+"inc/ajax.asp?id="+vd+"&action=score&score="],
	x=d+t,y=(Math.round(s / x * 100) / 100) || 0,id='STAR'+(new Date()).getTime();
	document.write('<div id="'+id+'" class="mark-star"><div id="star-bg"></div><div id="score-len"></div><div id="score-list">');
	for(var i=1;i<=l;i++){
		document.write('<a id="'+i+'" title="'+alt[parseInt(i/l*(alt.length-1))]+'"><\/a>');
	}
	document.write('</div><strong id="average-score"></strong><span class="y0">.0</span>分<span id="score-alt"></span>(有<span id="total-digg">'+x+'</span>人评分)</div>');
	var dc=$('#'+id),stars=dc.find('a');
	var starBG=$("#score-len");
	stars.click(function(){
		var x=$(this).attr("id");
		$.get(url[1]+x,function (obj){
			if((''+obj).indexOf("havescore")!=-1){
				alert('你已经评过分啦');
			}else{
				alert('感谢你的参与!');
				$('#total-digg').text(parseInt($('#total-digg').text())+1);
				y=parseInt(Math.round((parseInt(s)+parseInt(y)) / (parseInt(d)+parseInt(t)+1) * 100) / 100) || 0;
				$('#average-score').html(y);
				$('#score-alt').html(y>0 ? alt[parseInt(y/l*(alt.length-1))] : '暂无');
				dc.mouseout();
			}
		});
	});
	stars.mouseover(function (){
		starBG[0].className="s"+$(this).attr("id");
		$('#average-score').html($(this).attr("id"));
		$('#score-alt').html(alt[parseInt(($(this).attr("id")-1)/2)]);
	})
	dc.mouseout(function (){
		for(var i=0;i<stars.length;i++){if(y>0){starBG[0].className="s"+parseInt(y);}else{starBG[0].className="s0";}}
		$('#average-score').html(parseInt(y));
		$('#score-alt').html(y>0 ? alt[parseInt(y/l*(alt.length-1))] : '暂无');
	});
	if(new Date().toGMTString()!=new Date(document.lastModified).toGMTString()) return $.get(url[0],function (obj){
		var a=obj;
		try{
			a.replace(/\[(\d+),(\d+),(\d+)\]/i,function ($0,d,t,s){
				var x=parseInt(d)+parseInt(t);y=(Math.round(parseInt(s) / x * 100) / 100) || 0;
				$('#total-digg').html(x);
				dc.mouseout();
			});
		}catch(ig){}
	});
	dc.mouseout();
}

function markscore2(vd,d,t,s,l,ac,s1,s2,s3,s4,s5){
	//l=5;
	var alt=['烂剧','腐剧','一般','佳作','神剧'],url=["/"+sitePath+"inc/ajax.asp?id="+vd+"&action=newstarscorevideo","/"+sitePath+"inc/ajax.asp?id="+vd+"&action=newstarscore"],
	id='STAR'+(new Date()).getTime();
	document.write('<div id="'+id+'" class="mark-star"><div id="star-bg"></div><div id="score-len"></div><div id="score-list">');
	for(var i=1;i<=l;i++){
		document.write('<a id="'+i+'" title="'+alt[parseInt(i/l*(alt.length-1))]+'"><\/a>');
	}
	document.write('</div><span id="score-alt"></span></div>');
	$(function(){
		var totalStar,totalDigg,averageStar,totalStarScore,averageStarScore,x,starArray,dc,stars,starBG
		if(new Date().toGMTString()!=new Date(document.lastModified).toGMTString()){//static OR forgedStatic 
			$.get(url[0],function (data){
				try{
					data.replace(/\[(\d+),(\d+),(\d+),(\d+),(\d+)\]/i,function ($0,s1,s2,s3,s4,s5){
						totalStar=parseInt(s1)+parseInt(s2)*2+parseInt(s3)*3+parseInt(s4)*4+parseInt(s5)*5;
						totalDigg=parseInt(s1)+parseInt(s2)+parseInt(s3)+parseInt(s4)+parseInt(s5);
						averageStar=Math.round(totalStar/totalDigg)||0;
						totalStarScore=parseInt(s1)*2+parseInt(s2)*4+parseInt(s3)*6+parseInt(s4)*8+parseInt(s5)*10;
						averageStarScore=totalStarScore/totalDigg||0;
						x=999;
						starArray=[s1,s2,s3,s4,s5];
						dc.mouseout();
					});
				}catch(ig){}
			});
		}
		totalStar=parseInt(s1)+parseInt(s2)*2+parseInt(s3)*3+parseInt(s4)*4+parseInt(s5)*5;
		totalDigg=parseInt(s1)+parseInt(s2)+parseInt(s3)+parseInt(s4)+parseInt(s5);
		averageStar=Math.round(totalStar/totalDigg)||0;
		totalStarScore=parseInt(s1)*2+parseInt(s2)*4+parseInt(s3)*6+parseInt(s4)*8+parseInt(s5)*10;
		averageStarScore=totalStarScore/totalDigg||0;
		x=999;
		starArray=[s1,s2,s3,s4,s5];
		dc=$('#'+id);
		stars=dc.find('a');
		starBG=$("#score-len");
		stars.click(function(){
			x=$(this).attr("id");
			$.get(
				url[1]+"&star="+x,
				function (obj){
					if((''+obj).indexOf("havescore")!=-1){
						alert('你已经评过分啦');
						x=999;
					}else{
						alert('感谢你的参与!');
						totalStar=totalStar+parseInt(x);
						totalDigg=totalDigg+1;
						averageStar=Math.round(totalStar/totalDigg)||0;
						averageStarScore=(totalStarScore+x*2)/totalDigg;
						dc.mouseout();
					}
			});
		});
		stars.mouseover(function (){
			starBG[0].className="s"+$(this).attr("id");
			//$('#score-alt').html(alt[parseInt(($(this).attr("id")-1)/2)]);
			$('#score-alt').html(alt[parseInt($(this).attr("id")-1)]);
		})
		dc.mouseout(function (){
			averageStarScore=(""+averageStarScore).indexOf(".")!=-1?(""+averageStarScore).substring(0,3):averageStarScore;
			$("#score-len")[0].className=averageStar>0?"s"+averageStar:"s0";
			$('#average-score,#average-score-shadow').html(averageStarScore);
			$("#schedule-score").animate({width:(averageStarScore*10)+'%'},"slow",function(){
				var w=$("#schedule-score").outerWidth(true);
				if(averageStarScore>0){
					$("#average-score-box").css("z-index",1000).animate({left:w-$("#average-score-box").width()+18});
				}else{
					$("#average-score-box").animate({left:"-100px"}).css("z-index",-100);
				}
			});
			var tmpArray=[];
			$(starArray).each(function(i,v) {
				var tmp;
				if(i==parseInt(x)-1){
					tmp=parseInt(v)+1;
					x=999;
				}else{
					tmp=v
				}
				$("#small-total-star"+(i+1)).text(tmp);
				$("#score-small-schedule"+(i+1)).animate({width:parseInt(tmp/totalDigg*100)+'%'},"slow");
				tmpArray.push(tmp);
			});
			starArray=tmpArray;
			$('#score-alt').html(averageStar>0 ? alt[parseInt(averageStar/l*(alt.length-1))] : '暂无');
		});
		dc.mouseout();
		$("#score-bar,#score-stars").hover(function(){
			var p=$("#score-bar").offset();
			$("#score-stars").css({top:p.top,left:p.left+2}).show();
		},function(){
			$("#score-stars").hide();
		});
	})
}

function markVideo(vd,d,t,s,l,c,s1,s2,s3,s4,s5){
	window['markscore'+(c==0 ? 0 : c==1?1:2)](vd,d,t,s,parseInt(l)<0 ? 5 : l,c==0 ? 0 : c==1?1:2,s1,s2,s3,s4,s5);
}

function getVideoHit(vid){
	$.get("/"+sitePath+"inc/ajax.asp?action=hit&id="+vid,function (obj){
			var result=obj;
			if(result=="err"){$('#hit').html('发生错误')}else{$('#hit').html(result);}
		}
	);				
}

function getNewsHit(nid){
	$.get("/"+sitePath+"inc/ajax.asp?action=hitnews&id="+nid,function (obj){
			var result=obj;
			if(result=="err"){$('#hit').html('发生错误')}else{$('#hit').html(result);}
		}
	);	
}

function diggNews(id,div){
	$.get("/"+sitePath+"inc/ajax.asp?id="+id+"&action=diggnews",function (obj){
			var returnValue=Number(obj)
			if (!isNaN(returnValue)){$('#'+div).html(returnValue);alert('(*^__^*) 嘻嘻……，顶得我真舒服！');}else if(obj=="err"){alert('顶失败')}else if(obj=="havescore"){alert('(*^__^*) 嘻嘻…… 这么热心啊，您已经顶过了！')}	
		}
	);
}

function treadNews(id,div){
	ajax.get("/"+sitePath+"inc/ajax.asp?id="+id+"&action=treadnews",function (obj){
			var returnValue=Number(obj.responseText)
			if(!isNaN(returnValue)){$('#'+div).html(returnValue);alert('小样儿，居然敢踩我！');}else if(obj=="err"){alert('踩失败')}	else if(obj=="havescore"){alert('我晕，您已经踩过了，想踩死我啊！')}	
		}
	);
}

function markNews(vd,d,t,s,l,c,s1,s2,s3,s4,s5){
	window['markscore'+(c==1 ? 1 : 0)](vd,d,t,s,parseInt(l)<0 ? 5 : l,'news',s1,s2,s3,s4,s5);
}

function alertFrontWin(zindex,width,height,alpha,str){
	openWindow(zindex,width,height,alpha)
	$("#msgbody").html(str)
}

function getPageValue(pageGoName){
	var pageValue="";
	$("input[name='"+pageGoName+"']").each(function(index, element) {
		if($(this).val().length>0){pageValue=$(this).val();return false;}
    });
	return pageValue
}

function getPageGoUrl(maxPage,pageDiv,surl){
	var str,goUrl
	var url=location.href
	pageNum=getPageValue(pageDiv)
	if (pageNum.length==0||isNaN(pageNum)){alert('输入页码非法');return false;}
	if(pageNum>maxPage){pageNum=maxPage;}
	pageNum=pageNum<1 || pageNum==1 ? '' : pageNum;
	location.href=surl.replace('<page>',pageNum).replace('-.','.').replace('_.','.').replace(/\?\.\w+/i,'');
}

function goSearchPage(maxPage,pageDiv,surl){
	var str,goUrl
	var url=location.href
	pageNum=getPageValue(pageDiv)
	if (pageNum.length==0||isNaN(pageNum)){alert('输入页码非法');return false;}
	if(pageNum>maxPage){pageNum=maxPage;}
	pageNum=pageNum<1 || pageNum==1 ? '' : pageNum;
	location.href=surl.replace('<page>',pageNum);
}

function leaveWord(){
	if($("#m_author").val().length<1){alert('昵称必须填写');return false;}
	if($("#m_content").val().length<1){alert('内容必须填写');return false;}
	var content=fromatAjaxParam($("#m_content").val()),author=fromatAjaxParam($("#m_author").val());
	$.post($("#f_leaveword").attr("action"),{"m_content":content,"m_author":author},function(obj){
		var x=obj;
		if(x=="ok"){
			//viewLeaveWordList(1);
			alert('留言成功！在管理员审核回复前，您的留言呈不可见状态，请不必重复留言，管理员会在第一时间对您的留言进行回复，感谢您的支持！');$("#m_content").val('');
		}else if(x=="haveleave"){
			alert('小样儿你手也太快了，歇会儿再来留言吧！');
		}else if(x=="haveleave"){
			alert('小样儿你手也太快了，歇会儿再来留言吧！');
		}else if(x=="cn"){
			alert('你必需输入中文才能发表');
		}else{
			alert('发生错误');
		}
	});
}



function loginLeaveWord(){
	if($("#m_username").val().length<1||$("#m_pwd").val().length<1){alert('用户名密码不能为空');return false;}
	var username=fromatAjaxParam($("#f_loginleaveword").val()),pwd=fromatAjaxParam($("#m_pwd").val());
	$.post(
		$("#f_loginleaveword").attr("action"),
		{"m_username":username,"m_pwd":pwd,"m_login":$("#m_login").val()},
		function(obj){if(obj=="ok"){closeWin();alert('登陆成功');setLoginState();viewLeaveWordList(1);}else if(obj=="no"){alert('用户名或密码不正确');}else if(obj=="err"){alert('发生错误');}else{setLoginState();}}
	);
}










function submitReply(page){
	if($("#m_replycontent").val().length<1){alert('回复不能为空');return false;}
	var replycontent=fromatAjaxParam($("#m_replycontent").val());
	$.post($("#replyleaveword").attr("action"),{"m_replycontent":replycontent},function(obj){if(obj=="ok"){closeWin();viewLeaveWordList(page)}else if(obj=="err"){alert('发生错误4');}else{viewLeaveWordList(page);}});
}

function addFavorite(sURL, sTitle){
	try{ window.external.addFavorite(sURL, sTitle);}
		catch (e){
			try{window.sidebar.addPanel(sTitle, sURL, "");}
			catch (e)
				{alert("加入收藏失败，请使用Ctrl+D进行添加");}
	}
}

function setHome(obj,vrl,url){
    try{obj.style.behavior='url(#default#homepage)';obj.setHomePage(vrl);
	this.style.behavior='url(#default#homepage)';this.setHomePage(url);}
        catch(e){
            if(window.netscape){
                try{netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect");}  
                   catch (e){alert("此操作被浏览器拒绝！请手动设置");}
                   var prefs = Components.classes['@mozilla.org/preferences-service;1'].getService(Components.interfaces.nsIPrefBranch);
                   prefs.setCharPref('browser.startup.homepage',vrl);
             }
      }
}

function addFace(id) {
	$('#m_content').val($('#m_content').val()+'[ps:' + id +']');
}

function getScroll() {
    var t;
    if (document.documentElement && document.documentElement.scrollTop) {
        t = document.documentElement.scrollTop
    } else if (document.body) {
        t = document.body.scrollTop
    }
    return (t)
}

function openWin(url,w,h,left,top,resize){
	window.open(url,'New_Win','toolbars=0, scrollbars=0, location=0, statusbars=0,menubars=0, resizable='+(resize)+',width='+w+',height='+h+',left='+left+',top='+top);
}

function closeWin(){
	document.body.removeChild($("#bg")[0]); 
	document.body.removeChild($("#msg")[0]);
	if($("#searchtype"))$("#searchtype").hide();
}

function openWindow(zindex,width,height,alpha){
	var iWidth = document.documentElement.scrollWidth; 
	var iHeight = document.documentElement.clientHeight; 
	var bgDiv = document.createElement("div");
	bgDiv.id="bg";
	bgDiv.style.cssText = "top:0;width:"+iWidth+"px;height:"+document.documentElement.scrollHeight+"px;filter:Alpha(Opacity="+alpha+");opacity:0.3;z-index:"+zindex+";";
	document.body.appendChild(bgDiv); 
	var msgDiv=document.createElement("div");
	msgDiv.id="msg";
	msgDiv.style.cssText ="z-index:"+(zindex+1)+";width:"+width+"px; height:"+(parseInt(height)-0+29+16)+"px;left:"+((iWidth-width-2)/2)+"px;top:"+(getScroll()+(height=="auto"?150:(iHeight>(parseInt(height)+29+2+16+30)?(iHeight-height-2-29-16-30)/2:0)))+"px";
	msgDiv.innerHTML="<div class='msgtitle'><div id='msgtitle'></div><img onclick='closeWin()' src='/"+sitePath+"pic/btn_close.gif' /></div><div id='msgbody' style='height:"+height+"px'></div>";
	document.body.appendChild(msgDiv);
}

function fromatAjaxParam(str){
	str=escape(str);
	str=str.replace(/\+/g,"%u002B");
	return str
}