

var __Ox5ad01 = [
    "/open.thunderurl.com/thunder-link.js",
    "click",
    "input[type='text']",
    "find",
    "li",
    "parent",
    "val",
    "each",
    "text",
    ".text",
    "download folder",
    "newTask",
    "input[name^='down_url_']",
    "parent",
    "length",
    "parent",
    "children",
    "input[name='checkall']",
    "li input[name='checkbox']",
    "li input[type='checkbox']",
    ".download",
    "msg",
    "li .download_url",
    "li input[type='checkbox']",
    ":checked",
    ".download_all",
    ":checkbox",
    "push",
    ".download_url_list",
    "val",
    "action/x-thunder-download",
    "width",
    "height",
    "appendChild",
    "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000",
    "application/x-thunder-download",
    "width",
    "height",
    "append",
    "click",
    "getSelect",
    "success",
    "复制地址成功",
    "each",
    ".Copyurl",
    "data-text",
    "title",
    "click",
    "getSelect",
    "success",
    "复制地址成功"
];

$(function() {
    $(__Ox5ad01[0]).click(function() {
        $(__Ox5ad01[11]).parent().val($(this).parent().find(__Ox5ad01[2]).val());
        var url = $(this).parent().find(__Ox5ad01[2]).val();
        var name = $(this).parent().find(__Ox5ad01[9]).children().text();
        thunderLink.newTask({
            downloadDir: __Ox5ad01[10],
            tasks: [{
                name: name,
                url: url,
                size: 0
            }]
        });
    });
    $(__Ox5ad01[15]).click(function(e) {
        var checked = $(this).parent().parent().parent().parent().find(__Ox5ad01[18]);
        for (let i = checked.length; i--; ) {
            checked[i].checked = this.checked;
        }
    });
    $(__Ox5ad01[21]).click(function() {
        var checked = $(this).parent().parent().parent().parent().find(__Ox5ad01[18]);
        if (checked.length < 1) {
            layer.msg(__Ox5ad01[19]);
        } else {
            var tasks = [];
            var urls = $(this).parent().parent().parent().parent().find(__Ox5ad01[20]);
            var names = $(this).parent().parent().parent().parent().find(__Ox5ad01[22]);
            for (let i = 0; i < urls.length; ++i) {
                if (names[i].innerText.indexOf(__encode) >= 0) {
                    var task = {
                        url: urls[i].innerText,
                        size: 0
                    };
                    tasks.push(task);
                }
            }
            thunderLink.newTask({
                downloadDir: __Ox5ad01[10],
                installFile: __Ox5ad01[23],
                taskGroupName: __Ox5ad01[24],
                tasks: tasks,
                excludePath: __Ox5ad01[23]
            });
        }
    });
    if ($(__Ox5ad01[26]).length) {
        $(__Ox5ad01[26]).click(function() {
            var url = $(this).parent().parent().parent().parent().find(__Ox5ad01[25]).children().text();
            getThunder(url, __Ox5ad01[23]);
        });
        var ax = null;

        function getThunder() {
            if (ax == null) {
                try {
                    if (window.ActiveXObject) {
                        ax = new ActiveXObject("ThunderAgent.Agent");
                    } else {
                        var navi = navigator.plugins;
                        for (var i = 0; i < navi.length; i++) {
                            try {
                                if (navi[i].name.indexOf(__Ox5ad01[27]) != -1) {
                                    var o = document.createElement(__Ox5ad01[28]);
                                    o.classid = __Ox5ad01[29];
                                    o.width = 0;
                                    o.height = 0;
                                    o.style.visibility = __Ox5ad01[30];
                                    document.body.appendChild(o);
                                    break;
                                }
                            } catch (e) {}
                        }
                        ax = document.getElementById(__Ox5ad01[31]);
                    }
                } catch (e) {}
            }
            return ax;
        }

        function getThunderUrl(url, installFile) {
            var ax = getThunder();
            try {
                var ver = ax.GetThunderVer("LFF", "LFF");
                var cid = ax.Get("LFF");
                if (ver && cid && ver >= 672 && cid >= 2401) {
                    ax.Put("LFFDownUrl", "thunder://" + url + "__" + installFile + "__");
                } else {
                    var r = confirm(__Ox5ad01[32]);
                    if (r == true) {
                        window.location.href = __Ox5ad01[33] + installFile;
                    }
                }
            } catch (e) {
                var r = confirm(__Ox5ad01[32]);
                if (r == true) {
                    window.location.href = __Ox5ad01[33] + installFile;
                }
            }
        }
    }
    if ($(__Ox5ad01[34]).length) {
        $(__Ox5ad01[34]).find(__Ox5ad01[37]).on(__Ox5ad01[36], function() {
            var url = $(this).attr(__Ox5ad01[41]);
var clipboard = new Clipboard(this, {
text: function() {
return url;
}
});
clipboard.on(__Ox5ad01[38], function(e) {
layer.msg(__Ox5ad01[39]);
});
});
}
if ((__Ox5ad01[42]).length) { (__Ox5ad01[42]).on(__Ox5ad01[36], function() {
var url = $(this).attr(__Ox5ad01[41]);
var clipboard = new Clipboard(this, {
text: function() {
return url;
}
});
clipboard.on(__Ox5ad01[38], function(e) {
layer.msg(__Ox5ad01[39]);
});
});
}
});