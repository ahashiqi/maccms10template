<?php
namespace app\admin\controller;


class Mgpc extends Base
	{
		public function mgset()
		{
			if (Request()->isPost()) {
				$config = input();
				$config_new["mgcms"] = $config["mgcms"];
				$config_old = config("mgst");
				$config_new = array_merge($config_old, $config_new);
				$res = mac_arr2file(APP_PATH . "extra/mgst.php", $config_new);
				if ($res === false) {
					return $this->error("保存失败，请重试!");
				}
				return $this->success("保存成功!");
			}
			$this->assign("config", config("mgst"));
			return $this->fetch("admin@system/mgcms");
		}
	}
