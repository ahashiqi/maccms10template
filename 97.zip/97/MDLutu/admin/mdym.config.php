<?php
 $mdym =  array (
  'load' => 
  array (
    'state' => '1',
    'time' => '5',
    'appurl' => '#',
    'url' => '#',
    'img' => 'https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fhbimg.huabanimg.com%2Fb4a9968782d6e2a8db3fbc4964f69514939e213428301-76zkNp_fw658&refer=http%3A%2F%2Fhbimg.huabanimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1641396962&t=12edad3c1a34cbbe47577bf56e3f36ec',
  ),
  'logo' => '',
  'type' => 
  array (
    'one' => '1',
    'two' => '2',
  ),
  'email' => '',
  'group' => '',
  'search' => '永久网址 xxx.xx',
  'qrcode' => '',
  'gonggao' => '<a href="#" target="_blank" rel="noopener noreferrer">地址:xxx.xx</a>
<p>五一劳动大促销，劳动节快乐！<br><br>近期严格审查线路，屏幕截图保存二维码即可隨時找到我们！</p>
<img src="https://www.baidu.com">',
  'playad' => '<a href="https://www.baidu.com" class="ga-share">
<img src="https://z3.ax1x.com/2021/11/21/IjRErD.gif" width="100%" alt="ad">
</a>',
  'yjurl' => 'https://www.baidu.com',
);
?>