window.jQuery||document.write('<script src="{$maccms.path}mxtheme/js/jquery.min.js"></script>');
$(document).ready(function(){
	$('.open-more-desc').click(function(){
		$('.show-desc').removeClass('module-info-introduction-content');
		$('.open-more-desc').css('display','none');
		$('.close-more-desc').css('display','flex');
	});
	$('.close-more-desc').click(function(){
		$('.open-more-desc').css('display','flex');
		$('.close-more-desc').css('display','none');
		$('.show-desc').addClass('module-info-introduction-content');
	});
});
function getQr(XueBuHuiGo){
	if(!$('#desc_qrcode_img').attr('src')){
		$('#desc_qrcode_img').attr('src',url);
	}
	if($('#desc_qrcode_main').css('display')=='none'){
		$('#desc_qrcode_main').show();
	}else{
		$('#desc_qrcode_main').hide();
	}
};