<?php
session_start();
error_reporting(0);
include('yzm.config.php'); 
define('SYSPATH',$yzm['path']);

?>