<?php
 $yzm =  array (
  'pic' => 
  array (
    'logo' => 'template/b/images/logo2.png',
    'lazy' => 'template/b/images/loading.gif',
    'top' => 'https://i0.hdslb.com/bfs/archive/7197cae46569a49abd98e0c51348068831be6a85.png',
  ),
  'qqqun' => 'http://wpa.qq.com/msgrd?v=3&uin=276121760&site=qq&menu=yes',
  'APP_down' => '',
  'home' => 
  array (
    'ad' => 
    array (
      'ad_1' => '',
      'ad_2' => '',
    ),
    'guide1' => 
    array (
      'link' => 'http://tvgo.bio/',
      'title' => '二站',
      'state' => '1',
    ),
    'guide2' => 
    array (
      'link' => 'http://dd.xiantian.fun/',
      'title' => '导航',
      'state' => '1',
    ),
    'guide3' => 
    array (
      'link' => 'http://cms.xiantian.fun/',
      'title' => '尔氡氡酱',
      'state' => '1',
    ),
    'guide4' => 
    array (
      'link' => '123',
      'title' => '测试',
      'state' => '0',
    ),
    'guide5' => 
    array (
      'link' => '123',
      'title' => '测试',
      'state' => '0',
    ),
    'banner' => 
    array (
      'value' => '4',
      'level' => '9',
      'right' => '1',
    ),
    'top_guide' => 
    array (
      'state' => '1',
    ),
    'xuanfu' => 
    array (
      'state' => '1',
    ),
    'week' => 
    array (
      'state' => '1',
    ),
    'hot' => 
    array (
      'rnd' => '1',
      'level' => '2',
      'title' => '热门推荐',
      'state' => '0',
    ),
    'show1' => 
    array (
      'by' => 'rnd',
      'type' => '1',
      'title' => '电影',
      'state' => '1',
    ),
    'show2' => 
    array (
      'by' => 'time',
      'type' => '2',
      'title' => 'TV剧',
      'state' => '1',
      'type1' => '13',
      'type2' => '14',
      'type3' => '15',
      'type4' => '16',
    ),
    'show3' => 
    array (
      'by' => 'time',
      'type' => '3',
      'title' => '综艺',
      'state' => '1',
    ),
    'show4' => 
    array (
      'by' => 'time',
      'type' => '4',
      'title' => '动漫',
      'state' => '1',
    ),
  ),
  'topcss' => 'div::-webkit-scrollbar{width: 2px;/*height: 4px;*/}
div::-webkit-scrollbar-thumb{border-radius: 10px;-webkit-box-shadow: inset 0 0 5px #e2e2e2;background: #e2e2e2;}
div::-webkit-scrollbar-track{-webkit-box-shadow: inset 0 0 5px #fafafa;border-radius: 0;background: #fafafa;}
html::-webkit-scrollbar{width: 4px;height: 4px;}
html::-webkit-scrollbar-thumb{border-radius: 10px;-webkit-box-shadow: inset 0 0 5px #00a4db;background: #00a4db;}
html::-webkit-scrollbar-track{-webkit-box-shadow: inset 0 0 5px #ddd;border-radius: 10px;background: #ddd;}
body {cursor: url(https://i.loli.net/2019/04/23/5cbedb2dae545.png), default;} a:hover{cursor:url(https://i.loli.net/2019/04/23/5cbedb246fd81.png), pointer;}
',
  'foottitle' => '本站不提供任何视听上传储存服务，所有内容均来至网络自动采集，只提供web页面浏览服务，并不提供影片资源存储，也不参与任何视频录制、上传.',
  'pc_gonggao' => '本站完全免费！欢迎分享本站给你的朋友！我们的网址http://cms.xiantian.fun/',
  'pc_tixing' => '播放中若遇到视频加载卡顿、播放失败、请在下方点击<font color="#e20048">>播放来源</font><font color="#c630f7">或切换线路</font><font color="#03a9f4">>选择其他片源</font><font color="#c630f7">>点集数播放.</font>如有其他问题可加入qq反馈~微信看剧也简单.',
  'wap_gonggao' => '通知个球球：即日起网站免费观看！！！感谢您对的支持！！！',
  'wap' => 
  array (
    'banner' => 
    array (
      'value' => '4',
      'level' => '9',
    ),
    'top' => 
    array (
      'level' => '1',
      'value' => '2',
      'title' => '置顶s ',
      'state' => '0',
    ),
    'hot' => 
    array (
      'level' => '2',
      'value' => '8',
      'title' => '热门电影',
      'title1' => '院线热播',
      'state' => '1',
    ),
    'hot1' => 
    array (
      'level' => '1',
      'value' => '8',
      'title' => '热门推荐',
      'state' => '0',
    ),
    'week' => 
    array (
      'state' => '1',
    ),
    'fenlei' => 
    array (
      'state' => '0',
    ),
    'zuixin' => 
    array (
      'state' => '0',
    ),
    'play' => 
    array (
      'state' => '1',
    ),
  ),
  'wap_tixing' => '全网搜索已恢复！！( ゜- ゜)つロ如有不能播放的资源，一定要记得点“<a href="javascript:;" tapmode onClick="MAC.Gbook.Report(\'编号【{$obj.vod_id}】名称【{$obj.vod_name}】不能观看请检查修复，页面地址\' + location.href)"><span style="color: #fb7299;">报错</span></a>”哟！或者在下方留言都可以！！！',
);
?>