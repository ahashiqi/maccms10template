<?php
return array (
  'basic' => 
  array (
    'paw_name' => '首涂短剧',
    'paw_short_name' => '首涂短剧',
    'paw_icon512' => '/template/zhiyan/pwa/icons/android-chrome-512x512.png',
    'paw_icon192' => '/template/zhiyan/pwa/icons/android-chrome-192x192.png',
    'paw_theme_color' => '#16151a',
    'paw_background_color' => '#ffffff',
  ),
  'poster' => 
  array (
    'lopimg' => '/template/zhiyan/statics/images/load.png',
    'high' => '140',
    'subtitle' => 'vod_class',
    'subtitle_is' => '1',
    'text1' => 'vod_score',
    'position1' => 'left',
    'text1_is' => '1',
    'text2' => 'vod_remarks',
    'position2' => 'left',
    'text_is' => '0',
    'text2_is' => '1',
    'radius' => '10',
  ),
  'other' => 
  array (
    'modeno' => '0',
    'rightno' => '0',
    'f12no' => '0',
    'iframeno' => '0',
    'selectno' => '0',
    'rightnotext' => '你知道的太多了！',
    'opgreytime' => '2024-03-04',
    'opgrey' => '0',
  ),
  'nav' => 
  array (
    'data' => 
    array (
      12 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '全部',
        'type' => '1',
        'val' => '1',
        'blank' => '0',
      ),
      0 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '犯罪',
        'type' => '1',
        'val' => '21',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '奇幻',
        'type' => '1',
        'val' => '22',
        'blank' => '0',
      ),
      8 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '灾难',
        'type' => '1',
        'val' => '23',
        'blank' => '0',
      ),
      9 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '悬疑',
        'type' => '1',
        'val' => '24',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '动作',
        'type' => '1',
        'val' => '6',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '科幻',
        'type' => '1',
        'val' => '8',
        'blank' => '0',
      ),
      10 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '爱情',
        'type' => '1',
        'val' => '7',
        'blank' => '0',
      ),
      11 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '恐怖',
        'type' => '1',
        'val' => '9',
        'blank' => '0',
      ),
    ),
  ),
  'index' => 
  array (
    'data' => 
    array (
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-calendar',
        'title' => '最近更新',
        'block' => 'vod_list2',
        'type' => 'all',
        'by' => 'time',
        'subval' => '/index.php/vod/type/id/1.html',
      ),
      0 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '测试广告',
        'block' => 'vod_ad',
        'type' => '1',
        'by' => '',
        'subval' => '',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-hot',
        'title' => '热播美剧',
        'block' => 'vod_list',
        'type' => 'all',
        'by' => 'hits',
        'subval' => '',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-like',
        'title' => '最受欢迎',
        'block' => 'vod_list',
        'type' => 'all',
        'by' => 'hits_week',
        'subval' => '',
      ),
      5 => 
      array (
        'is' => '1',
        'icon' => 'icon-film',
        'title' => '随机推荐',
        'block' => 'vod_list',
        'type' => 'all',
        'by' => 'rnd',
        'subval' => '',
      ),
    ),
  ),
  'navfoot' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '首页',
        'type' => 'web',
        'val' => 'https://www.shoutu.cn/',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-menu',
        'title' => '分类',
        'type' => '1',
        'val' => '1',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-favorite',
        'title' => '推荐',
        'type' => 'url',
        'val' => 'label/hot',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-time',
        'title' => '历史',
        'type' => 'url',
        'val' => 'label/history',
        'blank' => '0',
      ),
    ),
  ),
  'dialog' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'id' => 'Weixin',
        'title' => '联系客服',
        'class' => 'center',
        'code' => '<div class="text-center"><p><img src="/template/shoutu30/img/weixin.jpg" /></p><p>微信扫一扫联系我们</p></div>',
      ),
    ),
  ),
  'play' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-like',
        'title' => '猜你喜欢',
        'block' => 'vod_list2',
        'type' => 'all',
        'by' => 'time',
        'subval' => '',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => '',
        'title' => '图片广告',
        'block' => 'vod_ad',
        'type' => '1',
        'by' => '',
        'subval' => '',
      ),
    ),
  ),
  'ad' => 
  array (
    'data' => 
    array (
      1 => 
      array (
        'is' => '1',
        'title' => '首页1号',
        'url' => '#',
        'img' => '/template/zhiyan/img/adadad.png',
        'val' => '',
        'blank' => '0',
      ),
    ),
  ),
  'seo1' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
    'diy' => '1',
  ),
  'seo0' => 
  array (
    'title' => '[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo10' => 
  array (
    'title' => '视频首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
    'diy' => '',
  ),
  'seo14' => 
  array (
    'title' => '[vod_name]-在线观看-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
    'diy' => '',
  ),
  'seo15' => 
  array (
    'title' => '[vod_name]-在线观看在线下载-[vod_area][vod_year][vod_class]片-[site_name]',
    'key' => '[site_keywords],[vod_class]',
    'des' => '[vod_blurb]',
  ),
  'seo11' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo30' => 
  array (
    'title' => '专题首页-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo12' => 
  array (
    'title' => '[type_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo13' => 
  array (
    'title' => '搜索结果-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo31' => 
  array (
    'title' => '[topic_name]-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[topic_blurb]',
  ),
  'seo2' => 
  array (
    'title' => '网站地图-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'seo4' => 
  array (
    'title' => '留言板-[site_name]',
    'key' => '[site_keywords]',
    'des' => '[site_description]',
  ),
  'set' => 
  array (
    'seatext' => '我想赚几个亿很合理吧',
    'seatext_is' => '1',
    'seahot' => '战狼,流浪地球',
    'seahot_is' => '1',
    'topadjs' => '',
    'topadjs_is' => '0',
    'footadjs' => '',
    'footadjs_is' => '0',
    'footcode' => '',
    'footcode_is' => '0',
  ),
  'module' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '男频爽剧',
        'desc' => '男生都爱看的',
        'type' => 'url',
        'val' => 'label/boy',
        'level' => '1',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'title' => '女频爽剧',
        'desc' => '女生都爱看的',
        'type' => 'url',
        'val' => 'label/girl',
        'level' => '2',
        'blank' => '0',
      ),
    ),
  ),
  'head' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '首页',
        'type' => 'url',
        'val' => '/',
        'blank' => '0',
      ),
    ),
  ),
  'nav_head' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '首页',
        'type' => 'web',
        'val' => '/',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-photo',
        'title' => '全部美剧',
        'type' => '1',
        'val' => '1',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-rank',
        'title' => '最新美剧',
        'type' => 'url',
        'val' => 'label/new',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-hot',
        'title' => '热门美剧',
        'type' => 'url',
        'val' => 'label/hot',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'icon' => 'icon-support',
        'title' => '推荐美剧',
        'type' => 'url',
        'val' => 'label/jian',
        'blank' => '0',
      ),
    ),
  ),
  'nav_right' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'icon' => 'icon-home',
        'title' => '首页',
        'type' => 'web',
        'val' => '/',
        'blank' => '0',
      ),
      1 => 
      array (
        'is' => '1',
        'icon' => 'icon-photo',
        'title' => '全部',
        'type' => '1',
        'val' => '1',
        'blank' => '0',
      ),
      2 => 
      array (
        'is' => '1',
        'icon' => 'icon-rank',
        'title' => '最新',
        'type' => 'url',
        'val' => 'label/new',
        'blank' => '0',
      ),
      3 => 
      array (
        'is' => '1',
        'icon' => 'icon-hot',
        'title' => '热门',
        'type' => 'url',
        'val' => 'label/hot',
        'blank' => '0',
      ),
      4 => 
      array (
        'is' => '1',
        'icon' => 'icon-support',
        'title' => '推荐',
        'type' => 'url',
        'val' => 'label/jian',
        'blank' => '0',
      ),
      5 => 
      array (
        'is' => '1',
        'icon' => 'icon-favorite',
        'title' => '排行',
        'type' => 'url',
        'val' => 'label/rank',
        'blank' => '0',
      ),
    ),
  ),
  'title' => 
  array (
    'h1' => '嘿，终于等到你',
    'h2' => '定期更新热门美剧，禁止广告，为美剧爱好者提供良好的观影环境',
    'h2_is' => '1',
  ),
  'typeid' => 
  array (
    'data' => 
    array (
    ),
  ),
  'slide' => 
  array (
    'data' => 
    array (
      0 => 
      array (
        'is' => '1',
        'title' => '西行纪年番',
        'id' => '87283',
        'url' => '',
        'img' => 'https://tv.puui.qpic.cn/tv/0/mz_tv_image_frontend_fbd86c-2_778223561_1713873715815300_pic_1920x800/0',
        'val' => '',
        'blank' => '0',
      ),
    ),
    'is' => '1',
    'style' => '0',
  ),
);