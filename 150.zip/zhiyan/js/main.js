 /*文章展开隐藏*/
 function expandText(selector, maxLength) {
      var text = $(selector).text(); // 获取文本内容
      if (text.length > maxLength) {
        var shortText = text.substr(0, maxLength); // 截取前10个字符
        var longText = text.substr(maxLength); // 截取剩余的文字
        $(selector).html(shortText + '<span class="hidden">' + longText + '</span>' + '<a href="#" class="toggle-content">...展开</a>');
        $('.toggle-content').click(function(e) {
          e.preventDefault();
          $(this).prev('.hidden').toggle(); // 切换隐藏/显示状态
          if ($(this).text() === '...展开') {
            $(this).text('收起');
          } else {
            $(this).text('...展开');
          }
        });
      }
 }

$(function () {
     /*懒加载*/
    $("img.lazyload").lazyload();
     /*菜单*/
    $(".menu").hover(function() {
        $(".menu-ul").css("display","flex").css("flex-flow","wrap").show();
    },function() {
        $(".menu-ul").hide();
    });
    
    // 点击切换主题风格
    $('.changetheme').hover(function() {
        $('.zy-style').toggleClass('expand');
    });
    // 在页面加载时检查并应用保存的主题样式
    var savedTheme = localStorage.getItem('theme_style');
    if (savedTheme !== null) {
        $('body').addClass("style-for-" + savedTheme);
    }
    $(".zy-style a").click(function(){
        var styleName = $(this).attr("style-text");
        var expirationDays = 1; // Cookie 有效期为一天
        
        // 移除之前保存的主题样式
        var styleClasses = $('body').attr('class').split(' ');
        var classesToKeep = styleClasses.filter(className => !className.startsWith('style-for-'));
        $('body').removeClass().addClass(classesToKeep.join(' '));
        
        // 添加新的主题样式并保存到 localStorage
        $('body').addClass("style-for-" + styleName);
        localStorage.setItem('theme_style', styleName);
    });

    /*分享*/
    var clipboard = new ClipboardJS('.share');
    $(".share").click(function () {
        $.toast({
            heading: '复制成功，快去分享吧',
            position: 'mid-center',
            icon: 'success',
            loader: true,
            loaderBg: '#439b6b',
            text: $(this).attr('data-clipboard-text'),
        })
    });
});