$(function(){
	$(window).scroll(function(){	
		if(Math.ceil($(this).scrollTop()) + $(this).height() >= $(document).height()){
			var $that = $("#Morelist");
			$that.attr("data-page", parseInt($that.attr("data-page")) + 1);
			if ($that.attr("data-page")-1 == '{$__PAGING__.page_total}') {
				$("#Morelist").remove();
				$(".list-loading").hide();
				$(".list-tips").append("<p style='padding: 0.5rem 0;'>没有更多数据了</p>");
			}else if ($that.attr("data-page") == '20') {
				$("#Morelist").remove();
				$(".list-loading").hide();
				$(".list-tips").append("<p style='padding: 0.5rem 0;'>我是有底线的</p>");
			}
			if ($("#Morelist").length > 0) {			
				$.ajax({
					type: "get",
					url: '{$maccms.path}index.php/ajax/data.html?mid='+$that.attr("data-mid")+'&page='+$that.attr("data-page")+'&limit=30&tid='+$that.attr("data-tid")+'',
					dataType: "json",
					success: function(data) {
						var _list="";
						$.each(data.list,function(i,vo){
                           _list+='<div class="col-12 d-flex pt-3 pb-4"><div class="haibao"style="width:15%"><a href="'+vo.vod_url+'"><img src="'+vo.vod_pic+'"style="width:100%"></a></div><div class="wenzi d-flex flex-column justify-content-between"style="width:85%"><div class="shang d-flex"><span class="text-truncate"class="ming"><a class="text-info"href="'+vo.vod_url+'">'+vo.vod_name+'</a></span><strong class="nian text-secondary ml-1">('+vo.vod_year+')</strong></div><div class="zhong text-muted">'+vo.type.type_name+'/ '+vo.vod_class+' /'+vo.vod_area+'/ '+vo.vod_actor+'</div><div class="xia text-muted d-flex align-items-center"></div><div class="bo d-flex"><a href="'+vo.vod_url+'"class="mr-2 text-nowrap border rounded px-4 text-dark">已归档，直达精准播放列表</a></div></div></div>'
						});
						$('#test').append(_list);		           	
					}
				});						
			}
		}
	});
});