

// 搜索框回车事件
$('.input-group input').on('keypress', function(e) {
	var keycode = e.keyCode;
	var c = $(this).val();
	if(keycode == '13') {
		self.location.href='/s?c='+c;
	}
});

// ldb-shijian 事件监听
$('body').on('click', '[ldb-shijian]', function(){
	var shijian = $(this).attr('ldb-shijian');
	f = shijianzu[shijian];
	if(typeof(f) != 'undefined'){
		f(this);
	}	
	return false;
});

//ldb-shijian 事件组
var shijianzu = {
	//所有页面 搜索按钮事件
	waisou : function(me){
		c = $(me).parent().prev().val();
		self.location.href='/s?c='+c;
	},
	// 所有页面 A标签搜索
	neisou : function(me){

		c = $(me).html();
		self.location.href='/s?c='+c;
	},
	//首页 LOGO戳事件
	logo_chuo : function(me){
		$(me).parent().hide();
		$(me).parent().next().show();
	},
	// 搜索页 左侧 加载更多按钮事件
	ssy_jiazai :function(me){
		yeshuzhi +=1;
		zuoce_sousuobiao(guanjianzizhi, yeshuzhi);
	},
	// 测速按钮事件
	cesu : function(me){
		if($(me).html() == '测速中。。'){
			return false;
		}
		var m3u8 = $(me).attr('ldb-m3u8');
		$(me).html('测速中。。');
		var qidong = new Date().getTime();
		$.ajax({
			url:m3u8, 
			success: function(){
				var shijian = new Date().getTime() - qidong;
				$(me).html(shijian.toString() + 'ms');
			},
			error:function(){
				$(me).html('测试失败！');
			}
		});
	},
	// 播放按钮事件

	shoucang :function(me){
		var bianhaozhi = $(me).attr('ldb-bianhao');
		$.post('/shoucang/tianjia', {bianhao:bianhaozhi}, function(fanhui){
			// 收藏失败
			if(fanhui.zhuangtai == 1){
				alert(fanhui.xinxi);
			}
			
			if(fanhui.zhuangtai == 0){
				alert(fanhui.xinxi);
			}
		})
	},
	shanshoucang :function(me){
		var bianhaozhi = $(me).attr('ldb-bianhao');
		var xunwen = confirm('确定删除？');
		if(xunwen){
			$.post('/shoucang/shanchu', {bianhao:bianhaozhi}, function(fanhui){
				// 删除收藏失败
				if(fanhui.zhuangtai == 1){
					alert(fanhui.xinxi);
				}
				if(fanhui.zhuangtai == 0){
					self.location.href='/huiyuan';
				}
			})
		}
	},
	dingyue :function(me){
		var bianhaozhi = $(me).attr('ldb-bianhao');
		$.post('/dingyue/tianjia', {bianhao:bianhaozhi}, function(fanhui){
			// 收藏失败
			if(fanhui.zhuangtai == 1){
				alert(fanhui.xinxi);
			}
			
			if(fanhui.zhuangtai == 0){
				alert(fanhui.xinxi);
			}
		})
	},
	shandingyue :function(me){
		var bianhaozhi = $(me).attr('ldb-bianhao');
		var xunwen = confirm('确定删除？');
		if(xunwen){
			$.post('/dingyue/shanchu', {bianhao:bianhaozhi}, function(fanhui){
				// 删除收藏失败
				if(fanhui.zhuangtai == 1){
					alert(fanhui.xinxi);
				}
				if(fanhui.zhuangtai == 0){
					self.location.href='/huiyuan';
				}
			})
		}
	},
	shanjilu :function(me){
		var suoyin = $(me).attr('ldb-suoyin');
		var xunwen = confirm('确定删除？');
		if(xunwen){
			
			var jilujson = $.cookie('ldb_guankanjilu');
			jiluzu = JSON.parse(jilujson);
			jiluzu.splice(suoyin,1);
			$.cookie('ldb_guankanjilu', JSON.stringify(jiluzu));
			
			self.location.href='/guankanjilu';
		}
	},
	// 注册
	zhuce : function(){
		var data = {};
			data.email = $('[name="email"]').val();
			data.pass1 = $('[name="pass1"]').val();
			data.pass2 = $('[name="pass2"]').val();
			data.yanzhengma = $('[name="yanzhengma"]').val();
			
			var yzmail = /^\w+@\w+(\.\w+)+$/;
			var yzpass = /^[a-zA-Z0-9]{6,10}$/;
			var yzyanzhengma = /^[0-9]{6}$/;
			
			if(data.email == ''){
				$('.email_ts').text('信箱不能为空！');
				$('.email_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzmail.test(data.email)){
				$('.email_ts').text('信箱格式不正确！');
				$('.email_ts').addClass('text-danger');
				return false;
			}
			
			$('.email_ts').text('信箱验证通过！');
			$('.email_ts').removeClass('text-danger');
			$('.email_ts').addClass('text-success');
			
			if(data.pass1 == ''){
				$('.pass1_ts').text('登录密码不能为空！');
				$('.pass1_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzpass.test(data.pass1)){
				$('.pass1_ts').text('登录密码格式不正确！');
				$('.pass1_ts').addClass('text-danger');
				return false;
			}
			
			$('.pass1_ts').text('登录密码验证通过！');
			$('.pass1_ts').removeClass('text-danger');
			$('.pass1_ts').addClass('text-success');
			
			
			if(data.pass2 == ''){
				$('.pass2_ts').text('确认密码不能为空！');
				$('.pass2_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzpass.test(data.pass2)){
				$('.pass2_ts').text('确认密码格式不正确！');
				$('.pass2_ts').addClass('text-danger');
				return false;
			}
			
			if(data.pass1 != data.pass2){
				$('.pass2_ts').text('确认与登录密码不一样！');
				$('.pass2_ts').addClass('text-danger');
				return false;
			}
			
			$('.pass2_ts').text('登录密码验证通过！');
			$('.pass2_ts').removeClass('text-danger');
			$('.pass2_ts').addClass('text-success');
			
			if(data.yanzhengma == ''){
				$('.yanzhengma_ts').text('还没有填写验证码！');
				$('.yanzhengma_ts').addClass('text-danger');
				return false;
			}
			
			
			if(!yzyanzhengma.test(data.yanzhengma)){
				$('.yanzhengma_ts').text('验证码格式不正确！');
				$('.yanzhengma_ts').addClass('text-danger');
				return false;
			}
		
			$('.yanzhengma_ts').text('验证码通过！');
			$('.yanzhengma_ts').removeClass('text-danger');
			$('.yanzhengma_ts').addClass('text-success');
			
			
			$.post('/huiyuan/zhucepost', data, function(fanhui){
				// 注册失败
				if(fanhui.zhuangtai != 0){
					$(fanhui.zhuangtai).text(fanhui.xinxi);
					$(fanhui.zhuangtai).addClass('text-danger');
				}
				
				if(fanhui.zhuangtai == 0){
					self.location.href='/huiyuan/denglu';
				}
			})
	},
	fasongyanzhengma : function(){
		
		var data = {};
			data.email = $('[name="email"]').val();
			
			var yzmail = /^\w+@\w+(\.\w+)+$/;
	
			if(data.email == ''){
				$('.email_ts').text('信箱不能为空！');
				$('.email_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzmail.test(data.email)){
				$('.email_ts').text('信箱格式不正确！');
				$('.email_ts').addClass('text-danger');
				return false;
			}
			
			var yanzhenganniu = $('[ldb-shijian="fasongyanzhengma"]');
				$(yanzhenganniu).attr('disabled', true);
				$(yanzhenganniu).text('正在获取。。。');
				
			var jishi = 60;
			var dingshiqi; 
			
		$.post('/huiyuan/quyanzhengma', data, function(fanhui){
			$(yanzhenganniu).text(fanhui.xinxi);
			dingshiqi = window.setInterval(function(){
					jishi -= 1;
					if(jishi == 0){
						clearInterval(dingshiqi);
						$(yanzhenganniu).attr('disabled', false);
						$(yanzhenganniu).text('获取验证码');
					}
					if(jishi != 0){
						$(yanzhenganniu).text(jishi.toString()+'秒后重新获取！');
					}
				}, 1000);
		})
	},
	fasongmima : function(){
		
		var data = {};
			data.email = $('[name="email"]').val();
			
			var yzmail = /^\w+@\w+(\.\w+)+$/;
	
			if(data.email == ''){
				$('.email_ts').text('信箱不能为空！');
				$('.email_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzmail.test(data.email)){
				$('.email_ts').text('信箱格式不正确！');
				$('.email_ts').addClass('text-danger');
				return false;
			}
			
			var yanzhenganniu = $('[ldb-shijian="fasongmima"]');
				$(yanzhenganniu).attr('disabled', true);
				$(yanzhenganniu).text('正在发送。。。');
				
			var jishi = 60;
			var dingshiqi; 
			
		$.post('/huiyuan/fasongmima', data, function(fanhui){
			$(yanzhenganniu).text(fanhui.xinxi);
			dingshiqi = window.setInterval(function(){
					jishi -= 1;
					if(jishi == 0){
						clearInterval(dingshiqi);
						$(yanzhenganniu).attr('disabled', false);
						$(yanzhenganniu).text('忘记了，取回密码？');
					}
					if(jishi != 0){
						$(yanzhenganniu).text(jishi.toString()+'秒后重新发送！');
					}
				}, 1000);
		})
	},
	denglu : function(){
		var data = {};
			data.email = $('[name="email"]').val();
			data.pass = $('[name="pass"]').val();
			data.yanzhengma = $('[name="yanzhengma"]').val();
			
			var yzmail = /^\w+@\w+(\.\w+)+$/;
			var yzpass = /^[a-zA-Z0-9]{6,10}$/;
			
			if(data.email == ''){
				$('.email_ts').text('信箱不能为空！');
				$('.email_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzmail.test(data.email)){
				$('.email_ts').text('信箱格式不正确！');
				$('.email_ts').addClass('text-danger');
				return false;
			}
			

			$('.email_ts').removeClass('text-danger');
			$('.email_ts').addClass('text-success');
			
			if(data.pass == ''){
				$('.pass_ts').text('登录密码不能为空！');
				$('.pass_ts').addClass('text-danger');
				return false; 
			}
			
			if(!yzpass.test(data.pass)){
				$('.pass_ts').text('登录密码格式不正确！');
				$('.pass_ts').addClass('text-danger');
				return false;
			}
		
			$('.pass_ts').removeClass('text-danger');
			$('.pass_ts').addClass('text-success');
			
			if(data.yanzhengma == ''){
				console.log(data.yanzhengma );
				$('.yanzhengma_ts').text('还没有填写验证码！');
				$('.yanzhengma_ts').addClass('text-danger');
				return false;
			}
		
			$('.yanzhengma_ts').removeClass('text-danger');
			$('.yanzhengma_ts').addClass('text-success');
			
		$.post('/huiyuan/denglupost', data, function(fanhui){
			if(fanhui.zhuangtai == 1){
				$('.pass_ts').text('');
				$('.yanzhengma_ts').text('');
				$('.email_ts').text(fanhui.xinxi);
				$('.email_ts').addClass('text-danger');
				shijianzu.huanyanzhengma();
			}
			if(fanhui.zhuangtai == 2){
				$('.email_ts').text('');
				$('.yanzhengma_ts').text('');
				$('.pass_ts').text(fanhui.xinxi);
				$('.pass_ts').addClass('text-danger');
				shijianzu.huanyanzhengma();
			}
			if(fanhui.zhuangtai == 3){
				$('.email_ts').text('');
				$('.pass_ts').text('');
				$('.yanzhengma_ts').text(fanhui.xinxi);
				$('.yanzhengma_ts').addClass('text-danger');
				shijianzu.huanyanzhengma();
			}
			
			
			if(fanhui.zhuangtai == 0){
				$('.email_ts').text('');
				$('.pass_ts').text('');
				$('.yanzhengma_ts').text('');
				// 此处模拟POST跳转
			//	var form = $("<form method='post'></form>"),
			//		input;
			//		$(document.body).append(form);
			//		form.attr({'action':'/huiyuan/'});
			//		input = $("<input type='hidden'>");
			//		input.attr({'name':'uuid'});
			//		input.val(fanhui.uuid);
			//		form.append(input);
			//		form.submit();
				//console.log(fanhui.uuid);
				self.location.href='/huiyuan/';
			}
		})
	},
	huanyanzhengma : function(){
		$('[name="yanzhengma"]').next().children('img').attr('src','/huiyuan/yanzhengma?t='+Date())
	},
	// 列表页 筛选按钮事件
	lby_shaixuan:function(me){
		// 已选中直接返回
		if($(me).hasClass('active')){
			return false;
		}
		// 删除同级所有样式
		$(me).siblings().each(function(){
			$(this).removeClass('active')
		})
		// 赋值被选元素样式
		$(me).addClass('active');
		var leixing = $('.leixing .active').attr('ldb-zhi');
		var diqu = $('.diqu .active').attr('ldb-zhi');
		var nianfen = $('.nianfen .active').attr('ldb-zhi');
		var paixu = $('.paixu .active').attr('ldb-zhi');
		var tuwen = $('.tuwen .active').attr('ldb-zhi');	
			
			
		$('.tuwenbiao').hide();
		$('.tubiao').hide();
		$('.wenzibiao').hide();
		
		$('.tuwenbiao').html('');
		$('.tubiao').html('');
		$('.wenzibiao ul').html('');	
			
		// 图文列表
		if(tuwen == 'tuwen'){
			$('.tuwenbiao').show();
		}		
		// 海报列表
		if(tuwen == 'tu'){
			$('.tubiao').show();
		}	
		// 文字列表
		if(tuwen == 'wen'){
			$('.wenzibiao').show();
		}
		
		yeshuzhi = 1;
		$('.jiazai').addClass('d-flex');
		$('.jiazai').show();
		zuoce_biaojiazai(yeshuzhi, fenlei, tuwen, leixing, diqu, nianfen ,paixu);
		
	}// 左侧 表加载按钮 事件
	,biao_jiazai :function(me){
		yeshuzhi +=1;
		 
		var leixing = $('.leixing .active').attr('ldb-zhi');
		var diqu = $('.diqu .active').attr('ldb-zhi');
		var nianfen = $('.nianfen .active').attr('ldb-zhi');
		var paixu = $('.paixu .active').attr('ldb-zhi');
		var tuwen = $('.tuwen .active').attr('ldb-zhi');
		// 排行页需要此处
		if(tuwen == undefined){
			tuwen = 'tuwen';
		}
		zuoce_biaojiazai(yeshuzhi, fenlei, tuwen, leixing, diqu, nianfen ,paixu);
	},
		dizhifanxu :function(){
		var dizhizu = [];
		$('.tab-content .show a').each(function(){
			dizhizu.push(this.outerHTML);
		});
		$('.tab-content .show').html(dizhizu.reverse().join(''));
	}
};
// 左侧图文列表加载 
function zuoce_biaojiazai(yeshuzhi, fenleizhi, tuwen, leixingzhi, diquzhi, nianfenzhi, paixuzhi){
		
		var data = {};
		data.fenlei = fenleizhi;
		data.yeshu = yeshuzhi;
		data.leixing = leixingzhi;
		data.diqu = diquzhi;
		data.nianfen = nianfenzhi;
		data.paixu = paixuzhi;
		data.tuwen = tuwen;
		$.post('/api/neirong/', data, function(fanhui){
		/* 没有数据 */
		if(fanhui.zhuangtai == 404){ 
			$('[ldb-shijian="biao_jiazai"]').html(fanhui.xinxi);
			$('[ldb-shijian="biao_jiazai"]').attr('disabled', true);
			return false;
		}
		var data = {liebiao : fanhui};
		if(tuwen == 'tuwen'){
			var html = template('tuwenbiao_moban', data); 
			$('.tuwenbiao').append(html);
			zuoce_tuwenbiao_zishiying('.tuwenbiao');
		}
		if(tuwen == 'tu'){
			var html = template('tubiao_moban', data); 
			$('.tubiao').append(html);
			zuoce_tubiao_zishiying('.tubiao');
		}
		if(tuwen == 'wen'){
			var html = template('wenzibiao_moban', data); 
			$('.wenzibiao ul').append(html);
		}
	})
}

//折叠LOGO监听
(function() {
  $('.zhedie-logo').children('span').hover((function() {
    var $el, n;
    $el = $(this);
    n = $el.index() + 1;
    $el.addClass('lan');
    if (n % 2 === 0) {
      return $el.prev().addClass('lan');
    } else {
      if (!$el.hasClass('jieshu')) {
        return $el.next().addClass('lan');
      }
    }
  }), function() {
    return $('.lan').removeClass('lan');
  });
}).call(this);


// 播放页 设置播放器高度

// 播放页观看记录
function guankanjilu(){
	var jilu = {};
		jilu.h = h;
		jilu.y = y;
		jilu.t = t;	
	if(jiluzu == undefined){   // 没有观看记录
		jiluzu = [];
		jiluzu.unshift(jilu);
		jilusuoyin = 0;
	}else{
		jiluzu = JSON.parse(jiluzu); // 有观看记录记录索引
		for(var jian in jiluzu){  // 判断观看记录是否存在
			if(jiluzu[jian].h == h){
				jilusuoyin = jian;
				if(jiluzu[jilusuoyin].y == y){
					shijian = jiluzu[jilusuoyin].s;
				}
				// 如果记录纯在，删除原有记录，
				jiluzu.splice(jilusuoyin,1); 
				jiluzu.unshift(jilu);
				jilusuoyin = 0;
				break; 
			}
		}
		if(jilusuoyin == -1){ // 观看记录不存在
			
			//超过记录总数，删远观看时间一条。
			if(jiluzu.length == 20){
				jiluzu.pop();
			}
			jiluzu.unshift(jilu);
			jilusuoyin = 0;
		}
	}
}
// 播放页初始化播放器
function bofangqigaodu(){
	var kuan = $('.video').width();
	$('.video').height(kuan/2);
}
// 播放器监听事件
function bofangqishijian(){
	player.addListener('ended', bofangjieshu); 
	player.addListener('pause', bofangzanting); 
	player.addListener('time', bofangshijian); 
	player.addListener('error', bofangcuowu); 
}

// FLASH 播放错误，自动切换到HTML5
function bofangcuowu(){
	var dizhi = videoObject.video;
	videoObject = {
		container: '.video',
		variable: 'player',
		video:dizhi,
		loaded:'bofangqishijian',
		html5m3u8:true,
	};
	player = new ckplayer(videoObject);
}
// 播放中事件
function bofangshijian(shijian){
	$('.jianting span').html('已经播放:'+shijian.toFixed(2)+'s --- 视频内广告有风险！');
	
	// 更新观看记录的 当前记录的观看时间
		jiluzu[jilusuoyin].s = parseInt(shijian);
		$.cookie('ldb_guankanjilu', JSON.stringify(jiluzu));
			
}
// 播放暂停事件
function bofangzanting(){
	$('.jianting span').html('觉得不错推荐给朋友!');
}

// 播放结束后连播
function bofangjieshu() {
	var xiaji = $('[ldb-suoyin='+y+']').next();
	var lianbo = $('.lianbo').prop('checked');
	if(xiaji.length == 1 && lianbo){
		$(xiaji).click();
	}
}

// 左侧海报列表
function zuoce_tubiao_zishiying(yuansu){
	var pingkuan = $(window).width();
	
	if(pingkuan >= 1200){
		var jianxi = '40px';
	}
	if(pingkuan >= 992 && pingkuan < 1200){
		var jianxi = '30px';
	}
	if(pingkuan >= 768 && pingkuan < 992){
		var jianxi = '30px';
	}
	if(pingkuan >= 576 && pingkuan < 768){
		var jianxi = '10px';
	}
	if(pingkuan < 576){
		var jianxi = '5px';
	}
	// 设置海报缝隙
	$(yuansu+' .zu').each(function(){
		$(this).css('padding-right', jianxi);
	});
	// 根据海报宽度设置高度
	$(yuansu+' .zu img').each(function(){
		var kd = $(this).width();
		var gd = kd * 1.4;
		$(this).height(gd);	
	})	
}
// 左侧图文列表
// 列表加载完毕 初始化内容溢出设置
function zuoce_tuwenbiao_zishiying(yuansu){
	
	var pingkuan = $(window).width();
	if(pingkuan >= 1200){
		// 文字列表自适应
		var zhong = '8px';
		var bo = '8px';
		var xia = '5px';
		var hangshu = 3;
	}
	if(pingkuan >= 992 && pingkuan < 1200){
		// 文字列表自适应
		var zhong = '7px';
		var bo = '7px';
		var xia = '4px';
		var hangshu = 2;
	}
	if(pingkuan >= 768 && pingkuan < 992){
		// 文字列表自适应
		var zhong = '8px';
		var bo = '8px';
		var xia = '5px';
		var hangshu = 3;
	}
	if(pingkuan >= 576 && pingkuan < 768){
		// 调整海报
		$(yuansu+' .wenzi').each(function(){
			$(this).css('padding-left', '25px');
			$(this).css('width', '85%');
		});
		$(yuansu+' .haibao').each(function(){
			$(this).css('width', '15%');
		});
		// 文字列表自适应
		var zhong = '4px';
		var bo = '6px';
		var xia = '1px';
		var hangshu = 2;
	}
	if(pingkuan < 576){
		// 调整海报
		$(yuansu+' .wenzi').each(function(){
			$(this).css('padding-left', '15px');
			$(this).css('width', '75%');
		});
		$(yuansu+' .haibao').each(function(){
			$(this).css('width', '25%');
		});
		
		var zhong = '4px';
		var bo = '6px';
		var xia = '1px';
		var hangshu = 2;
	}
	// 文字行间距
	$(yuansu+' .zhong').each(function(){
		$(this).css('margin-top', zhong);
	});
	$(yuansu+' .bo').each(function(){
		$(this).css('margin-top', bo);
	});
	$(yuansu+' .xia').each(function(){
		$(this).css('margin-top', xia);
	});
	// 中间行溢出行数
	$(yuansu+' .zhong').each(function(){
		$clamp(this, {clamp: hangshu});
	})
	// 海报自适应
	$(yuansu+' img').each(function(){
		var kd = $(this).width();
		var gd = kd * 1.4;
		$(this).height(gd);	
	})	
}
// 左侧搜索表自适应
function zuoce_sousuobiao_zishiying(yuansu){
	var kuandu = $(yuansu+' img').width();
    $(yuansu+' img').css('height', kuandu*0.6);
}

// 左侧 搜索表加载
function zuoce_sousuobiao(guanjianzizhi, yeshuzhi){
	$.post('/api/sousuo/',{guanjianzi:guanjianzizhi, yeshu: yeshuzhi} , function(fanhui){
		/* 没有数据 */
		if(fanhui.zhuangtai == 404){ 
			$('[ldb-shijian="ssy_jiazai"]').html(fanhui.xinxi);
			$('[ldb-shijian="ssy_jiazai"]').attr('disabled', true);
			return false;
		}
		var data = {liebiao : fanhui,};
		var html = template('sousuobiao_moban', data); 
		$('.sousuobiao').append(html);

		// 列表加载初 始化海报高度
		zuoce_sousuobiao_zishiying('.sousuobiao');
		// 列表加载完毕 初始化内容溢出
		$('.sousuobiao .neirong').each(function(){
			var hangshu = 3;
			if($(window).width() < 576){
				hangshu = 2;
			}
			$clamp(this, {clamp: hangshu});
		})
	})
}

// 右侧列表固定 
function youce_liebiao_guding(zuo, you){
	$(you).css('position', 'fixed');
	var lby_you_top = $(you).offset().top;
	var lby_you_left = $(zuo).offset().left + $(zuo).width() + 40;
	$(you).width($(zuo).width() / 2);   
	$(you).offset({top:lby_you_top, left:lby_you_left});
}


console.warn('影视云擎欢迎您~');
console.warn('朋友，恭喜你看到彩蛋~');
console.warn('觉得本站还行，请一定分享给你的朋友！');