MacPlayer.Html = '<iframe width="100%" height="100%" src="'+MacPlayer.PlayUrl+'" frameborder="0" border="0" marginwidth="0" marginheight="0" scrolling="no"></iframe>';
MacPlayer.Show();